"""Independent cross-package coverage check, without importing author's code.
Checks archived proof dispositions, not the validity of the exhaustive searches.
"""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
MAIN = BASE.parent / "replay_pinned/even-simplex-packet"
LOW = BASE.parent / "replay_pinned/prerequisites_expanded/low-simplex-packet"
sys.path.insert(0, str(BASE.parent.parent / "C2_K4_Methodenpilot_20261117"))
from c2_shared_measurement_20261118_v1 import measure


def need(ok, why):
    if not ok:
        raise ValueError(why)


def rows(path):
    return [line.split() for line in path.read_text().splitlines() if line.strip()]


def value(row, name):
    need(row.count(name) == 1, "missing/duplicate field " + name)
    return int(row[row.index(name) + 1])


def mod_rank(matrix):
    a = [[x % 7 for x in row] for row in matrix]
    basis = {}
    for row in a:
        for col in sorted(basis):
            factor = row[col]
            row = [(x - factor * y) % 7 for x, y in zip(row, basis[col])]
        pivot = next((i for i, x in enumerate(row) if x), None)
        if pivot is not None:
            inv = pow(row[pivot], -1, 7)
            basis[pivot] = [(inv * x) % 7 for x in row]
    return len(basis)


def high_receipts(initial, strong):
    closed = set()
    for row in initial:
        key = int(row[0]), int(row[1]), value(row, "mode")
        need(key not in closed, "duplicate direct case")
        need(value(row, "open") == value(row, "truncated") == 0, "incomplete direct case")
        need(value(row, "nodes") > 0, "empty direct trace")
        closed.add(key)
    chains = defaultdict(list)
    for row in strong:
        key = int(row[0]), int(row[1]), value(row, "mode")
        need(key not in closed, "overlap baseline/strong")
        need(value(row, "open") == value(row, "truncated") == 0, "incomplete strong case")
        start = value(row, "range")
        stop = int(row[row.index("range") + 2])
        end = value(row, "outer")
        limited = value(row, "limited")
        need(0 <= start < stop and start <= end <= stop, "bad range")
        need(value(row, "checked") == end - start, "wrong checked count")
        need(limited in (0, 1) and limited == int(end == stop), "inconsistent range end")
        chains[key].append((start, stop, end, limited))
    for key, chain in chains.items():
        chain.sort()
        cursor = 0
        for pos, (start, stop, end, limited) in enumerate(chain):
            need(start == cursor, "gap or overlap")
            need(limited == int(pos + 1 < len(chain)), "missing/early natural exhaustion")
            cursor = stop
        closed.add(key)
    return closed


def main():
    resource = measure()
    need(resource["ram_free_gib"] >= 10 and resource["disk_free_gib"] >= 35, "resource reserve")
    need(max(r["system_busy_cpu"] for r in resource["intervals"]) + 1 <= 20, "CPU reserve")
    catalog = MAIN / "dualplanes/unary5-packet/layouts.tsv"
    need(catalog.read_bytes() == (LOW / "dualplanes/unary5-packet/layouts.tsv").read_bytes(), "different catalogues")
    independent = json.loads((BASE / "independent_catalogue_coverage.json").read_text())
    need(independent["catalogue_sha256"] == hashlib.sha256(catalog.read_bytes()).hexdigest(), "independent catalogue binding")
    bad = set(independent["physical_bad_ids"])
    rank, degree = {}, {}
    for i, fields in enumerate(rows(catalog)):
        r, *pn = map(int, fields)
        p, n = pn[:12], pn[12:]
        matrix = [[11 * (a == b) + ((a ^ 1) == b) - 4 * (p[a] == b) + 4 * (n[a] == b) - 1 for b in range(12)] for a in range(12)]
        need(mod_rank(matrix) == r, "rank mismatch")
        rank[i] = r
        degree[i] = sum(8 - 4 * (p[j] == j + 1) - 4 * (n[j] == j + 1) > 0 for j in range(0, 12, 2))
    stars, observed_bad = {}, set()
    for row in rows(MAIN / "unsigned15/sf-run/star.tsv"):
        i = int(row[0])
        if row[1] == "bad":
            need(i not in observed_bad, "duplicate bad")
            observed_bad.add(i)
            continue
        key = i, int(row[1])
        need(key not in stars and value(row, "truncated") == 0, "duplicate/truncated star")
        need(value(row, "rank") == rank[i], "star rank mismatch")
        stars[key] = value(row, "outer")
        need(stars[key] in (0, 1), "bad star disposition")
    need(observed_bad == bad, "physical base mismatch")
    need(set(stars) == {(i, p) for i in rank if i not in bad for p in (0, 1)}, "missing star parity")
    required_high = {(i, p, mode) for (i, p), survives in stars.items() if survives and degree[i] % 2 == 0 and rank[i] >= 10 for mode in range(12 - rank[i])}
    required_low = {(i, p) for (i, p), survives in stars.items() if survives and degree[i] % 2 == 0 and rank[i] < 10}
    initial = rows(MAIN / "unsigned15/sf-run/direct-initial.tsv")
    strong = rows(MAIN / "unsigned15/sf-run/direct-strong.tsv")
    observed_high = high_receipts(initial, strong)
    need(observed_high == required_high, "high case set mismatch")
    bare = {(int(i), int(p)): int(total) for i, p, total in rows(LOW / "expected/independent-stars.tsv")}
    low_candidates = set()
    low_unary, low_bad = {}, set()
    for row in rows(LOW / "expected/unary.log"):
        i = int(row[0])
        if row[1] == "bad":
            need(i not in low_bad, "duplicate low bad")
            low_bad.add(i)
        else:
            key = i, int(row[1])
            need(key not in low_unary and value(row, "truncated") == 0, "low unary mismatch")
            low_unary[key] = value(row, "outer")
            need(value(row, "rank") == rank[i] and low_unary[key] in (0, 1), "low rank/disposition")
            if low_unary[key]:
                low_candidates.add(key)
    need(low_bad == {i for i in bad if rank[i] < 10}, "low invalid base set")
    need(set(low_unary) == {(i, p) for i in rank if rank[i] < 10 and i not in bad for p in (0, 1)}, "low unary coverage")
    need(set(bare) == {(i, p) for i in rank if rank[i] < 10 for p in (0, 1)}, "low raw-star coverage")
    baseline, fallback = {}, {}
    names = ["generic-low.tsv", "generic-low-1.tsv", "r9n.log", "r9line.log"]
    for name in names + ["r9n-fallback.log", "r9line-fallback.log"]:
        target = fallback if "fallback" in name else baseline
        for row in rows(LOW / "expected" / name):
            key = int(row[0]), int(row[1])
            need(key not in target and value(row, "open") == 0, "duplicate/open low case")
            target[key] = row
    need(set(baseline) == low_candidates, "low baseline coverage")
    need(set(fallback) == {k for k, r in baseline.items() if value(r, "truncated") == 1}, "low fallback coverage")
    complete_low = dict(baseline)
    complete_low.update(fallback)
    for key, row in complete_low.items():
        need(value(row, "truncated") == 0 and value(row, "star") == bare[key], "low nonexhaustion")
    need(required_low <= set(complete_low), "cross-package low case missing")
    negative = []
    def rejects(label, a, b):
        try:
            need(high_receipts(a, b) == required_high, "required cases not equal")
        except ValueError:
            negative.append(label)
        else:
            raise ValueError("negative control accepted: " + label)
    rejects("missing direct case", initial[1:], strong)
    rejects("duplicate direct case", initial + initial[:1], strong)
    for field in ("open", "truncated"):
        corrupted = [r[:] for r in initial]
        corrupted[0][corrupted[0].index(field) + 1] = "1"
        rejects(field + " never accepted as closure", corrupted, strong)
    corrupted = [r[:] for r in strong]
    corrupted[0][corrupted[0].index("range") + 1] = "1"
    rejects("gap in strong range", initial, corrupted)
    result = dict(time=datetime.now(timezone.utc).isoformat(), status="INDEPENDENT_CROSS_PACKAGE_COVERAGE_PASS",
        high_cases=len(required_high), high_by_degree=dict(Counter(degree[i] for i, p, m in required_high)),
        low_even_cases=len(required_low), low_all_cases=len(complete_low), baseline_high=len(initial),
        strong_blocks=len(strong), physical_bad=len(bad), negative_controls=negative,
        resource=resource, catalogue_sha256=hashlib.sha256(catalog.read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        author_code_imported=False, archived_dispositions_only=True, solver_correctness_not_proved_by_ledger=True, C2_closed=False)
    dest = BASE / "independent_cross_package_coverage.json"
    need(not dest.exists(), "do not overwrite previous evidence")
    dest.write_text(json.dumps(result, indent=4), encoding="utf-8")
    print(result["status"], len(required_high), len(required_low), len(complete_low), negative)


if __name__ == "__main__":
    main()
