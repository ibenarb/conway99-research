"""Read-only acceptance of the completed low-rank replay, separate from author audit."""
from pathlib import Path
import hashlib
import json
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "proof_review_v1"))
sys.path.insert(0, str(BASE.parent / "C2_K4_Methodenpilot_20261117"))
from independent_cross_package_v1 import rows, value, need
from c2_shared_measurement_20261118_v1 import measure
from c2_serial_admission_core_20261118_v1 import identity
from h_portable_v1 import now

RUN = BASE / "full_replay_20261122_v1"
LOW = RUN / "evidence/low-simplex-packet"
FRESH = RUN / "evidence/low_build_and_evidence"
HIGH = BASE / "replay_pinned/even-simplex-packet"
UNSIGNED = BASE / "proof_review_v1/unsigned_full_replay_v2"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized(path):
    return [line.split(" cpu ")[0].strip() for line in path.read_text().splitlines() if line.strip()]


def table(path):
    output = {}
    for fields in rows(path):
        key = int(fields[0]), int(fields[1])
        need(key not in output, "duplicate case")
        output[key] = fields
    return output


def main():
    identities = []
    for run in (RUN, UNSIGNED):
        for filename in ("identity.json", "child_identity.json"):
            data = json.loads((run / filename).read_text())
            need(identity(data["process"]["pid"]) == data["process"], "process identity changed")
            identities.append(data["process"])
    resource = measure()
    manifests = {}
    for packet in (LOW, HIGH, BASE / "proof_review_v1/unsigned_packet_v2/singleton-simplex-packet"):
        entries = {}
        for line in (packet / "MANIFEST.sha256").read_text().splitlines():
            digest, relative = line.split(maxsplit=1)
            path = (packet / relative.lstrip("*")).resolve()
            need(path.is_relative_to(packet.resolve()) and sha(path) == digest, "source manifest changed")
            entries[relative] = digest
        manifests[str(packet.relative_to(BASE))] = entries
    completion = json.loads((RUN / "evidence/low_full_completion.json").read_text())
    need(completion["status"] == "AUTHOR_FULL_LOW_REPLAY_PASS" and completion["cases"] == 94, "low receipt invalid")
    need(completion["audit_sha256"] == sha(RUN / "evidence/low_full_audit.txt"), "low audit hash")
    checked_files = {}
    for filename in ("unary.log", "independent-stars.tsv", "lowctrl.log", "hypctrl.log", "labels-check.log"):
        need(normalized(FRESH / filename) == normalized(LOW / "expected" / filename), "control/unary mismatch: " + filename)
        checked_files[filename] = sha(FRESH / filename)
    want = {}
    for filename in ("generic-low.tsv", "generic-low-1.tsv", "r9n.log", "r9line.log"):
        for key, row in table(LOW / "expected" / filename).items():
            need(key not in want, "duplicate archived baseline")
            want[key] = row
    truncated = {k for k, row in want.items() if value(row, "truncated") == 1}
    replaced = set()
    for filename in ("r9n-fallback.log", "r9line-fallback.log"):
        for key, row in table(LOW / "expected" / filename).items():
            need(key in truncated and key not in replaced, "unexpected fallback")
            want[key] = row
            replaced.add(key)
    need(replaced == truncated, "missing fallback")
    got = table(FRESH / "generic.log")
    need(set(got) == set(want) and len(got) == 94, "generic scope")
    for key, fields in got.items():
        need(value(fields, "open") == value(fields, "truncated") == 0, "open/truncated fresh generic")
        need(" ".join(fields).split(" cpu ")[0] == " ".join(want[key]).split(" cpu ")[0], "generic transcript mismatch")
    bare = {(int(i), int(p)): int(n) for i, p, n in rows(FRESH / "independent-stars.tsv")}
    expected_hyp = table(LOW / "expected/r9hyp.log")
    observed_hyp = table(FRESH / "hyp.log")
    need(set(observed_hyp) == set(expected_hyp) and len(observed_hyp) == 22, "hyperbolic scope")
    for key, fields in observed_hyp.items():
        need(value(fields, "open") == value(fields, "truncated") == 0, "open/truncated fresh hyperbolic")
        need(value(fields, "star") == bare[key], "incomplete star scope")
        if value(expected_hyp[key], "truncated") == 0:
            need(" ".join(fields).split(" cpu ")[0] == " ".join(expected_hyp[key]).split(" cpu ")[0], "hyperbolic transcript mismatch")
        else:
            need(key in ((333, 0), (333, 1)) and bare[key] == 10424, "unexpected former cap")
    for filename in ("generic.log", "hyp.log"):
        checked_files[filename] = sha(FRESH / filename)
    low_traces = {}
    for number in range(1, 112):
        file = RUN / "evidence/command_traces" / f"{number:05d}.json"
        trace = json.loads(file.read_text())
        need(trace["returncode"] == 0 and "error" not in trace, "failed low command")
        low_traces[file.name] = sha(file)
    record = dict(time=now(), status="FULL_LOW_REPLAY_SEPARATELY_ACCEPTED", full_low_cases=94,
        required_even_low_cases=88, independent_hyperbolic_cases=22,
        formerly_capped_scopes={"333/0":10424,"333/1":10424}, complete_non_timing_comparison=True,
        checked_files=checked_files, source_manifests=manifests, low_command_traces=low_traces,
        process_identities=identities, resource=resource, C2_closed=False, entire_chain_complete=False,
        solver_is_original=True, independent_acceptance_checker=True,
        pending=["Complete unsigned/Hamming prerequisite", "Complete all high-rank searches", "Final chain acceptance"],
        source_sha256=sha(Path(__file__)))
    output = BASE / "proof_review_v1/low_full_acceptance_20261122_0934_v1.json"
    need(not output.exists(), "preserve evidence")
    output.write_text(json.dumps(record, indent=4), encoding="utf-8")
    print(record["status"], 94, 22, record["formerly_capped_scopes"])


if __name__ == "__main__":
    main()
