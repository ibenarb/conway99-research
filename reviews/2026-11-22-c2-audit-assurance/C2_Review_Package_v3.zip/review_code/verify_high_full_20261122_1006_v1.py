"""Separate complete high-rank replay acceptance; no solver changes or C2 verdict."""
from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import sys
from independent_cross_package_v1 import high_receipts, need, rows, value

BASE = Path(__file__).resolve().parent
MX = BASE.parent
PACKET = MX / "replay_pinned/even-simplex-packet"
SF = PACKET / "unsigned15/sf-run"
RUN = MX / "full_replay_20261122_v1"
TRACES = RUN / "evidence/command_traces"


def read(p):
    return json.loads(p.read_text(encoding="utf-8"))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def clean(text):
    return [line.split(" cpu ")[0].strip() for line in text.splitlines() if line.strip()]


def expected(name):
    return clean((SF / name).read_text())


def linux_path(s):
    need(s.startswith("/mnt/c/"), "unexpected retained path")
    return Path("C:/" + s[len("/mnt/c/"):]).resolve()


def main():
    manifests = {}
    for line in (PACKET / "MANIFEST.sha256").read_text().splitlines():
        digest, relative = line.split(maxsplit=1)
        path = (PACKET / relative.lstrip("*")).resolve()
        need(path.is_relative_to(PACKET.resolve()) and not path.is_symlink(), "source path")
        need(sha(path) == digest and relative not in manifests, "source hash")
        manifests[relative] = digest
    preflight = read(RUN / "preflight.json")
    need(manifests == preflight["packet_hashes"] and len(manifests) == 49, "preflight packet binding")
    need(preflight["source_sha256"] == sha(MX / "run_full_replay_20261122_v1.py"), "wrapper changed")
    need(preflight["orchestration_sha256"] == sha(MX / "full_replay_retained_linux_20261122_v1.py"), "retained orchestration changed")
    initial, strong = rows(SF / "direct-initial.tsv"), rows(SF / "direct-strong.tsv")
    wanted = high_receipts(initial, strong)
    need((len(initial), len(strong), len(wanted)) == (3050, 286, 3156), "archived high coverage")
    rejected = []
    cases = [("missing", initial[1:], strong), ("duplicate", initial + initial[:1], strong)]
    for field in ("open", "truncated"):
        changed = [r[:] for r in initial]
        changed[0][changed[0].index(field) + 1] = "1"
        cases.append((field, changed, strong))
    changed = [r[:] for r in strong]
    changed[0][changed[0].index("range") + 1] = "1"
    cases.append(("range gap", initial, changed))
    for label, a, b in cases:
        try:
            need(high_receipts(a, b) == wanted, "case set differs")
        except ValueError:
            rejected.append(label)
        else:
            raise ValueError("negative control accepted: " + label)
    if "--self-check" in sys.argv:
        print("HIGH_ACCEPTANCE_PREPARATION_PASS", len(wanted), rejected)
        return
    need((RUN / "completion.json").exists(), "full replay not complete")
    done = read(RUN / "completion.json")
    need(done["status"] == "FULL_ORIGINAL_REPLAY_PASS" and done["exit_code"] == 0, "original replay failed")
    for stream in ("stdout", "stderr"):
        need(done[stream + "_sha256"] == sha(RUN / (stream + ".txt")), "completion log binding")
    inner = read(RUN / "evidence/full_completion.json")
    need(inner["status"] == "AUTHOR_FULL_LOW_AND_HIGH_REPLAY_PASS", "inner completion")
    need((RUN / "stdout.txt").read_text().rstrip().endswith("FULL_LOW_AND_HIGH_REPLAY_PASS"), "final marker")
    status = read(BASE / "review_status_v3.json")
    for evidence in status["evidence"]:
        need(sha(BASE / evidence["path"]) == evidence["sha256"], "accepted earlier evidence changed")
    by_program = {}
    trace_hashes = {}
    ids = []
    for file in sorted(TRACES.glob("*.json")):
        ids.append(int(file.stem))
        item = read(file)
        need(item.get("returncode") == 0 and "error" not in item, "command failure")
        trace_hashes[file.name] = sha(file)
        for suffix in ("stdin", "stdout", "stderr"):
            extra = file.with_suffix("." + suffix)
            if extra.exists():
                trace_hashes[extra.name] = sha(extra)
        if int(file.stem) <= 111:
            continue
        cmd = item["command"]
        program = cmd[0].split("/")[-1]
        by_program.setdefault(program, []).append((file, item))
    need(ids == list(range(1, len(ids) + 1)), "missing command trace")
    def output(entry):
        return clean(entry[0].with_suffix(".stdout").read_text())
    baseline = by_program.get("srerun", [])
    need(len(baseline) == 1 and baseline[0][1]["command"][1:] == ["0"], "baseline command scope")
    got_initial = output(baseline[0])
    need(got_initial == expected("direct-initial.tsv"), "baseline transcript")
    request = clean(baseline[0][0].with_suffix(".stdin").read_text())
    need(request == [" ".join((r[0], r[1], str(value(r, "mode")))) for r in initial], "baseline input coverage")
    got_strong, strong_commands = [], []
    for entry in by_program.get("sstrong-range", []):
        lines = output(entry)
        need(len(lines) == 1, "strong transcript length")
        r = lines[0].split()
        args = [r[0], r[1], str(value(r, "mode")), str(value(r, "range")), r[r.index("range") + 2]]
        need(entry[1]["command"][1:] == args, "strong command binding")
        got_strong.extend(lines)
        strong_commands.append(tuple(args))
    need(len(got_strong) == 286 and len(set(strong_commands)) == 286, "strong block coverage")
    need(Counter(got_strong) == Counter(expected("direct-strong.tsv")), "strong transcripts")
    need(high_receipts([r.split() for r in got_initial], [r.split() for r in got_strong]) == wanted, "fresh high coverage")
    star = by_program.get("sstar", [])
    need(len(star) == 1 and star[0][1]["command"][1:] == ["0", "3580"], "unary scope")
    need(output(star[0]) == expected("star.tsv"), "unary transcript")
    for program, filename in (("shighctrl", "shighctrl.log"), ("shighcaps", "shighcaps.log"), ("srealctrl", "realctrl.log")):
        entries = by_program.get(program, [])
        need(len(entries) == 1 and output(entries[0]) == expected(filename), "control mismatch " + program)
    for program, names in (("sref-range", ["even-ref-small.log", "high-literal.log"]), ("sref-depth", ["high-ref-positive.log"])):
        fresh_reference = [line for e in by_program.get(program, []) for line in output(e)]
        need(Counter(fresh_reference) == Counter(line for name in names for line in expected(name)), "scalar reference mismatch")
    for i in (0, 1, 11):
        for p in (0, 1):
            a = [e for e in by_program["sorbit-fast"] if e[1]["command"][1:] == [str(i), str(p)]]
            b = [e for e in by_program["strong-roster"] if e[1]["command"][1:] == [str(i), str(p), "0", "0", "1000000000"]]
            need(len(a) == len(b) == 1 and output(a[0]) == output(b[0])[:-1], "terminal orbit transport")
    scratch = linux_path(baseline[0][1]["command"][0]).parent.parent
    need(scratch.is_relative_to((RUN / "scratch").resolve()), "scratch path")
    for relative, digest in manifests.items():
        name = relative.removeprefix("./")
        if name.endswith((".cpp", ".hpp")):
            need(sha(scratch / name) == digest, "copied mathematical source differs")
    record = dict(time=datetime.now(ZoneInfo("Europe/Berlin")).isoformat(), status="FULL_HIGH_REPLAY_SEPARATELY_ACCEPTED", high_jobs=3156, baseline_jobs=3050, strong_blocks=286, strong_jobs=106, complete_non_timing_comparison=True, finite_controls_checked=True, scalar_references_checked=True, terminal_orbit_transports=6, source_manifests=manifests, trace_hashes=trace_hashes, completion_sha256=sha(RUN / "completion.json"), earlier_review_sha256=sha(BASE / "review_status_v3.json"), negative_controls=rejected, source_sha256=sha(Path(__file__)), solver_is_original=True, independent_acceptance_checker=True, C2_closed=False, pending=["Final mathematical dependency-chain acceptance and scope reconciliation"])
    with (BASE / "high_full_acceptance_20261122_1006_v1.json").open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=4)
    print(record["status"], record["high_jobs"], record["strong_blocks"])


if __name__ == "__main__":
    main()
