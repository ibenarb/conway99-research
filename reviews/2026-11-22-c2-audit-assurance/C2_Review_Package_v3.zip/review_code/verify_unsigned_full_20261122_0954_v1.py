"""Independent acceptance of frozen original unsigned replay; never a C2 verdict."""
from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import math
import sys

BASE = Path(__file__).resolve().parent
PACKET = BASE / "unsigned_packet_v2/singleton-simplex-packet"
U = PACKET / "unsigned15"
FRESH = U / "replay-out"
RUN = BASE / "unsigned_full_replay_v2"
OUTPUT = BASE / "unsigned_full_acceptance_20261122_0954_v1.json"


def need(condition, message):
    if not condition:
        raise ArithmeticError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def parse(text):
    result = {}
    for line in text.splitlines():
        row = line.split()
        need(len(row) >= 2, "empty or truncated row")
        index = int(row[0])
        need(index not in result, "duplicate chart")
        if row[1] == "bad":
            need(len(row) == 2, "invalid bad row")
        else:
            need(len(row) > 4 and row[-2] == "cpu", "missing timing terminator")
            elapsed = float(row[-1])
            need(math.isfinite(elapsed) and elapsed >= 0, "invalid time")
            row = row[:-2]
        result[index] = tuple(row)
    return result


def table(path):
    return parse(path.read_text(encoding="utf-8"))


def field(row, name):
    need(row.count(name) == 1, "missing/duplicate field " + name)
    return int(row[row.index(name) + 1])


def compare(got, expected):
    need(set(got) == set(expected), "incomplete or extra chart coverage")
    need(got == expected, "non-timing transcript differs")


def controls(expected):
    first = min(expected)
    cases = {}
    changed = dict(expected)
    del changed[first]
    cases["missing"] = lambda: compare(changed, expected)
    extra = dict(expected)
    extra[3580] = expected[first]
    cases["extra"] = lambda: compare(extra, expected)
    altered = dict(expected)
    r = list(altered[first])
    r[r.index("good") + 1] = "1"
    altered[first] = tuple(r)
    cases["open"] = lambda: compare(altered, expected)
    cases["duplicate"] = lambda: parse("0 bad\n0 bad\n")
    cases["truncated"] = lambda: parse("0 r 7 good 0\n")
    rejected = []
    for name, action in cases.items():
        try:
            action()
        except ArithmeticError:
            rejected.append(name)
        else:
            raise ArithmeticError("acceptance control failed: " + name)
    compare(expected, expected)
    return rejected


def main():
    manifests = {}
    for line in (PACKET / "MANIFEST.sha256").read_text().splitlines():
        digest, relative = line.split(maxsplit=1)
        path = (PACKET / relative.lstrip("*")).resolve()
        need(path.is_relative_to(PACKET.resolve()) and not path.is_symlink(), "source path")
        need(sha(path) == digest and relative not in manifests, "source hash or duplicate")
        manifests[relative] = digest
    need(manifests == read(RUN / "preflight.json")["hashes"], "preflight source binding")
    bound = read(RUN / "identity.json")
    need(bound["source_sha256"] == sha(BASE / "run_unsigned_full_v2.py"), "wrapper binding")
    need(bound["command"][-3:] == ["bash", "replay.sh", "full"], "not full command")
    even, odd = table(U / "expected/even.log"), table(U / "expected/odd.log")
    need(set(even) == set(range(0, 3580, 2)), "even coverage")
    need(set(odd) == set(range(1, 3580, 2)), "odd coverage")
    expected = even | odd
    rejected = controls(expected)
    if "--self-check" in sys.argv:
        print("UNSIGNED_ACCEPTANCE_PREPARATION_PASS", len(expected), rejected)
        return
    need((RUN / "completion.json").exists(), "original replay has not completed")
    completion = read(RUN / "completion.json")
    need(completion["status"] == "ORIGINAL_UNSIGNED_FULL_REPLAY_PASS" and completion["exit_code"] == 0, "original replay error")
    for name in ("stdout", "stderr"):
        need(completion[name + "_sha256"] == sha(RUN / (name + ".txt")), "completion transcript binding")
    need((RUN / "stdout.txt").read_text().rstrip().endswith("All required checks passed in full mode."), "missing final message")
    fresh = table(FRESH / "first.log")
    compare(fresh, expected)
    expected_pair, pairs = table(U / "expected/pair.tsv"), table(FRESH / "pair.log")
    compare(pairs, expected_pair)
    opens = {i for i, r in fresh.items() if r[1] != "bad" and field(r, "good") > 0}
    need(opens == set(pairs) == {183, 3377}, "pair exception coverage")
    for index, row in pairs.items():
        need(field(row, "good") == 0, "pair remains open")
        for name in ("r", "group", "orbits", "g", "z", "p", "retained"):
            need(field(row, name) == field(fresh[index], name), "pair prefix binding")
    artifacts = {"layouts.tsv": PACKET / "dualplanes/unary5-packet/layouts.tsv", "code15.tsv": U / "code15.tsv", "code7e8.tsv": U / "code7e8.tsv"}
    for name in ("rootedges.txt", "fixture-counts.txt", "audit.tsv", "controls.txt"):
        artifacts[name] = U / "expected" / name
    checked_files = {}
    for name, expected_path in artifacts.items():
        need((FRESH / name).read_bytes() == expected_path.read_bytes(), "fresh artifact differs: " + name)
        checked_files[name] = sha(FRESH / name)
    audit = {}
    for line in (FRESH / "audit.tsv").read_text().splitlines():
        row = line.split()
        index = int(row[0])
        need(index not in audit, "duplicate audit")
        audit[index] = row[1:]
    need(set(audit) == set(fresh), "audit coverage")
    for index, row in fresh.items():
        if row[1] == "bad":
            need(audit[index] == ["bad"], "bad audit mismatch")
        else:
            need(audit[index] == [str(field(row, n)) for n in ("r", "group", "orbits", "g", "z", "p")], "audit mismatch")
            need(field(row, "z") + field(row, "p") >= field(row, "retained"), "Schur mismatch")
    atlas = [l.split() for l in (FRESH / "code7e8.tsv").read_text().splitlines()]
    need(len(atlas) == 88, "mixed atlas size")
    retained = set()
    for j, row in enumerate(atlas):
        need(len(row) == 24 and tuple(map(int, row[:2])) == divmod(j, 8), "mixed atlas scope")
        need(int(row[2]) in (0, 1, 2), "mixed status")
        if row[2] == "2":
            retained.add(tuple(map(int, row[:2])))
    need(retained == {(i, o) for i in (3, 5, 6, 7, 8, 9, 10) for o in range(8)}, "mixed atlas retained coverage")
    for name in ("first.log", "pair.log"):
        checked_files[name] = sha(FRESH / name)
    record = dict(time=datetime.now(ZoneInfo("Europe/Berlin")).isoformat(), status="FULL_UNSIGNED_REPLAY_SEPARATELY_ACCEPTED", first_layer_cases=3580, pair_cases=sorted(pairs), bad_charts=sum(r[1] == "bad" for r in fresh.values()), mixed_atlas_cases=88, retained_mixed_cases=56, complete_non_timing_comparison=True, original_replay_receipt_sha256=sha(RUN / "completion.json"), source_manifests=manifests, checked_files=checked_files, acceptance_negative_controls=rejected, process_identity_record_sha256=sha(RUN / "identity.json"), child_identity_record_sha256=sha(RUN / "child_identity.json"), source_sha256=sha(Path(__file__)), solver_is_original=True, independent_acceptance_checker=True, C2_closed=False, entire_chain_complete=False, pending=["Full high-rank replay", "Final chain acceptance"])
    with OUTPUT.open("x", encoding="utf-8") as output:
        json.dump(record, output, indent=4)
    print(record["status"], record["first_layer_cases"], record["pair_cases"])


if __name__ == "__main__":
    main()
