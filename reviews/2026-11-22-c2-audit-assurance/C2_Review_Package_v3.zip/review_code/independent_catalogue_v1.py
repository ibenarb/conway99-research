"""Independent catalogue coverage: enumerate the entire signed permutation group.
No author module is imported; only the frozen list is read.
"""
from collections import Counter, defaultdict
from itertools import permutations, product, combinations
from pathlib import Path
import hashlib
import json
import sys
import time

BASE = Path(__file__).resolve().parent
CAT = BASE / "unsigned_packet/singleton-simplex-packet/dualplanes/unary5-packet/layouts.tsv"
PILOT = BASE.parent.parent / "C2_K4_Methodenpilot_20261117"
sys.path.insert(0, str(PILOT))
from c2_shared_measurement_20261118_v1 import measure

def matchings(points):
    if not points:
        yield ()
    else:
        a, *remaining = points
        for b in remaining:
            for tail in matchings(tuple(x for x in remaining if x != b)):
                yield ((a, b),) + tail

def partitions(n, least=1):
    if n == 0:
        yield ()
    else:
        for a in range(least, n + 1):
            for tail in partitions(n - a, a):
                yield (a,) + tail

def component_partition(p):
    unseen = set(range(12))
    sizes = []
    while unseen:
        todo = [min(unseen)]
        component = set()
        while todo:
            x = todo.pop()
            if x in component:
                continue
            component.add(x)
            todo.extend([x ^ 1, p[x]])
        unseen -= component
        assert len(component) % 2 == 0
        sizes.append(len(component) // 2)
    return tuple(sorted(sizes))

def bad_physical(p, n):
    neighbors = [set() for _ in range(39)]
    def edge(a, b):
        assert a != b
        neighbors[a].add(b)
        neighbors[b].add(a)
    for axis in range(7):
        plus, minus = 1 + 2 * axis, 2 + 2 * axis
        edge(0, plus)
        edge(0, minus)
        edge(plus, minus)
    for label in range(12):
        for sign in range(2):
            node = 15 + 2 * label + sign
            edge(node, 1 + sign)
            edge(node, 3 + 2 * (label // 2) + (sign ^ (label % 2)))
            edge(node, 15 + 2 * p[label] + sign)
            edge(node, 15 + 2 * n[label] + (sign ^ 1))
    return any(len(neighbors[a] & neighbors[b]) > 2 - int(b in neighbors[a])
        for a, b in combinations(range(39), 2))

def main():
    out = BASE / "independent_catalogue_coverage.json"
    assert not out.exists()
    resource = measure()
    assert resource["ram_free_gib"] >= 10 and resource["disk_free_gib"] >= 35
    assert max(row["system_busy_cpu"] for row in resource["intervals"]) + 1 <= 20
    start = time.monotonic()
    rows = [list(map(int, line.split())) for line in CAT.read_text().splitlines()]
    grouped = defaultdict(list)
    for index, row in enumerate(rows):
        assert len(row) == 25
        p, n = tuple(row[1:13]), tuple(row[13:])
        assert all(v[v[i]] == i and v[i] != i for v in (p, n) for i in range(12))
        grouped[p].append((index, n))
    parts = {component_partition(p) for p in grouped}
    assert len(grouped) == len(parts) == 11 and parts == set(partitions(6))
    all_n = set()
    for pairs in matchings(tuple(range(12))):
        n = [None] * 12
        for a, b in pairs:
            n[a], n[b] = b, a
        all_n.add(tuple(n))
    assert len(all_n) == 10395
    signed = [tuple(2 * q[i // 2] + ((i % 2) ^ flips[i // 2]) for i in range(12))
        for q in permutations(range(6)) for flips in product(range(2), repeat=6)]
    assert len(set(signed)) == 46080
    certificates = []
    for p, entries in grouped.items():
        stabilizer = [g for g in signed if all(g[p[i]] == p[g[i]] for i in range(12))]
        covered = set()
        orbit_sizes = []
        for index, n in entries:
            orbit = set()
            for g in stabilizer:
                transported = [None] * 12
                for i in range(12):
                    transported[g[i]] = g[n[i]]
                orbit.add(tuple(transported))
            assert orbit <= all_n and not (orbit & covered)
            assert len(stabilizer) % len(orbit) == 0
            covered |= orbit
            orbit_sizes.append(len(orbit))
        assert covered == all_n
        certificates.append(dict(partition=component_partition(p), stabilizer_order=len(stabilizer),
            charts=len(entries), orbit_sizes=orbit_sizes, union_size=len(covered)))
    bad = [i for i, row in enumerate(rows) if bad_physical(tuple(row[1:13]), tuple(row[13:]))]
    assert len(rows) == 3580 and len(bad) == 272
    result = dict(status="INDEPENDENT_FULL_GROUP_CATALOGUE_COVERAGE_PASS", chart_count=len(rows),
        matching_count=10395, signed_group_order=46080, physical_bad_count=len(bad),
        physical_bad_ids=bad, partitions=certificates, elapsed_seconds=time.monotonic()-start,
        catalogue_sha256=hashlib.sha256(CAT.read_bytes()).hexdigest(),
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        resource=resource, author_code_imported=False, C2_closed=False)
    out.write_text(json.dumps(result, indent=4), encoding="utf-8")
    print(result["status"], "3580 charts, all 11 x 10395 matchings covered disjointly;", len(bad), "bad physical bases")

if __name__ == "__main__":
    main()
