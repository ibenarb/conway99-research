"""Independent literal 51-vertex replay of published four-lift witnesses.
No author module, projected Schur test, or cached product mask is used.
Completeness of these witnesses and their domains remains a separate obligation.
"""
from collections import Counter
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
from independent_cross_package_v1 import measure, mod_rank, need

BASE = Path(__file__).resolve().parent
SUPPLEMENT = BASE / "optional_four_lifts/singleton-terminal-supplement"
CATALOG = BASE.parent / "replay_pinned/even-simplex-packet/dualplanes/unary5-packet/layouts.tsv"
LABELS = [(i, j, twist) for i, j in combinations(range(7), 2) for twist in range(2)]


def reconstruct(chart, additions, heavy_links, extra_links, final_link=None):
    row = list(map(int, CATALOG.read_text().splitlines()[chart].split()))
    p, n = row[1:13], row[13:]
    labels = LABELS[:12] + [LABELS[12 + v[0]] for v in additions]
    count = len(labels)
    unsigned = [[0] * count for _ in range(count)]
    signed = [[0] * count for _ in range(count)]
    def set_link(a, b, t, l):
        need(a != b and (t, l) in ((0, 0), (1, 1), (1, -1), (2, 0)), "invalid edge")
        unsigned[a][b] = unsigned[b][a] = t
        signed[a][b] = signed[b][a] = l
    for a, b in combinations(range(12), 2):
        set_link(a, b, int(p[a] == b) + int(n[a] == b), int(p[a] == b) - int(n[a] == b))
    for idx, (_, plus, minus, *_) in enumerate(additions, 12):
        for a in range(12):
            x, y = (plus >> a) & 1, (minus >> a) & 1
            set_link(idx, a, x + y, x - y)
    for (a, b), (t, l) in zip(((a, b) for a in range(4) for b in range(a)), heavy_links):
        set_link(12 + a, 12 + b, t, l)
    for idx, links in enumerate(extra_links, 16):
        for a, (t, l) in enumerate(links, 12):
            set_link(idx, a, t, l)
    if final_link is not None:
        set_link(16, 17, *final_link)
    adjacency = [set() for _ in range(15 + 2 * count)]
    def edge(a, b):
        need(a != b, "loop")
        adjacency[a].add(b)
        adjacency[b].add(a)
    for i in range(7):
        edge(0, 1 + 2 * i)
        edge(0, 2 + 2 * i)
        edge(1 + 2 * i, 2 + 2 * i)
    for idx, (a, b, twist) in enumerate(labels):
        for sign in range(2):
            edge(15 + 2 * idx + sign, 1 + 2 * a + sign)
            edge(15 + 2 * idx + sign, 1 + 2 * b + (sign ^ twist))
    for a, b in combinations(range(count), 2):
        t, l = unsigned[a][b], signed[a][b]
        for x, y in product(range(2), repeat=2):
            if t == 2 or (t == 1 and x ^ y == int(l < 0)):
                edge(15 + 2 * a + x, 15 + 2 * b + y)
    offending = next(((a, b, len(adjacency[a] & adjacency[b])) for a, b in combinations(range(len(adjacency)), 2)
        if len(adjacency[a] & adjacency[b]) > (1 if b in adjacency[a] else 2)), None)
    z = [[int(k == a) + (1 - 2 * twist) * int(k == b) for k in range(7)] for a, b, twist in labels]
    gram = [[12 * int(a == b) - 4 * signed[a][b] - sum(x * y for x, y in zip(z[a], z[b])) for b in range(count)] for a in range(count)]
    rank = mod_rank(gram)
    return dict(vertices=len(adjacency), rank7=rank, physical_witness=offending,
        rejection="physical" if offending else ("rank7" if rank > 13 else None))


def main():
    resource = measure()
    need(resource["ram_free_gib"] >= 10 and resource["disk_free_gib"] >= 35, "resource reserve")
    need(max(r["system_busy_cpu"] for r in resource["intervals"]) + 1 <= 20, "CPU reserve")
    manifest = {}
    for line in (SUPPLEMENT / "MANIFEST.sha256").read_text().splitlines():
        expected, relative = line.split(maxsplit=1)
        file = (SUPPLEMENT / relative).resolve()
        need(file.is_relative_to(SUPPLEMENT.resolve()), "unsafe manifest path")
        need(hashlib.sha256(file.read_bytes()).hexdigest() == expected, "manifest hash")
        manifest[relative] = expected
    cases = []
    for line in (SUPPLEMENT / "unsigned15/expected/case-witnesses.tsv").read_text().splitlines():
        tag, *fields = line.split()
        if tag == "case":
            chart, lift, mask, rank, *data = map(int, fields)
            current = dict(chart=chart, lift=lift, sign_mask=mask, base_rank=rank,
                heavy=[data[k:k+3] for k in range(0, 12, 3)],
                links=[data[k:k+2] for k in range(12, 24, 2)], small={})
            cases.append(current)
        elif tag == "domains":
            current["domains"] = {int(a): int(b) for a, b in (x.split(":") for x in fields)}
        elif tag == "small":
            data = list(map(int, fields))
            current["small"].setdefault(data[0], []).append(data)
    need([(c["chart"], c["lift"]) for c in cases] == [(183, 1), (183, 2), (3377, 1), (3377, 2)], "case identity")
    results = []
    for case in cases:
        need(len(case["domains"]) == 26 and len(case["small"]) == 2, "domain count")
        need(all(len(v) == case["domains"][k] for k, v in case["small"].items()), "small domain count")
        base = reconstruct(case["chart"], case["heavy"], case["links"], [])
        need(base["rejection"] is None and base["rank7"] == 11 and base["vertices"] == 47, "base positive control")
        counts, details = Counter(), []
        for x, y in product(*case["small"].values()):
            extra = [[v[k:k+2] for k in range(3, 11, 2)] for v in (x, y)]
            for link in ((0, 0), (1, 1), (1, -1), (2, 0)):
                checked = reconstruct(case["chart"], case["heavy"] + [x, y], case["links"], extra, link)
                need(checked["vertices"] == 51 and checked["rejection"] is not None, "compatible pair exists")
                counts[checked["rejection"]] += 1
                details.append(dict(x=x, y=y, link=link, **checked))
        need(dict(counts) == ({"physical": 6, "rank7": 10} if case["chart"] == 183 else {"physical": 4}), "unexpected result")
        results.append(dict(chart=case["chart"], lift=case["lift"], base_positive_control=base, counts=dict(counts), details=details))
    record = dict(status="INDEPENDENT_LITERAL_FOUR_LIFTS_PASS", results=results, resource=resource,
        manifest=manifest, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        author_code_imported=False, witness_domain_completeness_independently_proved=False, C2_closed=False)
    out = BASE / "independent_literal_four_lifts.json"
    need(not out.exists(), "preserve previous evidence")
    out.write_text(json.dumps(record, indent=4), encoding="utf-8")
    print(record["status"], [(r["chart"], r["lift"], r["counts"]) for r in results])


if __name__ == "__main__":
    main()
