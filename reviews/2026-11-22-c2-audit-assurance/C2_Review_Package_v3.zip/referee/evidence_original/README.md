# Referee evidence for the C2 review of 22 November 2026

Independent checks written for the referee report on "Excluding involutions in a strongly regular graph
with parameters (99,14,1,2)" (review dossier v1, frozen source `mxym/math` d73a176). Nothing here imports or
copies code from the frozen packets or from the dossier. Inputs taken from the frozen packets are named
explicitly (the list of 3,580 chart representatives `layouts.tsv`, and result ledgers used for comparison only).

Environment: Linux 6.18, 2 vCPU Intel Xeon 2.1 GHz, GCC 13.3.0, Python 3.13.18, numpy, scipy 1.18 (LP only),
PARI 2.15.4 through `cypari` (lattice reduction, short vectors, `qfauto`, `qfisom`).

## 1. Catalogue and coverage (manuscript section 6)

| File | Content |
|---|---|
| `catalogue.py`, `catalogue_own.json` | all orbits of ordered pairs (P,N) of perfect matchings on 12 labels under the group of order 46,080 (explicit orbits and Burnside): 3,580; rank of F_A mod 7: 3, 5, 97, 637, 2,838; literal 39-vertex check: 272 invalid; noncollapsed degree: 1, 4, 11, 70, 362, 3,132 charts for degrees 0, 2, 3, 4, 5, 6 |
| `layouts_check.py`, `id_map_author_to_own.json` | the frozen `layouts.tsv` contains exactly one representative of each of my 3,580 orbits (canonical form = lexicographic minimum over the whole group); rank column agrees |
| `geometry.py`, `geometry_own.json`, `geometry_own.txt` | 168 circuits, 28 cosets of six, the K8 structure on the cosets, GL(4,2) induces exactly the 20,160 even permutations; the two label parities |
| `star_own.cpp`, `star_own.out`, `star_counts_own.json` | number of sign-normalised 12-word star assignments realising H_A, for all 3,580 charts and both parities |
| (comparison, in the report) | zero/non-zero status equals the frozen `star.tsv` on all 6,616 physical chart-parities; even degree: 476 physical + 3,212 without any star + 88 low rank + 2,638 high rank = 6,414; high rank by (degree, rank): (0,11) 2, (2,11) 4, (4,10) 10, (4,11) 52, (6,10) 508, (6,11) 2,062, i.e. 3,156 jobs with the two modes at rank 10; low-rank survivors 2 + 6 + 86; pivot determinant: rank 7 square, rank 9: 64 nonsquare and 22 square. My parity label is the opposite of the packet's. |
| `fixed_points.py` | an involution fixes exactly one vertex: the only solution is (f, n, e, p, d0) = (1, 49, 7, 0, 42) |
| `small_checks.py` | D12+ classes (992/1024/1056/1024; 7,944 vectors cover 991 classes), rational packing gaps, Gaussian binomials |

## 2. The lattice step without packing bounds (manuscript sections 4 and 5.1)

L0 is an integral lattice of rank 15 and determinant 2^8 with L0*/L0 = (Z/2)^8 and integral norms on L0*.
Every such lattice is {v in V : (v,c) even for c in C} for a unimodular V and a 4-dimensional subspace C of V/2V
on which the norm vanishes modulo 4; conversely each pair (V,C) gives such a lattice. Counting pairs both ways:

    sum over classes of 1/|Aut(L0)|  =  N * m15 / 2295,

N = 3,876,193,035 (totally singular 4-subspaces of the O+_14(2) space V/2V; also counted directly for Z^15),
2295 = number of Lagrangians of the alternating form on L0*/L0, m15 = 29713/385648863215616000 = mass of the five
unimodular lattices of rank 15. Target mass: 116980081/898948399104000.

| File | Content |
|---|---|
| `genus_lib.py`, `genus_step1.py`, `unimodular15.json` | the five unimodular lattices of rank 15, automorphism orders by `qfauto` equal the known orders |
| `codes15.py`, `codes15_own.json` | all doubly-even 4-dimensional codes of length 15: 10,064 labelled multiplicity vectors, 20 types; N from the codes equals the formula |
| `genus_step2.py`, `genus_step3.py`, `genus_classes.json`, `code_class.json` | 20 classes from Z^15, 11 further classes from Z^7+E8, none new from the other three; **exact equality with the target mass, 31 classes** |
| `genus_step4.py`, `genus_atlas.json` | per class: X = L0/2L0*, its 28 classes of norm 2 as edges of K8, root lines per K8 vertex, dual units, admissible norm-5 vectors (pairing at most 1 with every dual unit), and for each of the 8 geometries the test "two vectors in each of the 21 required classes, every dual unit met by exactly 14" |
| `genus_step5.py`, `genus_farkas.json` | every LP-infeasible geometry has an exact integer Farkas certificate (46 of 46) |

Result: every class has seven pairwise orthogonal dual units (so equation (11) of the manuscript holds without
the packing step); 168 of the 248 (class, geometry) pairs are excluded (122 by an empty class, 46 by certificate);
the 80 survivors are all eight geometries of ten classes: the Hamming lattice, two further Z^15 classes with 4 and 2
root lines at every K8 vertex, and seven Z^7+E8 classes with 4, 3, 5, 2, 1, 3, 7. These are the numbers of the frozen
`rootedges.txt`.

## 3. Automorphism pruning and an independent solver (manuscript sections 6.6 to 6.8)

| File | Content |
|---|---|
| `orbit_groups.py`, `orbit_groups.txt`, `orbit_own.cpp`, `orbit_own.out`, `reps/` | my own chart automorphisms (even peripheral permutations with my own GL(4,2) lifts, and switches) acting on raw star assignments, for all 49 charts of strong jobs and both parities: group order and number of orbits; one representative per orbit |
| `own_local.py`, `own_rank7.py` | own local model (base graph, attachments with literal 41-vertex capacities, both Schur tests in exact rationals, pivot data mod 7, words); rank 7: chart 288, both parities, 688 stars each, no star and no 2-plane of F_7^4 leaves all 30 labels a candidate |
| `own_pair.py` | reference implementation of my pairwise solver (searches all 30 labels; exact rational Cauchy; literal 43-vertex capacities) |
| `own_setup.py`, `own_pair.cpp`, `own_pair2.cpp` | fast setup and C++ port; `own_pair2` adds my own normalisation of the first non-zero residual vector under the isometries fixing the residual anchor. The port reproduces the Python node, arc and rejection counts exactly on chart 0 |
| `pair_*.out`, `sample_jobs.py`, `sample_results.tsv`, `sample_strong.py`, `sample_strong_results.tsv` | results: terminal charts with orbit representatives; seeded random samples of baseline jobs (all raw stars) and of strong jobs of degree 4 (orbit representatives) |

## 4. Replays of the frozen packets on this machine (`replays/`)

`unsigned_full.*`: `bash replay.sh full` of the unsigned-simplex packet; `first.log`, `pair.log` and the other
outputs. `main/main_full_first_attempt.stdout`: `FULL_LOW=1 JOBS=2 python3 -B replay.py full` of the even-axis packet. It passed the manifest, both audits, the complete low-rank replay, the finite controls, the orbit transports, the scalar references, the literal rows and the star ledger; the machine was then restarted while the baseline rows were running. `main/high_driver.py` reran the last stage with the unmodified sources and the same commands, saving every row: `high_baseline_shard*.tsv` (3,050 rows) and `high_strong_blocks.tsv` (286 blocks); `high_rerun_comparison.txt`: all 3,336 equal the frozen ledgers apart from timing.
`main/orbit_audit_all.log`: the packet's own `sorbit-fast` and `seven-orbit` run on all 49 strong charts.
`main/uniform_check.txt`: `uniform-shards.py check` on the author's three uniform-replay transcripts.
`packing/`: outputs of the Taylor and Bernstein verifiers on `n014.json`, `n015.json`.
