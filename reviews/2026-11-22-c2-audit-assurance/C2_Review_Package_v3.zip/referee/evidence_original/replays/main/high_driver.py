# Restartable rerun of the high-rank rows of the frozen even-axis packet (unmodified sources, same commands as replay.py full):
#   baseline: srerun 0 on the keys of direct-initial.tsv;  strong: sstrong-range on every row of direct-strong.tsv.
# Each finished row is appended to disk at once, so an interruption loses at most the row in progress.
import subprocess, sys, os
W = '/home/claude/replay/high/unsigned15'; S = W + '/sf-run'
first = open(S + '/direct-initial.tsv').read().strip().splitlines(); strong = open(S + '/direct-strong.tsv').read().strip().splitlines()
def key(w): return [w[0], w[1], w[3]]
shard = int(sys.argv[1]); J = 2
rows = first[shard::J]; outp = f'{W}/out/base.{shard}.tsv'
done = len(open(outp).read().splitlines()) if os.path.exists(outp) else 0
if done < len(rows):
    buf = ''.join(' '.join(key(s.split())) + '\n' for s in rows[done:])
    with open(outp, 'a') as fo: subprocess.run([W + '/bin/srerun', '0'], cwd=W, input=buf, text=True, stdout=fo, check=True)
for i, line in enumerate(strong):
    if i % J != shard: continue
    op = f'{W}/out/strong.{i:03d}.tsv'
    if os.path.exists(op) and open(op).read().strip(): continue
    w = line.split(); a = w.index('range')
    r = subprocess.run([W + '/bin/sstrong-range', *key(w), *w[a + 1:a + 3]], cwd=W, capture_output=True, text=True, check=True)
    open(op, 'w').write(r.stdout)
open(f'{W}/out/done.{shard}', 'w').write('done\n')
