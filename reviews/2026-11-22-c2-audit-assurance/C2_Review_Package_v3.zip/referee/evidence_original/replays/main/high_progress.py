import os, glob
W='/home/claude/replay/high/unsigned15'; S=W+'/sf-run'
first=open(S+'/direct-initial.tsv').read().strip().splitlines(); strong=open(S+'/direct-strong.tsv').read().strip().splitlines()
clean=lambda s: s.split(' cpu ')[0].strip()
cpu=lambda s: float(s.split(' cpu ')[1])
tot=sum(map(cpu,first))+sum(map(cpu,strong)); done=0; ok=0; bad=0; nrows=0
for sh in (0,1):
    p=f'{W}/out/base.{sh}.tsv'
    if not os.path.exists(p): continue
    got=open(p).read().splitlines(); exp=first[sh::2]
    for g,e in zip(got,exp):
        if ' cpu ' not in g: continue
        nrows+=1; done+=cpu(e)
        if clean(g)==clean(e): ok+=1
        else: bad+=1; print('MISMATCH',g[:80],'|',e[:80])
ns=0
for i,e in enumerate(strong):
    p=f'{W}/out/strong.{i:03d}.tsv'
    if os.path.exists(p) and open(p).read().strip():
        ns+=1; done+=cpu(e); g=open(p).read().strip()
        if clean(g)==clean(e): ok+=1
        else: bad+=1; print('MISMATCH strong',i)
print(f'baseline rows {nrows}/3050, strong blocks {ns}/286, identical apart from timing {ok}, different {bad}, progress by recorded cost {100*done/tot:.1f}%')
