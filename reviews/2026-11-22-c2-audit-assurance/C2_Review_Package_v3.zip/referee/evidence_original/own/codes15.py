# Own enumeration of doubly-even binary codes of dimension 4 and length 15 (zero columns allowed).
# A generator matrix up to column permutation = multiplicities m_v (v in F_2^4), sum 15.
# Weight of the word lambda: w_l = sum_{v: l.v=1} m_v, must be in {4,8,12}.  Inversion: m_v = -(1/8) sum_l (-1)^{l.v} w_l (v != 0).
import itertools, json, numpy as np
from math import factorial
par = np.array([[bin(l & v).count('1') & 1 for v in range(16)] for l in range(16)])
sgn = 1 - 2 * par          # (-1)^{l.v}
sols = []
vals = np.array([4, 8, 12])
first = np.array(list(itertools.product(vals, repeat=7)))          # w_1..w_7
second = np.array(list(itertools.product(vals, repeat=8)))         # w_8..w_15
A1 = first @ sgn[1:8, 1:].astype(np.int64)                         # contribution to -8 m_v
A2 = second @ sgn[8:16, 1:].astype(np.int64)
for i in range(len(first)):
    tot = A1[i][None, :] + A2                                     # = -8 m_v
    ok = (tot <= 0).all(axis=1) & (tot % 8 == 0).all(axis=1)
    if ok.any():
        m = (-tot[ok] // 8)
        keep = m.sum(axis=1) <= 15
        for row in m[keep]:
            sols.append([15 - int(row.sum())] + [int(x) for x in row])
print('labelled multiplicity vectors:', len(sols))
# check weights directly
for m in sols:
    for l in range(1, 16):
        w = sum(m[v] for v in range(16) if par[l][v]); assert w in (4, 8, 12)
# orbits under GL(4,2) acting on column labels
def gl():
    for b in itertools.permutations(range(1, 16), 4):
        f = [0]; ok = True
        for x in b:
            if x in f: ok = False; break
            f += [y ^ x for y in f]
        if ok: yield tuple(f)
Gl = list(gl()); assert len(Gl) == 20160
S = {tuple(m) for m in sols}; orbits = []
while S:
    m = next(iter(S)); orb = {tuple(m[f.index(v)] for v in range(16)) for f in Gl}
    assert orb <= S; S -= orb; orbits.append((min(orb), len(orb)))
orbits.sort()
print('GL(4,2)-orbits (code types):', len(orbits))
# number of labelled codes (subspaces of F_2^15): each generator-matrix class with multiplicities m has 15!/prod m_v! column arrangements;
# a code has |GL(4,2)| generator matrices
N = 0
for m, sz in orbits:
    arr = factorial(15)
    for x in m: arr //= factorial(x)
    N += arr * sz
assert N % 20160 == 0
print('number of doubly-even 4-dim subspaces of F_2^15:', N // 20160, ' formula for O+_14(2):', 11811 * 65 * 33 * 17 * 9)
for m, sz in orbits:
    wts = sorted(sum(m[v] for v in range(16) if par[l][v]) for l in range(1, 16))
    print(m, 'orbit', sz, 'zero cols', m[0], 'weights 4/8/12:', wts.count(4), wts.count(8), wts.count(12))
json.dump([list(m) for m, _ in orbits], open('codes15_own.json', 'w'))
