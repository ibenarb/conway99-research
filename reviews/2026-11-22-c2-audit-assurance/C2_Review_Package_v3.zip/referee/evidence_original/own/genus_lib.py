# Own tools for the genus of L_0 (rank 15, det 2^8, elementary discriminant, integral dual norms).
import itertools, random
from fractions import Fraction
from math import factorial
from cypari import pari
pari.allocatemem(1500000000, silent=True)

def pm(M):  # python int matrix -> pari matrix
    return pari('[' + ';'.join(','.join(str(int(x)) for x in row) for row in M) + ']')
def tolist(P):
    r, c = int(pari.matsize(P)[0]), int(pari.matsize(P)[1])
    return [[int(P[i, j]) for j in range(c)] for i in range(r)]

def lattice_from_generators(gens):
    """gens: rational vectors (lists of Fractions). Returns a Z-basis (rows, Fractions)."""
    den = 1
    for g in gens:
        for x in g:
            den = den * x.denominator // __import__('math').gcd(den, x.denominator)
    M = [[int(x * den) for x in g] for g in gens]
    H = pari.mathnf(pari.mattranspose(pm(M)))        # column HNF of the generator columns
    H = tolist(pari.mattranspose(H))
    return [[Fraction(x, den) for x in row] for row in H]

def gram(B):
    return [[sum(a * b for a, b in zip(u, v)) for v in B] for u in B]

def F(*a): return [Fraction(x) for x in a]
def e(n, i, s=1): v = [Fraction(0)] * n; v[i] = Fraction(s); return v
def add(u, v): return [a + b for a, b in zip(u, v)]
def pad(v, lo, n): return [Fraction(0)] * lo + list(v) + [Fraction(0)] * (n - lo - len(v))

def unimodular_15():
    n = 15; out = {}
    out['Z15'] = [e(n, i) for i in range(n)]
    # E8 = D8 + (1/2)^8
    def E8():
        g = [add(e(8, i), e(8, i + 1, -1)) for i in range(7)] + [add(e(8, 6), e(8, 7))] + [[Fraction(1, 2)] * 8]
        return g
    out['Z7+E8'] = [e(n, i) for i in range(7)] + [pad(v, 7, n) for v in E8()]
    D12 = [add(e(12, i), e(12, i + 1, -1)) for i in range(11)] + [add(e(12, 10), e(12, 11))] + [[Fraction(1, 2)] * 12]
    out['Z3+D12+'] = [e(n, i) for i in range(3)] + [pad(v, 3, n) for v in D12]
    # E7 = vectors of E8 with coordinate sum 0; glue (1/4)(1^6,-3^2). Embed two copies in R^16 and add Z: work in R^17.
    def E7gens():
        gs = []
        for i in range(8):
            for j in range(i + 1, 8):
                gs.append(add(e(8, i), e(8, j, -1)))
        for S in itertools.combinations(range(8), 4):
            gs.append([Fraction(1, 2) if i in S else Fraction(-1, 2) for i in range(8)])
        return gs
    g7 = [Fraction(1, 4)] * 6 + [Fraction(-3, 4)] * 2
    m = 17
    out['Z1+E7E7+'] = [e(m, 0)] + [pad(v, 1, m) for v in E7gens()] + [pad(v, 9, m) for v in E7gens()] + [[Fraction(0)] + g7 + g7]
    A15 = [add(e(16, i), e(16, i + 1, -1)) for i in range(15)] + [[Fraction(1, 4)] * 12 + [Fraction(-3, 4)] * 4]
    out['A15+'] = A15
    res = {}
    for k, gens in out.items():
        B = lattice_from_generators(gens)
        B = [row for row in B if any(row)]
        G = gram(B)
        assert len(B) == 15 and all(x.denominator == 1 for r in G for x in r), k
        G = [[int(x) for x in r] for r in G]
        Gp = pm(G)
        assert int(pari.matdet(Gp)) == 1, k
        T = pari.qflllgram(Gp)
        Gr = tolist(pari.mattranspose(T) * Gp * T)
        res[k] = Gr
    return res

def short_count(G, bound):
    r = pari.qfminim(pm(G), bound, 0, 2)
    return int(r[0])
def short_vectors(G, bound):
    r = pari.qfminim(pm(G), bound, None, 2)
    V = r[2]; n = int(pari.matsize(V)[1]); k = int(pari.matsize(V)[0])
    return [[int(V[i, j]) for i in range(k)] for j in range(n)]
