# Independent check of the rank-7 low-rank case (chart 288, both parities): for every star assignment and every
# 2-plane W of F_7^4 some outside label has no admissible attachment with residual-anchor pairing vector in W.
import itertools, sys, time
from own_local import *
def planes():
    seen = set(); out = []
    vecs = [v for v in itertools.product(range(7), repeat=4) if any(v)]
    def norm(v):
        f = next(x for x in v if x); iv = pow(f, -1, 7); return tuple(x * iv % 7 for x in v)
    pts = sorted({norm(v) for v in vecs})
    for a, b in itertools.combinations(pts, 2):
        W = frozenset(tuple((x * p + y * q) % 7 for p, q in zip(a, b)) for x in range(7) for y in range(7))
        if W not in seen: seen.add(W); out.append(W)
    return out
PL = planes(); print('2-planes of F_7^4:', len(PL), flush=True)
for cid in (288,):
    for par in (0, 1):
        t0 = time.time(); C = Chart(cid, par)
        print('chart', cid, 'own parity', par, 'rank', C.rank, 'pivots', C.piv, 'nonpivots', C.nonpiv, 'det Q mod 7', C.detQ, '(square)' if C.detQ in (1, 2, 4) else '(nonsquare)', flush=True)
        dom = C.attachments(); print('  attachments per label: min', min(len(v) for v in dom.values()), 'max', max(len(v) for v in dom.values()), 'time', round(time.time() - t0), flush=True)
        stars = C.star_assignments(); print('  star assignments', len(stars), flush=True)
        viable_total = 0; nolabel = 0
        for st in stars:
            Hs = []
            dead = False
            for y in OUTER:
                keys = C.outer_keys(st, y)
                hs = {a['h'] for a in dom[y] if a['key'] in keys}
                if not hs: dead = True; break
                Hs.append(hs)
            if dead: nolabel += 1; continue
            viable = sum(1 for W in PL if all(hs & W for hs in Hs))
            viable_total += viable
        print('  stars with an empty outside domain:', nolabel, ' viable (star, plane) pairs:', viable_total, ' time', round(time.time() - t0), flush=True)
