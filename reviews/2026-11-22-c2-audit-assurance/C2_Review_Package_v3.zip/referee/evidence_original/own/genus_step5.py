# Exact (integer) Farkas certificates for every geometry that genus_step4 reports as LP-infeasible.
# Certificate: integers y_class (21) and y_unit (one per dual unit line) with
#   y_class(p) + sum_{u : (u,p) != 0} y_unit[u] <= 0  for every admissible norm-5 vector p of a required class,
#   2*sum y_class + 14*sum y_unit > 0.
import json, itertools
import numpy as np
from scipy.optimize import linprog
from genus_lib import *
exec(open('genus_step4.py').read().split('out = []')[0])
classes = json.load(open('genus_classes.json')); atlas = json.load(open('genus_atlas.json'))
ncert = 0; nfail = 0; summary = []
for ci, c in enumerate(classes):
    need = [g['vertex'] for g in atlas[ci]['geo'] if g['status'] == 'lp-infeasible']
    if not need: continue
    G = np.array(c['gram'], dtype=np.int64); Gp = pm(c['gram'])
    M = np.array(tolist(pari('2') * Gp ** -1), dtype=np.int64)
    ker, rk = nullspace_mod2(M.tolist()); K = np.array(ker, dtype=np.int64)
    pi = lambda x: tuple(int(v) for v in (K @ np.array(x)) % 2)
    reps = {}
    for x in itertools.product([0, 1], repeat=15):
        k = pi(x)
        if k not in reps:
            reps[k] = np.array(x, dtype=np.int64)
            if len(reps) == 128: break
    q = {k: int(x @ G @ x) % 4 for k, x in reps.items()}
    b = lambda k1, k2: int(reps[k1] @ G @ reps[k2]) % 2
    n2 = [k for k in reps if q[k] == 2]
    adj = {k: {l for l in n2 if l != k and b(k, l) == 1} for k in n2}
    cl = []
    def ext(cur, cand):
        if len(cur) == 7: cl.append(frozenset(cur)); return
        for x in sorted(cand):
            if x > cur[-1]: ext(cur + [x], cand & adj[x])
    for a in sorted(n2): ext([a], set(adj[a]))
    stars = sorted(set(cl), key=sorted)
    vert = {k: tuple(i for i, s in enumerate(stars) if k in s) for k in n2}
    char = [k for k in reps if all(b(k, l) == q[l] % 2 for l in reps)][0]
    addk = lambda k1, k2: tuple((a + b_) % 2 for a, b_ in zip(k1, k2))
    du = short_vectors(M.tolist(), 2)
    dunits = np.array([v for v in du if int(np.array(v) @ M @ np.array(v)) == 2], dtype=np.int64)
    s5 = short_vectors(c['gram'], 5)
    V5 = np.array([v for v in s5 if int(np.array(v) @ G @ np.array(v)) == 5], dtype=np.int64)
    pair = np.abs(V5 @ dunits.T); adm = pair.max(axis=1) <= 1; cls5 = [pi(v) for v in V5]
    for w in need:
        req = [addk(char, k) for k in n2 if w not in vert[k]]
        cols = [i for i in range(len(V5)) if adm[i] and cls5[i] in req]
        rows_c = np.array([[1 if cls5[i] == k else 0 for i in cols] for k in req], dtype=np.int64)
        rows_u = (pair[cols] != 0).T.astype(np.int64)
        A = np.vstack([rows_c, rows_u]); rhs = np.array([2] * 21 + [14] * len(dunits), dtype=np.int64)
        m = A.shape[0]
        # maximise rhs.y subject to A^T y <= 0, -1 <= y <= 1
        res = linprog(-rhs.astype(float), A_ub=A.T.astype(float), b_ub=np.zeros(A.shape[1]), bounds=(-1, 1), method='highs')
        ok = False
        if res.status == 0 and -res.fun > 1e-7:
            y = res.x
            for scale in list(range(1, 61)) + [84, 120, 168, 240, 420, 840]:
                yi = np.rint(y * scale / max(1e-12, np.abs(y).max())).astype(np.int64) if False else np.rint(y * scale).astype(np.int64)
                if (yi @ A <= 0).all() and int(yi @ rhs) > 0:
                    ok = True; break
        ncert += ok; nfail += (not ok)
        summary.append(dict(cls=ci, vertex=w, certified=bool(ok), scale=int(scale) if ok else None, value=int(yi @ rhs) if ok else None,
                            y=[int(v) for v in yi] if ok else None))
        print(ci, 'vertex', w, 'exact certificate' if ok else 'NO exact certificate found', (scale, int(yi @ rhs)) if ok else '', flush=True)
print('LP-infeasible geometries:', ncert + nfail, ' certified exactly:', ncert, ' not certified:', nfail)
json.dump(summary, open('genus_farkas.json', 'w'))
