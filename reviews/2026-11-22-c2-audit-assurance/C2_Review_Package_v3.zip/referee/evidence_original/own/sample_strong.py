# Random sample of strong (automorphism-pruned) high-rank jobs of noncollapsed degree 4 for my independent solver,
# using my own orbit representatives (one star assignment per orbit of my own automorphism group).
import random, subprocess, os, sys, json, time
import own_setup
rows = [s.split() for s in open('/home/claude/pk/Conway99_NoInvolution_EvenAxis_Exact/even-simplex-packet/unsigned15/sf-run/direct-strong.tsv')]
cov = {}
for s in open('/home/claude/pk/Conway99_NoInvolution_EvenAxis_Exact/even-simplex-packet/EvenCoverage.tsv').read().splitlines()[1:]:
    w = s.split('\t'); cov[(int(w[0]), int(w[1]), int(w[4]))] = (int(w[2]), int(w[3]), w[5])
jobs = sorted({(int(w[0]), int(w[1]), int(w[3])) for w in rows})
deg4 = [j for j in jobs if cov[j][1] == 4]
print('strong jobs', len(jobs), 'of degree 4:', len(deg4), flush=True)
random.seed(99141204)
n = int(sys.argv[1]) if len(sys.argv) > 1 else 8
sample = random.sample(deg4, n)
out = open('sample_strong_results.tsv', 'a')
for (cid, their_par, mode) in sample:
    par = 1 - their_par; t0 = time.time()
    sf = f'setup/{cid}.{par}.txt'
    if not os.path.exists(sf): own_setup.write_setup(cid, par, sf)
    r = subprocess.run(['./own_pair2', sf, f'reps/{cid}.{par}.txt', str(mode)], capture_output=True, text=True)
    line = f'{cid}\t{their_par}\t{mode}\trank={cov[(cid,their_par,mode)][0]}\t{r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "NO OUTPUT rc=%d" % r.returncode}\tseconds={round(time.time()-t0)}'
    print(line, flush=True); out.write(line + '\n'); out.flush()
