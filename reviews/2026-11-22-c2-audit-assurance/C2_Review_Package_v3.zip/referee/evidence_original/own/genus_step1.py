from genus_lib import *
U = unimodular_15()
import json
tot = Fraction(0)
info = {}
for k, G in U.items():
    n1 = short_count(G, 1); n2 = short_count(G, 2) - n1
    a = pari.qfauto(pm(G))
    o = int(a[0])
    info[k] = dict(units=n1, roots=n2, aut=o)
    tot += Fraction(1, o)
    print(k, 'norm1', n1, 'norm2', n2, '|Aut|', o, flush=True)
exp = {'Z15': 2**15 * factorial(15), 'Z7+E8': 2**7 * factorial(7) * 696729600, 'Z3+D12+': 2**3 * 6 * 2**11 * factorial(12),
       'Z1+E7E7+': 2 * 2903040**2 * 2, 'A15+': 2 * factorial(16)}
print('automorphism orders as expected:', all(info[k]['aut'] == exp[k] for k in exp))
print('mass of unimodular rank 15 (5 classes):', tot)
json.dump({'gram': U, 'info': info, 'mass': [tot.numerator, tot.denominator]}, open('unimodular15.json', 'w'))
