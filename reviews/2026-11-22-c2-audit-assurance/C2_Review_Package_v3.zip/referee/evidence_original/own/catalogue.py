# Independent check of the ordered matching-pair catalogue (manuscript Section 6.1).
# Own code; uses nothing from the reviewed packets. Python 3 + numpy.
import itertools, json, sys
import numpy as np
from fractions import Fraction

n = 12
M = [i ^ 1 for i in range(n)]

def matchings(pts):
    if not pts:
        yield []
        return
    a = pts[0]
    for k in range(1, len(pts)):
        b = pts[k]
        rest = pts[1:k] + pts[k+1:]
        for m in matchings(rest):
            yield [(a, b)] + m

ALL = []
for m in matchings(list(range(n))):
    p = [0] * n
    for a, b in m:
        p[a] = b; p[b] = a
    ALL.append(tuple(p))
assert len(ALL) == 10395
IDX = {p: i for i, p in enumerate(ALL)}
ARR = np.array(ALL, dtype=np.int8)

# group preserving M: permutations of the 6 pairs times swaps inside pairs
G = []
for perm in itertools.permutations(range(6)):
    for sw in range(64):
        g = [0] * n
        for j in range(6):
            s = (sw >> j) & 1
            g[2 * j] = 2 * perm[j] + s
            g[2 * j + 1] = 2 * perm[j] + 1 - s
        G.append(g)
G = np.array(G, dtype=np.int8)
assert len(G) == 46080
# conjugation action on matchings as an index map, computed for every group element
pw = (12 ** np.arange(n)).astype(np.int64)
code = {int(np.dot(np.array(p, dtype=np.int64), pw)): i for i, p in enumerate(ALL)}
codes_sorted = np.array(sorted(code)); vals = np.array([code[c] for c in codes_sorted])
def act(g):
    # (g.P)(g(i)) = g(P(i))
    ginv = np.empty(n, dtype=np.int64); ginv[g] = np.arange(n)
    Q = g[ARR[:, ginv]].astype(np.int64)
    c = Q @ pw
    return vals[np.searchsorted(codes_sorted, c)]

# orbits of G on single matchings P
lab = np.arange(len(ALL))
ACT = np.empty((len(G), len(ALL)), dtype=np.int16)
for k, g in enumerate(G):
    ACT[k] = act(g)
# Burnside count of orbits on ordered pairs (independent of the explicit orbit construction below)
fix = (ACT == np.arange(len(ALL))[None, :]).sum(axis=1).astype(object)
burn_pairs = sum(int(f) * int(f) for f in fix)
burn_single = sum(int(f) for f in fix)
assert burn_pairs % len(G) == 0 and burn_single % len(G) == 0
print('Burnside: orbits on matchings', burn_single // len(G), ' orbits on ordered pairs', burn_pairs // len(G), flush=True)

seen = np.zeros(len(ALL), bool); Preps = []
for i in range(len(ALL)):
    if not seen[i]:
        orb = np.unique(ACT[:, i]); seen[orb] = True; Preps.append((i, len(orb)))
print('P-orbits', len(Preps), [s for _, s in Preps], flush=True)

def cycle_type(P):
    # alternating cycles of M and P on 12 points -> partition of 6
    seen = set(); out = []
    for s in range(n):
        if s in seen: continue
        c = 0; x = s
        while x not in seen:
            seen.add(x); x = M[x]; seen.add(x); x = P[x]; c += 1
        out.append(c)
    return tuple(sorted(out, reverse=True))

charts = []
for i, osz in Preps:
    stab = np.flatnonzero(ACT[:, i] == i)
    assert len(stab) * osz == len(G)
    S = ACT[stab]
    seenN = np.zeros(len(ALL), bool)
    for jn in range(len(ALL)):
        if not seenN[jn]:
            orb = np.unique(S[:, jn]); seenN[orb] = True
            charts.append((i, jn, len(G) // (len(stab) // len(orb))))
tot = sum(c[2] for c in charts)
print('charts', len(charts), 'pairs covered', tot, '= 10395^2', tot == 10395 ** 2, flush=True)
print('cycle types of P reps', sorted(cycle_type(ALL[i]) for i, _ in Preps))

def mat(P):
    A = np.zeros((n, n), dtype=np.int64)
    for a in range(n): A[a, P[a]] = 1
    return A
Mm = mat(M); I = np.eye(n, dtype=np.int64); J = np.ones((n, n), dtype=np.int64)

def rank_mod(Amat, p):
    A = [[int(x) % p for x in row] for row in Amat]; r = 0; rows = len(A); cols = len(A[0])
    for c in range(cols):
        piv = next((k for k in range(r, rows) if A[k][c]), None)
        if piv is None: continue
        A[r], A[piv] = A[piv], A[r]
        inv = pow(A[r][c], -1, p)
        A[r] = [(x * inv) % p for x in A[r]]
        for k in range(rows):
            if k != r and A[k][c]:
                f = A[k][c]; A[k] = [(x - f * y) % p for x, y in zip(A[k], A[r])]
        r += 1
    return r

def base_graph(P, N):
    # vertices: 0 = o; 1,2 = c+, c-; 3.. = peripheral axis members (j,s); then positive reps, negative reps
    V = 1 + 2 + 12 + 24
    A = np.zeros((V, V), dtype=np.int8)
    def e(a, b): A[a, b] = A[b, a] = 1
    cp, cm = 1, 2
    ax = lambda j, s: 3 + 2 * j + s
    pos = lambda i: 15 + i
    neg = lambda i: 27 + i
    e(0, cp); e(0, cm); e(cp, cm)
    for j in range(6):
        e(0, ax(j, 0)); e(0, ax(j, 1)); e(ax(j, 0), ax(j, 1))
    for i in range(12):
        j, t = divmod(i, 2)
        e(cp, pos(i)); e(cm, neg(i))
        # positive rep has parents c+ and j^{(-1)^t}; its mate has c- and the other member
        e(pos(i), ax(j, t)); e(neg(i), ax(j, 1 - t))
        e(pos(i), pos(P[i])); e(neg(i), neg(P[i]))
        e(pos(i), neg(N[i])); e(neg(i), pos(N[i]))
    return A

def caps_ok(A):
    C = A.astype(np.int64) @ A.astype(np.int64)
    lim = 2 - A.astype(np.int64)
    np.fill_diagonal(C, 0)
    return bool((C <= lim).all())

out = []
rk = {}; bad = 0; even = 0; even_bad = 0; lowlist = []
for (i, jn, sz) in charts:
    P = ALL[i]; N = ALL[jn]
    F = 11 * I + Mm - 4 * mat(P) + 4 * mat(N) - J
    H = 5 * I - Mm - 2 * mat(P) - 2 * mat(N)
    r = rank_mod(F, 7)
    rk[r] = rk.get(r, 0) + 1
    ok = caps_ok(base_graph(P, N))
    coll = sum(1 for j in range(6) if P[2 * j] == 2 * j + 1 and N[2 * j] == 2 * j + 1)
    deg = 6 - coll
    bad += (not ok)
    if deg % 2 == 0:
        even += 1; even_bad += (not ok)
    out.append(dict(P=P, N=N, orbit=sz, rank7=r, physical=ok, degree=deg))
print('rank distribution', dict(sorted(rk.items())))
print('physically invalid bases', bad, ' even-degree charts', even, ' of which invalid', even_bad)
from collections import Counter
print('degree distribution', dict(sorted(Counter(o['degree'] for o in out).items())))
print('rank x degree (physical only)', dict(sorted(Counter((o['rank7'], o['degree']) for o in out if o['physical']).items())))
json.dump(out, open('catalogue_own.json', 'w'))
