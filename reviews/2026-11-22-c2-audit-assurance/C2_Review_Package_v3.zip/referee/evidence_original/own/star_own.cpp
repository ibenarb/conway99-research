// Independent count of 12-word central-star assignments in the simplex model (own code).
// Input: geometry_own.txt (2 parities x 6 peripheral axes x 6 supports), layouts (rank P[12] N[12]).
// Output per layout and parity: number of assignments of signed circuits p_0..p_11 with Gram
// H_A = 5I - M - 2P - 2N, where labels 2j,2j+1 use the coset of peripheral axis j, counted modulo
// sign changes of coordinates (each coordinate's first use is +1).
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <array>
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;
int geo[2][6][6];
int Hm[12][12];
int supp[12], sgn[12]; // sign mask: bit set = -1
long long cnt; const int *G;
static inline int dot(int s1,int g1,int s2,int g2){int c=s1&s2;return __builtin_popcount(c)-2*__builtin_popcount((g1^g2)&c);}
void rec(int i,int used,const int (*g)[6]){
  if(i==12){cnt++;return;}
  int j=i/2;
  for(int k=0;k<6;k++){
    int s=g[j][k];int old=s&used;
    // signs on new coordinates are +; enumerate sign patterns on old coordinates
    int sub=old;
    while(true){
      bool ok=true;
      for(int a=0;a<i&&ok;a++) if(dot(supp[a],sgn[a],s,sub)!=Hm[a][i]) ok=false;
      if(ok){supp[i]=s;sgn[i]=sub;rec(i+1,used|s,g);}
      if(sub==0)break; sub=(sub-1)&old;
    }
  }
}
int main(int argc,char**argv){
  {ifstream f("geometry_own.txt");for(int p=0;p<2;p++)for(int j=0;j<6;j++)for(int k=0;k<6;k++)f>>geo[p][j][k];}
  ifstream L(argv[1]);string line;int id=0;
  while(getline(L,line)){
    istringstream is(line);int r;is>>r;int P[12],N[12];for(int i=0;i<12;i++)is>>P[i];for(int i=0;i<12;i++)is>>N[i];
    for(int a=0;a<12;a++)for(int b=0;b<12;b++)Hm[a][b]=5*(a==b)-(b==(a^1))-2*(b==P[a])-2*(b==N[a]);
    for(int p=0;p<2;p++){cnt=0;rec(0,0,geo[p]);printf("%d %d %d %lld\n",id,p,r,cnt);}
    fflush(stdout);id++;
  }
}
