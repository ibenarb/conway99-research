# Own re-derivation: an involution t of an srg(99,14,1,2) fixes exactly one vertex.
# Local type at a fixed vertex x: of the 7 triangles through x, a are fixed pointwise, b have their two other
# vertices swapped, 2c are swapped in pairs; a + b + 2c = 7, a <= 6.  Then f = |Fix| = 1 + 2a^2 + 2c.
# Global: n = (99-f)/2 two-point orbits; e = sum_x b_x (adjacent orbits), p = sum_x c_x (nonadjacent orbits with
# two fixed common neighbours), d0 = n - e - p >= 0 even; trace on the antisymmetric space: 7 r = 4n - e, 0 <= r <= n;
# sum_x a_x = 3 * (number of triangles inside Fix).
import itertools
types = [(a, b, c) for a in range(7) for c in range(4) for b in [7 - a - 2 * c] if b >= 0]
by_f = {}
for (a, b, c) in types: by_f.setdefault(1 + 2 * a * a + 2 * c, []).append((a, b, c))
print('possible f:', sorted(by_f))
sols = []
for f, ts in sorted(by_f.items()):
    if f > 99 or (99 - f) % 2: continue
    n = (99 - f) // 2
    # distribute the f fixed vertices over the local types with this f
    for comp in itertools.combinations_with_replacement(range(len(ts)), f) if f <= 9 else [None]:
        if comp is None:
            # large f: enumerate counts instead of multisets
            def rec(i, left, cur):
                if i == len(ts) - 1: yield cur + [left]; return
                for k in range(left + 1): yield from rec(i + 1, left - k, cur + [k])
            combos = list(rec(0, f, []))
        else:
            cnt = [0] * len(ts)
            for i in comp: cnt[i] += 1
            combos = [cnt]
        for cnt in combos:
            e = sum(k * ts[i][1] for i, k in enumerate(cnt)); p = sum(k * ts[i][2] for i, k in enumerate(cnt)); sa = sum(k * ts[i][0] for i, k in enumerate(cnt))
            d0 = n - e - p
            if d0 < 0 or d0 % 2: continue
            if (4 * n - e) % 7: continue
            r = (4 * n - e) // 7
            if not (0 <= r <= n): continue
            if sa % 3: continue
            sols.append((f, n, e, p, d0, tuple(cnt)))
print('solutions (f, n, e, p, d0, counts of local types):', sorted(set(sols)))
