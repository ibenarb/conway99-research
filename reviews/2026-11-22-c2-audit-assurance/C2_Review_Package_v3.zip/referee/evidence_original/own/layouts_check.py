# Are the author's 3580 layouts a complete, irredundant set of orbit representatives?
# Canonical form = lexicographic minimum of (P,N) under the full group of order 46080 (own code).
import itertools, json, numpy as np
L = [list(map(int, s.split())) for s in open('/home/claude/pk/Conway99_NoInvolution_EvenAxis_Exact/even-simplex-packet/dualplanes/unary5-packet/layouts.tsv')]
own = json.load(open('catalogue_own.json'))
n = 12
G = []
for perm in itertools.permutations(range(6)):
    for sw in range(64):
        g = [0] * n
        for j in range(6):
            s = (sw >> j) & 1
            g[2 * j] = 2 * perm[j] + s; g[2 * j + 1] = 2 * perm[j] + 1 - s
        G.append(g)
G = np.array(G, dtype=np.int64); Ginv = np.argsort(G, axis=1)
pw = 12 ** np.arange(23, -1, -1, dtype=object)
def canon(P, N):
    P = np.array(P); N = np.array(N)
    Pc = G[np.arange(len(G))[:, None], P[Ginv]]   # (gPg^-1)(x) = g(P(g^-1 x))
    Nc = G[np.arange(len(G))[:, None], N[Ginv]]
    key = np.concatenate([Pc, Nc], axis=1)
    idx = np.lexsort(key.T[::-1])[0]
    return tuple(key[idx].tolist())
theirs = {}
for i, row in enumerate(L):
    c = canon(row[1:13], row[13:25]); assert c not in theirs, ('duplicate orbit', i, theirs[c]); theirs[c] = i
mine = {canon(o['P'], o['N']): k for k, o in enumerate(own)}
assert len(mine) == 3580
print('author layouts:', len(L), 'distinct orbits:', len(theirs), 'equal to own orbit set:', set(theirs) == set(mine))
# rank column and physical flag agree?
bad = 0
for c, i in theirs.items():
    o = own[mine[c]]
    if L[i][0] != o['rank7']: bad += 1
print('rank column disagreements:', bad)
json.dump({str(i): mine[c] for c, i in theirs.items()}, open('id_map_author_to_own.json', 'w'))
