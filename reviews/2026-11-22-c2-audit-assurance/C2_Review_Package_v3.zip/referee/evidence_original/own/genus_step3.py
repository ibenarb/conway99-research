# Targeted search for the remaining classes: mixed glue codes in Z^7 + E_8, sampled by (D, f) rather than uniformly.
import json, random, itertools, time
from fractions import Fraction
from collections import Counter
import numpy as np
from genus_lib import *
exec(open('genus_step2.py').read().split('# 1. all 20 code types')[0])   # reuse L0_gram, invariants, register, target (definitions only)
old = json.load(open('genus_classes.json'))
for c in old: classes.append(dict(gram=c['gram'], inv=tuple(c['inv']), aut=c['aut'], sources=set(c['sources'])))
def total(): return sum(Fraction(1, c["aut"]) for c in classes)
print("loaded", len(classes), 'classes; mass ratio', float(total() / target))
E8 = [[2 if i == j else 0 for j in range(8)] for i in range(8)]
for a, b in [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (4, 7)]: E8[a][b] = E8[b][a] = -1
assert int(pari.matdet(pm(E8))) == 1
G = [[0] * 15 for _ in range(15)]
for i in range(7): G[i][i] = 1
for i in range(8):
    for j in range(8): G[7 + i][7 + j] = E8[i][j]
En = np.array(E8, dtype=np.int64)
ys = np.array(list(itertools.product([0, 1], repeat=8)), dtype=np.int64)
Qy = ((ys @ En) * ys).sum(axis=1) // 2 % 2          # y^2/2 mod 2
print('E8/2E8: zero 1, nonsingular', int((Qy == 1).sum()), ' singular nonzero', int((Qy == 0).sum()) - 1)
rng = np.random.default_rng(7)
even7 = [np.array(v) for v in itertools.product([0, 1], repeat=7) if sum(v) % 2 == 0 and any(v)]
seen = Counter(); tried = 0; t0 = time.time()
while tried < 6000 and total() != target:
    # random 4-dim subspace D of the even hyperplane
    basis = []; span = [np.zeros(7, dtype=np.int64)]
    while len(basis) < 4:
        x = even7[rng.integers(len(even7))]
        if any((x == s).all() for s in span): continue
        basis.append(x); span = span + [(s + x) % 2 for s in span]
    fs = []; ok = True
    for i, x in enumerate(basis):
        need_q = (int(x.sum()) // 2) % 2
        cand = (Qy == need_q)
        for j in range(i):
            cand &= ((ys @ En @ fs[j]) % 2 == (int(x @ basis[j]) % 2))
        idx = np.flatnonzero(cand)
        if len(idx) == 0: ok = False; break
        fs.append(ys[idx[rng.integers(len(idx))]])
    if not ok: continue
    tried += 1
    C = [list(map(int, basis[i])) + list(map(int, fs[i])) for i in range(4)]
    # cheap invariant: for every nonzero word, (weight of the Z^7 part, type of the E8 part)
    typ = []
    for coef in itertools.product([0, 1], repeat=4):
        if not any(coef): continue
        x = sum(c * b for c, b in zip(coef, basis)) % 2; y = sum(c * f for c, f in zip(coef, fs)) % 2
        typ.append((int(x.sum()), 0 if not y.any() else (1 if int(y @ En @ y) // 2 % 2 else 2)))
    key = tuple(sorted(typ)); seen[key] += 1
    if seen[key] > 6: continue
    Gl, _ = L0_gram(G, C)
    c, new = register(Gl, 'Z7+E8:mixed')
    if new: print('  new class', len(classes) - 1, c['inv'], c['aut'], 'mass ratio', float(total() / target), 'after', tried, flush=True)
print('tried', tried, 'distinct word-type invariants', len(seen), 'time', round(time.time() - t0))
print('classes', len(classes), ' exact mass equality:', total() == target, total(), target)
json.dump([dict(gram=c['gram'], inv=c['inv'], aut=c['aut'], sources=sorted(c['sources'])) for c in classes], open('genus_classes.json', 'w'))
