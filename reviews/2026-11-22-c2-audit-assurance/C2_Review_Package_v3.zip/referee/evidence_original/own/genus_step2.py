import json, random, sys, time
from fractions import Fraction
from genus_lib import *
import numpy as np
U = json.load(open('unimodular15.json'))
mass15 = Fraction(*U['mass'])
N = 3876193035
target = mass15 * N / 2295
print('target mass of the genus:', target, flush=True)

def L0_gram(G, C):
    """G: Gram of V (15x15), C: 4 vectors in F_2^15 (basis coordinates). Returns LLL-reduced Gram of L0 and its basis in V-coordinates."""
    Gm = np.array(G, dtype=object)
    A = [[int(sum(Gm[i][j] * c[j] for j in range(15))) % 2 for i in range(15)] for c in C]   # rows: functional x -> (x,c) mod 2
    A = [row[:] for row in A]; piv = []; r = 0
    for col in range(15):
        k = next((i for i in range(r, 4) if A[i][col]), None)
        if k is None: continue
        A[r], A[k] = A[k], A[r]
        for i in range(4):
            if i != r and A[i][col]: A[i] = [a ^ b for a, b in zip(A[i], A[r])]
        piv.append(col); r += 1
    assert r == 4
    B = []
    for f in range(15):
        if f in piv: continue
        v = [0] * 15; v[f] = 1
        for i, p in enumerate(piv):
            if A[i][f]: v[p] = 1
        B.append(v)
    for p in piv:
        v = [0] * 15; v[p] = 2; B.append(v)
    Bm = np.array(B, dtype=object)
    Gl = Bm.dot(Gm).dot(Bm.T)
    Gp = pm(Gl.tolist()); assert int(pari.matdet(Gp)) == 256
    T = pari.qflllgram(Gp)
    Gr = pari.mattranspose(T) * Gp * T
    Bv = (np.array(tolist(pari.mattranspose(T)), dtype=object).dot(Bm)).tolist()
    return tolist(Gr), Bv

def invariants(Gl):
    Gp = pm(Gl)
    n = [int(pari.qfminim(Gp, b, 0, 2)[0]) for b in (1, 2, 3)]
    Md = 2 * pari.matinverseimage(Gp, pari.matid(15)) if False else pari('2') * (Gp ** -1)
    assert pari.denominator(Md) == 1
    d = [int(pari.qfminim(Md, b, 0, 2)[0]) for b in (2, 4)]
    return (n[0], n[1] - n[0], n[2] - n[1], d[0], d[1] - d[0])

classes = []   # dict(gram, inv, aut, sources)
def register(Gl, src):
    inv = invariants(Gl)
    for c in classes:
        if c['inv'] == inv and pari.qfisom(pm(c['gram']), pm(Gl)) != 0:
            c['sources'].add(src); return c, False
    a = int(pari.qfauto(pm(Gl))[0])
    c = dict(gram=Gl, inv=inv, aut=a, sources={src}); classes.append(c)
    return c, True

def q4(G, x): return int(sum(G[i][j] * x[i] * x[j] for i in range(15) for j in range(15))) % 4
def b2(G, x, y): return int(sum(G[i][j] * x[i] * y[j] for i in range(15) for j in range(15))) % 2
def random_C(G, rng):
    Gn = np.array(G, dtype=np.int64)
    C = []
    span = [np.zeros(15, dtype=np.int64)]
    while len(C) < 4:
        x = rng.integers(0, 2, 15)
        if int(x @ Gn @ x) % 4: continue
        if any(int(x @ Gn @ c) % 2 for c in C): continue
        if any((x == s).all() for s in span): continue
        C.append(x); span = span + [(s + x) % 2 for s in span]
    return [list(map(int, c)) for c in C]

# 1. all 20 code types in Z^15
codes = json.load(open('codes15_own.json'))
Gz = U['gram']['Z15']
assert Gz == [[int(i == j) for j in range(15)] for i in range(15)]
code_class = []
for idx, m in enumerate(codes):
    cols = []
    for v in range(16): cols += [v] * m[v]
    C = [[(cols[i] >> k) & 1 for i in range(15)] for k in range(4)]
    Gl, _ = L0_gram(Gz, C)
    c, new = register(Gl, f'Z15:code{idx}')
    code_class.append(classes.index(c))
    print('code', idx, m, '-> class', classes.index(c), 'new' if new else '', c['inv'], c['aut'], flush=True)
def total(): return sum(Fraction(1, c['aut']) for c in classes)
print('classes from Z^15:', len(classes), ' mass found / target =', float(total() / target), flush=True)

rng = np.random.default_rng(20261122)
for name in ['Z7+E8', 'Z3+D12+', 'Z1+E7E7+', 'A15+', 'Z15']:
    G = U['gram'][name]; t0 = time.time(); seen_inv = {}
    nsamp = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    for s in range(nsamp):
        C = random_C(G, rng)
        Gl, _ = L0_gram(G, C)
        c, new = register(Gl, name)
        if new: print('  new class', len(classes) - 1, 'from', name, c['inv'], c['aut'], ' mass ratio', float(total() / target), flush=True)
    print(name, 'sampled', nsamp, 'classes now', len(classes), 'mass ratio', float(total() / target), 'time', round(time.time() - t0), flush=True)
print('exact mass equality:', total() == target, ' found', total(), ' target', target)
json.dump([dict(gram=c['gram'], inv=c['inv'], aut=c['aut'], sources=sorted(c['sources'])) for c in classes], open('genus_classes.json', 'w'))
json.dump(code_class, open('code_class.json', 'w'))
