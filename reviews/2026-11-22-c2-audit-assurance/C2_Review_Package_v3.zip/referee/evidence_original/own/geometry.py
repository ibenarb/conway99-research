# Own derivation of the simplex/Hamming geometry (manuscript Prop. 5.2 and the K8 labelling).
# Coordinates = nonzero points 1..15 of F_2^4 (bit i-1 of a mask = point i).
import itertools, json
pts = range(1, 16)
def xor(S):
    x = 0
    for s in S: x ^= s
    return x
def mask(S): return sum(1 << (s - 1) for s in S)
circuits = []
for S in itertools.combinations(pts, 5):
    if xor(S): continue
    if any(xor(T) == 0 for k in (1, 2, 3, 4) for T in itertools.combinations(S, k)): continue
    circuits.append(mask(S))
simplex = [mask([v for v in pts if bin(l & v).count('1') % 2]) for l in range(16)]
assert sorted(bin(c).count('1') for c in simplex) == [0] + [8] * 15
hamming = [m for m in range(1 << 15) if all(bin(m & c).count('1') % 2 == 0 for c in simplex)]
assert len(hamming) == 2 ** 11
assert all(xor([i + 1 for i in range(15) if m >> i & 1]) == 0 for m in hamming)   # dual of simplex = zero-sum sets
wt5 = [m for m in hamming if bin(m).count('1') == 5]
assert sorted(wt5) == sorted(circuits) and len(circuits) == 168
cos = {}
for c in circuits: cos.setdefault(min(c ^ s for s in simplex), []).append(c)
assert len(cos) == 28 and all(len(v) == 6 for v in cos.values())
keys = sorted(cos)
# graph on the 28 cosets: a ~ b iff representatives meet evenly (then the norm-2 classes 1+a, 1+b have dot 1)
def even(a, b): return bin(cos[a][0] & cos[b][0]).count('1') % 2 == 0
for a in keys:
    for b in keys:  # well defined on cosets
        assert len({bin(x & y).count('1') % 2 for x in cos[a] for y in cos[b]}) == 1
adj = {a: {b for b in keys if b != a and even(a, b)} for a in keys}
assert all(len(v) == 12 for v in adj.values())
# maximal cliques of size 7 = stars of K8
cl = []
def ext(c, cand):
    if len(c) == 7: cl.append(frozenset(c)); return
    for x in sorted(cand):
        if x > c[-1]: ext(c + [x], cand & adj[x])
for a in keys: ext([a], set(adj[a]))
stars = sorted(set(cl), key=sorted)
assert len(stars) == 8
vert = {a: tuple(i for i, s in enumerate(stars) if a in s) for a in keys}
assert all(len(v) == 2 for v in vert.values()) and len(set(vert.values())) == 28
edge = {v: a for a, v in vert.items()}
# induced action of GL(4,2) on the 8 vertices: all even?
def gl():
    for b in itertools.permutations(range(1, 16), 4):
        f = [0]
        ok = True
        for x in b:
            if x in f: ok = False; break
            f += [y ^ x for y in f]
        if ok: yield f
perms = set(); n = 0
for f in gl():
    n += 1
    im = lambda m: sum(1 << (f[i + 1] - 1) for i in range(15) if m >> i & 1)
    img = {a: min(im(cos[a][0]) ^ s for s in simplex) for a in keys}
    p = []
    for i, s in enumerate(stars):
        t = frozenset(img[a] for a in s); p.append(stars.index(t))
    perms.add(tuple(p))
def sign(p): return sum(p[i] > p[j] for i in range(8) for j in range(i + 1, 8)) % 2
print('GL(4,2) elements', n, 'induced permutations of the 8 vertices', len(perms), 'all even:', all(sign(p) == 0 for p in perms))
assert n == 20160 and len(perms) == 20160
# geometry: omitted vertex 0, central vertex 1, peripheral axes j=0..5 -> vertices 2..7 (parity 0), or with 6,7 swapped (parity 1)
geo = {}
for par, order in ((0, [2, 3, 4, 5, 6, 7]), (1, [2, 3, 4, 5, 7, 6])):
    geo[par] = {'central': [sorted(cos[edge[(1, v)]]) for v in order],
                'outer': {f'{a},{b}': sorted(cos[edge[tuple(sorted((order[a], order[b])))]]) for a in range(6) for b in range(a + 1, 6)}}
json.dump(geo, open('geometry_own.json', 'w'))
# compare the 21 classes with the author's simplex.tsv as a set of sets (labelling may differ)
th = [frozenset(map(int, l.split())) for l in open('/home/claude/pk/Conway99_NoInvolution_EvenAxis_Exact/even-simplex-packet/unsigned15/simplex.tsv')]
allc = {frozenset(v) for v in cos.values()}
print('author simplex.tsv: 21 rows, all are circuit cosets:', all(t in allc for t in th), ' distinct:', len(set(th)) == 21)
miss = allc - set(th)
print('the 7 cosets not used by the author form a star of K8:', frozenset(min(m) for m in miss) in {frozenset(min(cos[a]) for a in s) for s in stars})
with open('geometry_own.txt', 'w') as f:
    for par in (0, 1):
        for row in geo[par]['central']: f.write(' '.join(map(str, row)) + '\n')
