# Random sample of baseline high-rank jobs for my independent solver (seeded, reproducible).
import random, subprocess, os, sys, json, time
import own_setup
LAYF = '/home/claude/pk/Conway99_NoInvolution_EvenAxis_Exact/even-simplex-packet/dualplanes/unary5-packet/layouts.tsv'
rows = [s.split() for s in open('/home/claude/pk/Conway99_NoInvolution_EvenAxis_Exact/even-simplex-packet/unsigned15/sf-run/direct-initial.tsv')]
jobs = [(int(w[0]), int(w[1]), int(w[3]), int(w[w.index('full') + 1]), int(w[w.index('pairs') + 1]), float(w[-1])) for w in rows]
random.seed(99141202)
n = int(sys.argv[1]) if len(sys.argv) > 1 else 40
sample = random.sample(jobs, n)
os.makedirs('raw', exist_ok=True); os.makedirs('setup', exist_ok=True)
out = open('sample_results.tsv', 'a')
for (cid, their_par, mode, full, pairs, cpu) in sample:
    par = 1 - their_par                      # my parity labelling is the opposite of the packet's (see star counts)
    t0 = time.time()
    sf = f'setup/{cid}.{par}.txt'
    if not os.path.exists(sf): own_setup.write_setup(cid, par, sf)
    rf = f'raw/{cid}.{par}.txt'
    if not os.path.exists(rf):
        with open(rf, 'w') as fo: subprocess.run(['./star_dump', LAYF, str(cid), str(par)], stdout=fo, check=True)
    r = subprocess.run(['./own_pair2', sf, rf, str(mode)], capture_output=True, text=True)
    line = f'{cid}\t{their_par}\t{mode}\tauthor_full={full}\tauthor_pairs={pairs}\tauthor_cpu={cpu}\t{r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "NO OUTPUT rc=%d" % r.returncode}\tseconds={round(time.time()-t0)}'
    print(line, flush=True); out.write(line + '\n'); out.flush()
