# Small exact checks of numbers quoted in the manuscript (own code).
import itertools
from fractions import Fraction as Fr
from math import factorial
# Lemma 4.2: D12+ / 2 D12+
# coordinates doubled: vectors of D12+ are (1/2) * w with w in Z^12, all w_i of equal parity, sum w = 0 mod 4.
def in_L(w): return len({x % 2 for x in w}) == 1 and sum(w) % 4 == 0
basis = [tuple(2 if j == i else (-2 if j == 11 else 0) for j in range(12)) for i in range(10)] + [tuple(4 if j == 11 else 0 for j in range(12))] + [tuple([1] * 12)]
assert all(in_L(b) for b in basis)
# index check: the 12 vectors generate a sublattice of D12+ of index 1 (determinant of D12+ is 1; in doubled coordinates 2^12)
import numpy as np
assert round(abs(np.linalg.det(np.array(basis, dtype=float)))) == 2 ** 12
def cls(w):   # class of w modulo 2 D12+ via coordinates in the basis
    c = np.linalg.solve(np.array(basis, dtype=float).T, np.array(w, dtype=float))
    return tuple(int(round(x)) % 2 for x in c)
norm = {}
for coef in itertools.product([0, 1], repeat=12):
    w = [sum(c * b[j] for c, b in zip(coef, basis)) for j in range(12)]
    n4 = (sum(x * x for x in w) // 4) % 4
    norm[coef] = n4
from collections import Counter
print('norm residues mod 4 over the 4096 classes:', dict(sorted(Counter(norm.values()).items())))
short = [tuple(4 * s if j == i else 0 for j in range(12)) for i in range(12) for s in (1, -1)]
for S in itertools.combinations(range(12), 4):
    for sg in itertools.product([2, -2], repeat=4):
        w = [0] * 12
        for i, s in zip(S, sg): w[i] = s
        short.append(tuple(w))
assert all(in_L(w) and sum(x * x for x in w) == 16 for w in short)
covered = {cls(w) for w in short}
target = {c for c, n in norm.items() if n == 0 and any(c)}
print('integer norm-4 vectors:', len(short), ' nonzero classes of norm 0 mod 4:', len(target), ' covered:', len(covered & target), ' all covered:', target <= covered)
# packing comparisons (4.3)
pi_lo = Fr(157, 50)
a = pi_lo ** 7 / (factorial(7) * 16); b = Fr(2 ** 15 * factorial(7)) * pi_lo ** 7 / (factorial(15) * 12)
print('rank 14: %.7f > 0.0352392080 %s ; rank 15: %.7f > 0.0256118267 %s' % (float(a), a > Fr('0.0352392080'), float(b), b > Fr('0.0256118267')))
print('sqrt(128) < 12:', 128 < 144, ' pi > 157/50: yes (3.14 < 3.14159...)')
# three-point bound would not suffice in rank 15: vol(B15)/sqrt(128) vs 0.033757
import math
print('vol(B15)/sqrt(128) = %.6f (three-point bound 0.033757, Cohn-Elkies LP ~0.0342); vol(B14)/16 = %.6f (three-point 0.045062)' % (math.pi ** 7.5 / math.gamma(8.5) / math.sqrt(128), math.pi ** 7 / 5040 / 16))
# Gaussian binomials
def gb(n, k, q):
    num = den = 1
    for i in range(k): num *= q ** (n - i) - 1; den *= q ** (i + 1) - 1
    return num // den
print('[4,2]_7, [3,2]_7, [2,1]_7 =', gb(4, 2, 7), gb(3, 2, 7), gb(2, 1, 7), ' [6,4]_2 =', gb(6, 4, 2), ' [7,4]_2 =', gb(7, 4, 2))
