# Per class of the genus: intrinsic K8 structure on X = L0/2L0*, root classes, dual units,
# admissible norm-5 vectors, and LP feasibility of each of the eight geometries.
import json, itertools, sys
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog
from genus_lib import *
classes = json.load(open('genus_classes.json'))
code_class = json.load(open('code_class.json'))

def nullspace_mod2(M):   # rows r with r.M = 0 mod 2
    A = [list(col) for col in zip(*M)]             # transpose: solve A^T ... we want left kernel of M = kernel of M^T
    rows = len(M); cols = len(M[0])
    # kernel of M^T (cols x rows matrix acting on row vectors r of length rows)
    Mt = [[M[i][j] % 2 for i in range(rows)] for j in range(cols)]
    piv = []; r = 0; Mt = [row[:] for row in Mt]
    for c in range(rows):
        k = next((i for i in range(r, len(Mt)) if Mt[i][c]), None)
        if k is None: continue
        Mt[r], Mt[k] = Mt[k], Mt[r]
        for i in range(len(Mt)):
            if i != r and Mt[i][c]: Mt[i] = [a ^ b for a, b in zip(Mt[i], Mt[r])]
        piv.append(c); r += 1
    free = [c for c in range(rows) if c not in piv]; ker = []
    for f in free:
        v = [0] * rows; v[f] = 1
        for i, p in enumerate(piv):
            if Mt[i][f]: v[p] = 1
        ker.append(v)
    return ker, r

out = []
for ci, c in enumerate(classes):
    G = np.array(c['gram'], dtype=np.int64); Gp = pm(c['gram'])
    Mi = pari('2') * Gp ** -1; M = np.array(tolist(Mi), dtype=np.int64)
    ker, rk = nullspace_mod2(M.tolist()); assert rk == 8 and len(ker) == 7
    K = np.array(ker, dtype=np.int64)
    pi = lambda x: tuple(int(v) for v in (K @ np.array(x)) % 2)
    # representatives of the 128 classes
    reps = {}
    for x in itertools.product([0, 1], repeat=15):
        k = pi(x)
        if k not in reps:
            reps[k] = np.array(x, dtype=np.int64)
            if len(reps) == 128: break
    assert len(reps) == 128
    q = {k: int(x @ G @ x) % 4 for k, x in reps.items()}
    def b(k1, k2): return int(reps[k1] @ G @ reps[k2]) % 2
    # well-definedness spot check: q of rep + element of 2L0*
    for k, x in list(reps.items())[:20]:
        y = x + M[:, 3]; assert int(y @ G @ y) % 4 == q[k]
    n2 = [k for k in reps if q[k] == 2]; n1 = [k for k in reps if q[k] == 1]
    assert len(n2) == 28 and len(n1) == 28
    adj = {k: {l for l in n2 if l != k and b(k, l) == 1} for k in n2}
    assert all(len(v) == 12 for v in adj.values())
    cl = []
    def ext(cur, cand):
        if len(cur) == 7: cl.append(frozenset(cur)); return
        for x in sorted(cand):
            if x > cur[-1]: ext(cur + [x], cand & adj[x])
    for a in sorted(n2): ext([a], set(adj[a]))
    stars = sorted(set(cl), key=sorted); assert len(stars) == 8
    vert = {k: tuple(i for i, s in enumerate(stars) if k in s) for k in n2}
    assert all(len(v) == 2 for v in vert.values())
    char = [k for k in reps if all(b(k, l) == q[l] % 2 for l in reps)]; assert len(char) == 1; char = char[0]
    addk = lambda k1, k2: tuple((a + b_) % 2 for a, b_ in zip(k1, k2))
    # roots and units
    sv = short_vectors(c['gram'], 2)
    roots = [v for v in sv if int(np.array(v) @ G @ np.array(v)) == 2]
    units_L0 = [v for v in sv if int(np.array(v) @ G @ np.array(v)) == 1]
    rootcount = [0] * 8
    for v in roots:
        k = pi(v); assert q[k] == 2
        for w in vert[k]: rootcount[w] += 1
    du = short_vectors(M.tolist(), 2)
    dunits = np.array([v for v in du if int(np.array(v) @ M @ np.array(v)) == 2], dtype=np.int64)   # dual-basis coordinates
    # orthogonal dual-unit frame size (greedy + small search)
    Du = dunits @ M @ dunits.T
    best = 0
    def grow(sel, cand):
        global best
        best = max(best, len(sel))
        if best >= 7: return
        for i in cand:
            grow(sel + [i], [j for j in cand if j > i and Du[i, j] == 0])
            if best >= 7: return
    best = 0; grow([], list(range(len(dunits))))
    # norm-5 vectors
    s5 = short_vectors(c['gram'], 5)
    V5 = np.array([v for v in s5 if int(np.array(v) @ G @ np.array(v)) == 5], dtype=np.int64)
    pair = np.abs(V5 @ dunits.T)                       # |(u,p)|
    adm = pair.max(axis=1) <= 1
    cls5 = [pi(v) for v in V5]
    geo = []
    for w in range(8):
        req = [addk(char, k) for k in n2 if w not in vert[k]]
        assert len(req) == 21 and all(q[k] == 1 for k in req)
        idx = {k: [i for i in range(len(V5)) if adm[i] and cls5[i] == k] for k in req}
        raw = {k: sum(1 for i in range(len(V5)) if cls5[i] == k) for k in req}
        if any(len(v) == 0 for v in idx.values()):
            geo.append(dict(vertex=w, roots=rootcount[w], status='empty-domain', min_raw=min(raw.values()))); continue
        cols = [i for k in req for i in idx[k]]
        A = []; rhs = []
        for k in req:
            A.append([1.0 if cls5[i] == k else 0.0 for i in cols]); rhs.append(2.0)
        for u in range(len(dunits)):
            A.append([1.0 if pair[i, u] else 0.0 for i in cols]); rhs.append(14.0)
        res = linprog(np.zeros(len(cols)), A_eq=np.array(A), b_eq=np.array(rhs), bounds=(0, None), method='highs')
        geo.append(dict(vertex=w, roots=rootcount[w], status='lp-feasible' if res.status == 0 else ('lp-infeasible' if res.status == 2 else f'lp-status-{res.status}'), nvars=len(cols)))
    src = [f'code{i}' for i, k in enumerate(code_class) if k == ci] or ['mixed']
    rec = dict(cls=ci, src=src, aut=c['aut'], units_L0=len(units_L0), roots_L0=len(roots), dual_unit_lines=len(dunits), orth_frame=best, norm5=len(V5), admissible5=int(adm.sum()), geo=geo)
    out.append(rec)
    print(ci, src, 'roots', len(roots), 'units', len(units_L0), 'dual unit lines', len(dunits), 'frame>=', best, 'norm5 lines', len(V5), 'adm', int(adm.sum()),
          '| roots at vertices', rootcount, '|', [g['status'][:6] for g in geo], flush=True)
json.dump(out, open('genus_atlas.json', 'w'), indent=0)
