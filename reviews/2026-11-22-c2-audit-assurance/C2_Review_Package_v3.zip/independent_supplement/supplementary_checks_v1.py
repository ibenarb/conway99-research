"""Independent finite checks supporting the review manuscript. Python 3, stdlib only."""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations, product
from math import factorial
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent

def circuit_checks():
    points = list(range(1, 16))
    code = []
    for a in range(16):
        code.append(sum((1 << (v - 1)) for v in points if (a & v).bit_count() % 2))
    assert len(set(code)) == 16
    assert Counter(x.bit_count() for x in code) == {0: 1, 8: 15}
    circuits = []
    for subset in combinations(points, 5):
        xor = 0
        for v in subset:
            xor ^= v
        if xor:
            continue
        for size in range(1, 5):
            for proper in combinations(subset, size):
                y = 0
                for v in proper:
                    y ^= v
                assert y
        circuits.append(sum(1 << (v - 1) for v in subset))
    cosets = Counter(min(x ^ c for c in code) for x in circuits)
    assert len(circuits) == 168
    assert len(cosets) == 28
    assert set(cosets.values()) == {6}
    return {"simplex_code_weight_distribution": {"0": 1, "8": 15},
            "five_circuits": 168, "cosets": 28, "circuits_per_coset": 6}

def d12_checks():
    # Basis: e_i-e_12 (i=1,...,10), 2e_12, (1/2,...,1/2).
    # All vectors are represented by doubled physical coordinates.
    basis = []
    for i in range(10):
        b = [0] * 12
        b[i], b[11] = 2, -2
        basis.append(b)
    basis.append([0] * 11 + [4])
    basis.append([1] * 12)

    def residue(w):
        a = [(w[i] - w[10]) // 2 for i in range(10)]
        assert all(2 * a[i] == w[i] - w[10] for i in range(10))
        b = (w[11] + 2 * sum(a) - w[10]) // 4
        assert 4 * b == w[11] + 2 * sum(a) - w[10]
        coeff = a + [b, w[10]]
        assert [sum(coeff[j] * basis[j][i] for j in range(12)) for i in range(12)] == list(w)
        return sum((c % 2) << j for j, c in enumerate(coeff))

    counts = Counter()
    qzero = set()
    for mask in range(4096):
        w = [sum(basis[j][i] for j in range(12) if mask >> j & 1) for i in range(12)]
        assert residue(w) == mask
        four_norm = sum(t * t for t in w)
        assert four_norm % 4 == 0
        q = (four_norm // 4) % 4
        counts[q] += 1
        if q == 0:
            qzero.add(mask)
    covered = set()
    enumerated = 0
    for i in range(12):
        for sign in (-1, 1):
            w = [0] * 12
            w[i] = 4 * sign
            covered.add(residue(w))
            enumerated += 1
    for support in combinations(range(12), 4):
        for signs in product((-1, 1), repeat=4):
            w = [0] * 12
            for i, s in zip(support, signs):
                w[i] = 2 * s
            covered.add(residue(w))
            enumerated += 1
    assert enumerated == 7944
    assert covered == qzero - {0}
    return {"residue_classes": 4096, "norm_mod_4_distribution": dict(sorted(counts.items())),
            "nonzero_norm_0_mod_4_classes": len(qzero) - 1,
            "norm_4_vectors_enumerated": enumerated,
            "all_nonzero_norm_0_mod_4_classes_represented_by_norm_4": True}

def packing_checks():
    # pi > 3.14; sqrt(128) < 12. These deliberately weaker rational
    # lower bounds suffice against the certified exact decimal bounds.
    pi_lower = Q(157, 50)
    lower15 = Q(2**15 * factorial(7), factorial(15) * 12) * pi_lower**7
    lower14 = pi_lower**7 / (factorial(7) * 16)
    upper14 = Q("0.0352392080")
    upper15 = Q("0.0256118267")
    assert lower14 > upper14
    assert lower15 > upper15
    def data(lo, hi):
        return {"lower_bound": str(lo), "certified_upper_bound": str(hi),
                "positive_gap": str(lo - hi), "approx_lower": float(lo)}
    return {"dimension_14": data(lower14, upper14), "dimension_15": data(lower15, upper15)}

def finite_geometry_counts():
    def gaussian(n, k, q):
        z = Q(1)
        for i in range(k):
            z *= Q(q**(n-i) - 1, q**(k-i) - 1)
        assert z.denominator == 1
        return int(z)
    values = {"two_planes_in_F7_4": gaussian(4, 2, 7),
              "two_planes_in_F7_3": gaussian(3, 2, 7),
              "lines_in_F7_2": gaussian(2, 1, 7)}
    assert list(values.values()) == [2850, 57, 8]
    return values

def main():
    result = {"status": "INDEPENDENT_PUBLICATION_SUPPLEMENT_PASS",
              "scope": "Finite supplementary lemmas only; not an independent complete C2 solver.",
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "simplex": circuit_checks(), "D12_plus": d12_checks(),
              "packing_comparisons": packing_checks(),
              "finite_geometry_counts": finite_geometry_counts()}
    output = ROOT / "supplementary_checks_v1.json"
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
