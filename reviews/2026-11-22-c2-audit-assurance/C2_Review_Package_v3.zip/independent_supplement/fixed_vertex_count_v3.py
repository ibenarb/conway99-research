"""Independent additive-state check of the fixed-vertex integer conditions.
No imports from the original solver. Enumerating aggregate sums by repeated
Minkowski addition covers every assignment of a local type to f fixed vertices.
"""
from pathlib import Path
from collections import defaultdict
import json

types = defaultdict(list)
for a in range(7):
    for b in range(8):
        for c in range(4):
            if a + b + 2 * c == 7:
                types[1 + 2 * a * a + 2 * c].append((a, b, c))

rows = []
survivors = []
for fixed, local in sorted(types.items()):
    aggregates = {(0, 0, 0)}
    for _ in range(fixed):
        aggregates = {
            (sa + a, sb + b, sc + c)
            for sa, sb, sc in aggregates for a, b, c in local
        }
    n = (99 - fixed) // 2
    kept = []
    for total_a, adjacent, two_fixed in sorted(aggregates):
        unpaired = n - adjacent - two_fixed
        trace = 4 * n - adjacent
        if (total_a % 3 == 0 and unpaired >= 0 and unpaired % 2 == 0
                and trace % 7 == 0 and 0 <= trace // 7 <= n):
            kept.append([fixed, n, adjacent, two_fixed, unpaired])
    survivors.extend(kept)
    rows.append({"fixed": fixed, "local_types": local,
                 "aggregate_count": len(aggregates), "survivors": kept})
assert survivors == [[1, 49, 7, 0, 42]], survivors
assert 476 + 3212 + 88 + 2638 == 6414
assert 2638 + 518 == 3156
result = {"status": "PASS", "survivors": survivors, "all_fixed_sizes": rows}
Path(__file__).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": "PASS", "survivors": survivors}))
