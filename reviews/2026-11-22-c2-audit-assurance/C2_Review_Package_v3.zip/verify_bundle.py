"""Verify a local review bundle, Python standard library only."""
from pathlib import Path
import hashlib
root = Path(__file__).resolve().parent
count = 0
for line in (root / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
    digest, name = line.split("  ", 1)
    path = (root / name).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Manifest path leaves bundle")
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise ValueError("Digest mismatch: " + name)
    count += 1
print("PASS:", count, "files verified")
