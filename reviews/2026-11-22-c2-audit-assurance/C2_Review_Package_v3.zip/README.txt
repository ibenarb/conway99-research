C2 REVIEW DOSSIER — VERSION 3 — 22 NOVEMBER 2026

Start with C2_Manuscript_v3.pdf, then C2_Reviewer_Memorandum_v3.pdf.
The latter is now a response and focused follow-up, not a request to repeat
the first review. The complete received referee report includes its
asymmetry addendum.

CLAIMS AND STATUS
Zhang's C2 exclusion is accepted in the AI-assisted project referee report,
with the implementation-diversity qualifications stated there. This is not
journal acceptance. Combined asymmetry additionally uses Djematene's full
C3 result and the published Behbahani–Lam prime-divisor restriction.
The published order-7/order-11 computations have not been replayed here.
Graph existence remains open. Authorship and publication consent are pending.

The first-layer singleton-root search still has no complete independent
second implementation. The referee's second solver covers terminals and
samples, not all high-rank and rank-8/rank-9 jobs. The genus alternative
is supplied but only partly checked by the project; the original packing
route remains in the main proof. No original search source was changed.

CONTENTS AND REPRODUCTION
manuscript_source/: editable LaTeX. Compile the two main .tex files with
pdfLaTeX until references stabilize. PDFs are ready for reading.

independent_supplement/: standalone standard-library Python checkers for
the small supplementary enumerations and the self-contained fixed-point count.

records/ and review_code/: INTERNAL INSPECTION NOTES. Receipts are marked
exports and workspace-dependent scripts are not runnable as a portable
bundle. Do not use them as a substitute for the original frozen replay packets.

transcripts/: checked project replay evidence, with original/export hashes
distinguished where local paths were normalized.

referee/: the full report supplied by the project owner, response matrix,
and unchanged received evidence files. The original evidence README defines
the referee programs' environment and layout. Inclusion is not a claim that
all those programs were rerun or reviewed by the project. The project
evidence audit export records exactly which files/claims were checked.

c3_integrity/: original repository checksum list and read-only comparison.
Five logs disagree with that list while their Git blob hashes agree.
All 24 checked Lean sources and the archived Actions log match. The cause
of the five differences is unresolved; no source checksum was rewritten.

ORIGINAL FROZEN SEARCH PACKETS
Obtain the three archives in review_index.json at the pinned public URLs,
verify hashes and follow their original instructions. Python 3.10+,
GNU C++17 and, for the unsigned packet, GMP C++ headers are required.
ASSERTIONS MUST BE ACTIVE: NDEBUG MUST NOT BE DEFINED.
Audit/quick modes do not replace full scope coverage.

The optional uniform replay was completed BY THE AUTHOR. The referee
validated its supplied transcripts (3156 keys, 446227 anchors, none open).
Neither the project nor referee re-executed that uniform replay.
No fresh C3 Lean build is claimed.

verify_bundle.py checks MANIFEST.sha256 with Python's standard library.
The manifest identifies bytes; it does not certify mathematical correctness.
No private correspondence is included. No material has been sent or published.
