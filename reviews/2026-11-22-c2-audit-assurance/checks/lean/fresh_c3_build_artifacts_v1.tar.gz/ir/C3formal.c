// Lean compiler output
// Module: C3formal
// Imports: public import Init public meta import Init public import C3formal.Eis public import C3formal.Step5 public import C3formal.Saturated public import C3formal.EisEuclid public import C3formal.EisComplex public import C3formal.NumberTheory public import C3formal.IntPart public import C3formal.Main public import C3formal.Bridge public import C3formal.Graph public import C3formal.SaturatedGen public import C3formal.GenLemmas public import C3formal.TriangleMatrix public import C3formal.TriangleMain public import C3formal.TriangleStep5 public import C3formal.TriangleStep4 public import C3formal.TriangleBridge public import C3formal.TriangleGraph public import C3formal.FixLemma
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Eis(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Step5(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Saturated(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_EisEuclid(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_EisComplex(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_NumberTheory(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_IntPart(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Main(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Bridge(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Graph(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_SaturatedGen(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_GenLemmas(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleMatrix(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleMain(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleStep5(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleStep4(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleBridge(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleGraph(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_FixLemma(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Eis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Step5(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Saturated(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_EisEuclid(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_EisComplex(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_NumberTheory(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_IntPart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Main(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Bridge(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Graph(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_SaturatedGen(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_GenLemmas(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleMatrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleMain(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleStep5(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleStep4(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleBridge(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleGraph(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_FixLemma(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
