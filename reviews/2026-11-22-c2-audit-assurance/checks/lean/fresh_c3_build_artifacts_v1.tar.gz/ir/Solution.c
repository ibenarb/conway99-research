// Lean compiler output
// Module: Solution
// Imports: public import Init public meta import Init public import C3formal.FixLemma public import Mathlib.Combinatorics.SimpleGraph.StronglyRegular public import Mathlib.Algebra.Order.Group.End public import Mathlib.GroupTheory.OrderOfElement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_div(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf___redArg();
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_Conway99_rook3(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_rook3___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_shift3(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_shift3___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_rookGraph;
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph___aux__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph___aux__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Conway99_shiftAut___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Conway99_shift3___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Conway99_shiftAut___closed__0 = (const lean_object*)&lp_c3formal_Conway99_shiftAut___closed__0_value;
static lean_once_cell_t lp_c3formal_Conway99_shiftAut___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Conway99_shiftAut___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_Conway99_shiftAut;
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf___redArg(){
_start:
{
lean_object* v___x_2_; 
v___x_2_ = lean_box(0);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf___redArg___boxed(lean_object* v___dummy_3_){
_start:
{
lean_object* v_res_4_; 
v_res_4_ = lp_c3formal_Conway99_graphOf___redArg();
return v_res_4_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf(lean_object* v_n_5_, lean_object* v_adj_6_, lean_object* v_h__symm_7_, lean_object* v_h__loop_8_){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lean_box(0);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_graphOf___boxed(lean_object* v_n_10_, lean_object* v_adj_11_, lean_object* v_h__symm_12_, lean_object* v_h__loop_13_){
_start:
{
lean_object* v_res_14_; 
v_res_14_ = lp_c3formal_Conway99_graphOf(v_n_10_, v_adj_11_, v_h__symm_12_, v_h__loop_13_);
lean_dec_ref(v_adj_11_);
lean_dec(v_n_10_);
return v_res_14_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1___redArg(lean_object* v_adj_15_, lean_object* v_i_16_, lean_object* v_j_17_){
_start:
{
lean_object* v___x_18_; uint8_t v___x_19_; 
v___x_18_ = lean_apply_2(v_adj_15_, v_i_16_, v_j_17_);
v___x_19_ = lean_unbox(v___x_18_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1___redArg___boxed(lean_object* v_adj_20_, lean_object* v_i_21_, lean_object* v_j_22_){
_start:
{
uint8_t v_res_23_; lean_object* v_r_24_; 
v_res_23_ = lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1___redArg(v_adj_20_, v_i_21_, v_j_22_);
v_r_24_ = lean_box(v_res_23_);
return v_r_24_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1(lean_object* v_n_25_, lean_object* v_adj_26_, lean_object* v_h__symm_27_, lean_object* v_h__loop_28_, lean_object* v_i_29_, lean_object* v_j_30_){
_start:
{
lean_object* v___x_31_; uint8_t v___x_32_; 
v___x_31_ = lean_apply_2(v_adj_26_, v_i_29_, v_j_30_);
v___x_32_ = lean_unbox(v___x_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1___boxed(lean_object* v_n_33_, lean_object* v_adj_34_, lean_object* v_h__symm_35_, lean_object* v_h__loop_36_, lean_object* v_i_37_, lean_object* v_j_38_){
_start:
{
uint8_t v_res_39_; lean_object* v_r_40_; 
v_res_39_ = lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___aux__1(v_n_33_, v_adj_34_, v_h__symm_35_, v_h__loop_36_, v_i_37_, v_j_38_);
lean_dec(v_n_33_);
v_r_40_ = lean_box(v_res_39_);
return v_r_40_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___redArg(lean_object* v_adj_41_, lean_object* v_i_42_, lean_object* v_j_43_){
_start:
{
lean_object* v___x_44_; uint8_t v___x_45_; 
v___x_44_ = lean_apply_2(v_adj_41_, v_i_42_, v_j_43_);
v___x_45_ = lean_unbox(v___x_44_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___redArg___boxed(lean_object* v_adj_46_, lean_object* v_i_47_, lean_object* v_j_48_){
_start:
{
uint8_t v_res_49_; lean_object* v_r_50_; 
v_res_49_ = lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___redArg(v_adj_46_, v_i_47_, v_j_48_);
v_r_50_ = lean_box(v_res_49_);
return v_r_50_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf(lean_object* v_n_51_, lean_object* v_adj_52_, lean_object* v_h__symm_53_, lean_object* v_h__loop_54_, lean_object* v_i_55_, lean_object* v_j_56_){
_start:
{
lean_object* v___x_57_; uint8_t v___x_58_; 
v___x_57_ = lean_apply_2(v_adj_52_, v_i_55_, v_j_56_);
v___x_58_ = lean_unbox(v___x_57_);
return v___x_58_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf___boxed(lean_object* v_n_59_, lean_object* v_adj_60_, lean_object* v_h__symm_61_, lean_object* v_h__loop_62_, lean_object* v_i_63_, lean_object* v_j_64_){
_start:
{
uint8_t v_res_65_; lean_object* v_r_66_; 
v_res_65_ = lp_c3formal_Conway99_instDecidableRelFinAdjGraphOf(v_n_59_, v_adj_60_, v_h__symm_61_, v_h__loop_62_, v_i_63_, v_j_64_);
lean_dec(v_n_59_);
v_r_66_ = lean_box(v_res_65_);
return v_r_66_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf___redArg___lam__0(lean_object* v_00_u03c3_67_, lean_object* v_i_68_){
_start:
{
lean_object* v___x_69_; lean_object* v___x_70_; 
lean_inc_ref(v_00_u03c3_67_);
v___x_69_ = lean_apply_1(v_00_u03c3_67_, v_i_68_);
v___x_70_ = lean_apply_1(v_00_u03c3_67_, v___x_69_);
return v___x_70_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf___redArg(lean_object* v_00_u03c3_71_){
_start:
{
lean_object* v___f_72_; lean_object* v___x_73_; 
lean_inc_ref(v_00_u03c3_71_);
v___f_72_ = lean_alloc_closure((void*)(lp_c3formal_Conway99_autOf___redArg___lam__0), 2, 1);
lean_closure_set(v___f_72_, 0, v_00_u03c3_71_);
v___x_73_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_73_, 0, v_00_u03c3_71_);
lean_ctor_set(v___x_73_, 1, v___f_72_);
return v___x_73_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf(lean_object* v_n_74_, lean_object* v_adj_75_, lean_object* v_h__symm_76_, lean_object* v_h__loop_77_, lean_object* v_00_u03c3_78_, lean_object* v_h__aut_79_, lean_object* v_h__cube_80_){
_start:
{
lean_object* v___x_81_; 
v___x_81_ = lp_c3formal_Conway99_autOf___redArg(v_00_u03c3_78_);
return v___x_81_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_autOf___boxed(lean_object* v_n_82_, lean_object* v_adj_83_, lean_object* v_h__symm_84_, lean_object* v_h__loop_85_, lean_object* v_00_u03c3_86_, lean_object* v_h__aut_87_, lean_object* v_h__cube_88_){
_start:
{
lean_object* v_res_89_; 
v_res_89_ = lp_c3formal_Conway99_autOf(v_n_82_, v_adj_83_, v_h__symm_84_, v_h__loop_85_, v_00_u03c3_86_, v_h__aut_87_, v_h__cube_88_);
lean_dec_ref(v_adj_83_);
lean_dec(v_n_82_);
return v_res_89_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_Conway99_rook3(lean_object* v_i_90_, lean_object* v_j_91_){
_start:
{
uint8_t v___x_92_; 
v___x_92_ = lean_nat_dec_eq(v_i_90_, v_j_91_);
if (v___x_92_ == 0)
{
lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; uint8_t v___x_96_; 
v___x_93_ = lean_unsigned_to_nat(3u);
v___x_94_ = lean_nat_div(v_i_90_, v___x_93_);
v___x_95_ = lean_nat_div(v_j_91_, v___x_93_);
v___x_96_ = lean_nat_dec_eq(v___x_94_, v___x_95_);
lean_dec(v___x_95_);
lean_dec(v___x_94_);
if (v___x_96_ == 0)
{
lean_object* v___x_97_; lean_object* v___x_98_; uint8_t v___x_99_; 
v___x_97_ = lean_nat_mod(v_i_90_, v___x_93_);
v___x_98_ = lean_nat_mod(v_j_91_, v___x_93_);
v___x_99_ = lean_nat_dec_eq(v___x_97_, v___x_98_);
lean_dec(v___x_98_);
lean_dec(v___x_97_);
return v___x_99_;
}
else
{
return v___x_96_;
}
}
else
{
uint8_t v___x_100_; 
v___x_100_ = 0;
return v___x_100_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_rook3___boxed(lean_object* v_i_101_, lean_object* v_j_102_){
_start:
{
uint8_t v_res_103_; lean_object* v_r_104_; 
v_res_103_ = lp_c3formal_Conway99_rook3(v_i_101_, v_j_102_);
lean_dec(v_j_102_);
lean_dec(v_i_101_);
v_r_104_ = lean_box(v_res_103_);
return v_r_104_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_shift3(lean_object* v_i_105_){
_start:
{
lean_object* v___x_106_; lean_object* v___x_107_; lean_object* v___x_108_; lean_object* v___x_109_; 
v___x_106_ = lean_unsigned_to_nat(9u);
v___x_107_ = lean_unsigned_to_nat(3u);
v___x_108_ = lean_nat_add(v_i_105_, v___x_107_);
v___x_109_ = lean_nat_mod(v___x_108_, v___x_106_);
lean_dec(v___x_108_);
return v___x_109_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_shift3___boxed(lean_object* v_i_110_){
_start:
{
lean_object* v_res_111_; 
v_res_111_ = lp_c3formal_Conway99_shift3(v_i_110_);
lean_dec(v_i_110_);
return v_res_111_;
}
}
static lean_object* _init_lp_c3formal_Conway99_rookGraph(void){
_start:
{
lean_object* v___x_112_; 
v___x_112_ = lean_box(0);
return v___x_112_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph___aux__1(lean_object* v_a_113_, lean_object* v_b_114_){
_start:
{
uint8_t v___x_115_; 
v___x_115_ = lp_c3formal_Conway99_rook3(v_a_113_, v_b_114_);
return v___x_115_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph___aux__1___boxed(lean_object* v_a_116_, lean_object* v_b_117_){
_start:
{
uint8_t v_res_118_; lean_object* v_r_119_; 
v_res_118_ = lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph___aux__1(v_a_116_, v_b_117_);
lean_dec(v_b_117_);
lean_dec(v_a_116_);
v_r_119_ = lean_box(v_res_118_);
return v_r_119_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph(lean_object* v_a_120_, lean_object* v_b_121_){
_start:
{
uint8_t v___x_122_; 
v___x_122_ = lp_c3formal_Conway99_rook3(v_a_120_, v_b_121_);
return v___x_122_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph___boxed(lean_object* v_a_123_, lean_object* v_b_124_){
_start:
{
uint8_t v_res_125_; lean_object* v_r_126_; 
v_res_125_ = lp_c3formal_Conway99_instDecidableRelFinOfNatNatAdjRookGraph(v_a_123_, v_b_124_);
lean_dec(v_b_124_);
lean_dec(v_a_123_);
v_r_126_ = lean_box(v_res_125_);
return v_r_126_;
}
}
static lean_object* _init_lp_c3formal_Conway99_shiftAut___closed__1(void){
_start:
{
lean_object* v___x_128_; lean_object* v___x_129_; 
v___x_128_ = ((lean_object*)(lp_c3formal_Conway99_shiftAut___closed__0));
v___x_129_ = lp_c3formal_Conway99_autOf___redArg(v___x_128_);
return v___x_129_;
}
}
static lean_object* _init_lp_c3formal_Conway99_shiftAut(void){
_start:
{
lean_object* v___x_130_; 
v___x_130_ = lean_obj_once(&lp_c3formal_Conway99_shiftAut___closed__1, &lp_c3formal_Conway99_shiftAut___closed__1_once, _init_lp_c3formal_Conway99_shiftAut___closed__1);
return v___x_130_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_FixLemma(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Combinatorics_SimpleGraph_StronglyRegular(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Algebra_Order_Group_End(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_GroupTheory_OrderOfElement(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_Solution(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_FixLemma(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Combinatorics_SimpleGraph_StronglyRegular(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Algebra_Order_Group_End(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_GroupTheory_OrderOfElement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_c3formal_Conway99_rookGraph = _init_lp_c3formal_Conway99_rookGraph();
lean_mark_persistent(lp_c3formal_Conway99_rookGraph);
lp_c3formal_Conway99_shiftAut = _init_lp_c3formal_Conway99_shiftAut();
lean_mark_persistent(lp_c3formal_Conway99_shiftAut);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
