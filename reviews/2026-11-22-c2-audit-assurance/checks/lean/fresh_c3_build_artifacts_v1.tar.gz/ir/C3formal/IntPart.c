// Lean compiler output
// Module: C3formal.IntPart
// Imports: public import Init public meta import Init public import C3formal.Step5 public import C3formal.Saturated public import C3formal.NumberTheory public import Mathlib.LinearAlgebra.Matrix.Block public import Mathlib.LinearAlgebra.Matrix.PosDef public import Mathlib.Data.Matrix.ColumnRowPartitioned public import Mathlib.Data.Int.Star public import Mathlib.Tactic.Module
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
lean_object* l_Lean_Name_num___override(lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l_String_toRawSubstring_x27(lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_Lean_Name_mkStr4(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
lean_object* l_Lean_SourceInfo_fromRef(lean_object*, uint8_t);
lean_object* l_Lean_addMacroScope(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_node1(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_node2(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_node3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_node5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "_private"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__0 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__0_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__0_value),LEAN_SCALAR_PTR_LITERAL(103, 214, 75, 80, 34, 198, 193, 153)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__1 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__1_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "C3formal"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__2 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__2_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__1_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__2_value),LEAN_SCALAR_PTR_LITERAL(225, 153, 193, 49, 232, 250, 186, 114)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__3 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__3_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "IntPart"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__4 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__4_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__3_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__4_value),LEAN_SCALAR_PTR_LITERAL(23, 24, 12, 185, 185, 3, 95, 251)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__5 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__5_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 2}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__5_value),((lean_object*)(((size_t)(0) << 1) | 1)),LEAN_SCALAR_PTR_LITERAL(170, 226, 30, 109, 35, 45, 207, 178)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__6 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__6_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "C3"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__7 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__7_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__6_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__7_value),LEAN_SCALAR_PTR_LITERAL(40, 111, 162, 205, 88, 253, 184, 8)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__8 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__8_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 5, .m_data = "term𝟙"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__9 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__9_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__8_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__9_value),LEAN_SCALAR_PTR_LITERAL(225, 182, 213, 56, 210, 221, 41, 128)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__10 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__10_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__11_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 1, .m_data = "𝟙"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__11 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__11_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 5}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__11_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__12 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__12_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 0, .m_other = 3, .m_tag = 3}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__10_value),((lean_object*)(((size_t)(1024) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__12_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__13 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__13_value;
LEAN_EXPORT const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__13_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Lean"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__0 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__0_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "Parser"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__1 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__1_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "Term"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__2 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__2_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "typeAscription"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__3 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__3_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__0_value),LEAN_SCALAR_PTR_LITERAL(70, 193, 83, 126, 233, 67, 208, 165)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value_aux_0),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__1_value),LEAN_SCALAR_PTR_LITERAL(103, 136, 125, 166, 167, 98, 71, 111)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value_aux_1),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__2_value),LEAN_SCALAR_PTR_LITERAL(75, 170, 162, 138, 136, 204, 251, 229)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value_aux_2),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__3_value),LEAN_SCALAR_PTR_LITERAL(247, 209, 88, 141, 5, 195, 49, 74)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 15, .m_capacity = 15, .m_length = 14, .m_data = "hygienicLParen"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__5 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__5_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__0_value),LEAN_SCALAR_PTR_LITERAL(70, 193, 83, 126, 233, 67, 208, 165)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value_aux_0),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__1_value),LEAN_SCALAR_PTR_LITERAL(103, 136, 125, 166, 167, 98, 71, 111)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value_aux_1),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__2_value),LEAN_SCALAR_PTR_LITERAL(75, 170, 162, 138, 136, 204, 251, 229)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value_aux_2),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__5_value),LEAN_SCALAR_PTR_LITERAL(41, 104, 206, 51, 21, 254, 100, 101)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "("};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__7 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__7_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "hygieneInfo"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__8 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__8_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__8_value),LEAN_SCALAR_PTR_LITERAL(27, 64, 36, 144, 170, 151, 255, 136)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__9 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__9_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__10 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__10_value;
static lean_once_cell_t lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__11;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__12_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__7_value),LEAN_SCALAR_PTR_LITERAL(13, 230, 96, 19, 169, 180, 122, 64)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__12 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__12_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__13_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__12_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__13 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__13_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__14_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = "Matrix"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__14 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__14_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__15_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__14_value),LEAN_SCALAR_PTR_LITERAL(214, 58, 148, 51, 223, 251, 16, 41)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__15 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__15_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__16_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__15_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__16 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__16_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__17_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__16_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__17 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__17_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__18_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__13_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__17_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__18 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__18_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__19_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "num"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__19 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__19_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__20_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__19_value),LEAN_SCALAR_PTR_LITERAL(227, 68, 22, 222, 47, 51, 204, 84)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__20 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__20_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__21_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__21 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__21_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__22_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ":"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__22 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__22_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__23_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 5, .m_capacity = 5, .m_length = 4, .m_data = "null"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__23 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__23_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__24_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__23_value),LEAN_SCALAR_PTR_LITERAL(24, 58, 49, 223, 146, 207, 197, 136)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__24 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__24_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__25_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "app"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__25 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__25_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__0_value),LEAN_SCALAR_PTR_LITERAL(70, 193, 83, 126, 233, 67, 208, 165)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value_aux_0),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__1_value),LEAN_SCALAR_PTR_LITERAL(103, 136, 125, 166, 167, 98, 71, 111)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value_aux_1),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__2_value),LEAN_SCALAR_PTR_LITERAL(75, 170, 162, 138, 136, 204, 251, 229)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value_aux_2),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__25_value),LEAN_SCALAR_PTR_LITERAL(69, 118, 10, 41, 220, 156, 243, 179)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26_value;
static lean_once_cell_t lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__27_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__27;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__28_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__15_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__28 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__28_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__29_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__28_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__17_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__29 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__29_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__30_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "paren"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__30 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__30_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__0_value),LEAN_SCALAR_PTR_LITERAL(70, 193, 83, 126, 233, 67, 208, 165)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value_aux_0),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__1_value),LEAN_SCALAR_PTR_LITERAL(103, 136, 125, 166, 167, 98, 71, 111)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value_aux_2 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value_aux_1),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__2_value),LEAN_SCALAR_PTR_LITERAL(75, 170, 162, 138, 136, 204, 251, 229)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value_aux_2),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__30_value),LEAN_SCALAR_PTR_LITERAL(124, 9, 161, 194, 227, 100, 20, 110)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__32_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "Fin"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__32 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__32_value;
static lean_once_cell_t lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__33_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__33;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__34_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__32_value),LEAN_SCALAR_PTR_LITERAL(62, 91, 162, 2, 110, 238, 123, 219)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__34 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__34_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__35_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__34_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__35 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__35_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__36_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__34_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__36 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__36_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__37_value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__14_value),LEAN_SCALAR_PTR_LITERAL(214, 58, 148, 51, 223, 251, 16, 41)}};
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__37_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__37_value_aux_0),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__32_value),LEAN_SCALAR_PTR_LITERAL(135, 20, 195, 73, 15, 107, 29, 210)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__37 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__37_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__38_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 0}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__37_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__38 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__38_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__39_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__38_value),((lean_object*)(((size_t)(0) << 1) | 1))}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__39 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__39_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__40_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__36_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__39_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__40 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__40_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__41_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 0, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__35_value),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__40_value)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__41 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__41_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__42_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 3, .m_capacity = 3, .m_length = 2, .m_data = "33"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__42 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__42_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__43_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = ")"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__43 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__43_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__44_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 5, .m_data = "termℤ"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__44 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__44_value;
static const lean_ctor_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__45_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__44_value),LEAN_SCALAR_PTR_LITERAL(233, 223, 72, 110, 220, 141, 14, 239)}};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__45 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__45_value;
static const lean_string_object lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__46_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 1, .m_data = "ℤ"};
static const lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__46 = (const lean_object*)&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__46_value;
LEAN_EXPORT lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_ones___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_ones___redArg___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_ones___redArg();
LEAN_EXPORT lean_object* lp_c3formal_C3_ones___redArg___boxed(lean_object*);
static lean_once_cell_t lp_c3formal_C3_ones___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_ones___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_ones(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_ones___boxed(lean_object*);
static lean_object* _init_lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__11(void){
_start:
{
lean_object* v___x_52_; lean_object* v___x_53_; 
v___x_52_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__10));
v___x_53_ = l_String_toRawSubstring_x27(v___x_52_);
return v___x_53_;
}
}
static lean_object* _init_lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__27(void){
_start:
{
lean_object* v___x_83_; lean_object* v___x_84_; 
v___x_83_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__14));
v___x_84_ = l_String_toRawSubstring_x27(v___x_83_);
return v___x_84_;
}
}
static lean_object* _init_lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__33(void){
_start:
{
lean_object* v___x_98_; lean_object* v___x_99_; 
v___x_98_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__32));
v___x_99_ = l_String_toRawSubstring_x27(v___x_98_);
return v___x_99_;
}
}
LEAN_EXPORT lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1(lean_object* v_x_127_, lean_object* v_a_128_, lean_object* v_a_129_){
_start:
{
lean_object* v___x_130_; lean_object* v___x_131_; uint8_t v___x_132_; 
v___x_130_ = lean_box(0);
v___x_131_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3_term_U0001d7d9___closed__10));
v___x_132_ = l_Lean_Syntax_isOfKind(v_x_127_, v___x_131_);
if (v___x_132_ == 0)
{
lean_object* v___x_133_; lean_object* v___x_134_; 
v___x_133_ = lean_box(1);
v___x_134_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v___x_134_, 0, v___x_133_);
lean_ctor_set(v___x_134_, 1, v_a_129_);
return v___x_134_;
}
else
{
lean_object* v_quotContext_135_; lean_object* v_currMacroScope_136_; lean_object* v_ref_137_; uint8_t v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_154_; lean_object* v___x_155_; lean_object* v___x_156_; lean_object* v___x_157_; lean_object* v___x_158_; lean_object* v___x_159_; lean_object* v___x_160_; lean_object* v___x_161_; lean_object* v___x_162_; lean_object* v___x_163_; lean_object* v___x_164_; lean_object* v___x_165_; lean_object* v___x_166_; lean_object* v___x_167_; lean_object* v___x_168_; lean_object* v___x_169_; lean_object* v___x_170_; lean_object* v___x_171_; lean_object* v___x_172_; lean_object* v___x_173_; lean_object* v___x_174_; lean_object* v___x_175_; lean_object* v___x_176_; lean_object* v___x_177_; lean_object* v___x_178_; lean_object* v___x_179_; lean_object* v___x_180_; lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; lean_object* v___x_185_; lean_object* v___x_186_; 
v_quotContext_135_ = lean_ctor_get(v_a_128_, 1);
v_currMacroScope_136_ = lean_ctor_get(v_a_128_, 2);
v_ref_137_ = lean_ctor_get(v_a_128_, 5);
v___x_138_ = 0;
v___x_139_ = l_Lean_SourceInfo_fromRef(v_ref_137_, v___x_138_);
v___x_140_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__4));
v___x_141_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__6));
v___x_142_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__7));
lean_inc_n(v___x_139_, 20);
v___x_143_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_143_, 0, v___x_139_);
lean_ctor_set(v___x_143_, 1, v___x_142_);
v___x_144_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__9));
v___x_145_ = lean_obj_once(&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__11, &lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__11_once, _init_lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__11);
lean_inc_n(v_currMacroScope_136_, 3);
lean_inc_n(v_quotContext_135_, 3);
v___x_146_ = l_Lean_addMacroScope(v_quotContext_135_, v___x_130_, v_currMacroScope_136_);
v___x_147_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__15));
v___x_148_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__18));
v___x_149_ = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(v___x_149_, 0, v___x_139_);
lean_ctor_set(v___x_149_, 1, v___x_145_);
lean_ctor_set(v___x_149_, 2, v___x_146_);
lean_ctor_set(v___x_149_, 3, v___x_148_);
v___x_150_ = l_Lean_Syntax_node1(v___x_139_, v___x_144_, v___x_149_);
v___x_151_ = l_Lean_Syntax_node2(v___x_139_, v___x_141_, v___x_143_, v___x_150_);
v___x_152_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__20));
v___x_153_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__21));
v___x_154_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_154_, 0, v___x_139_);
lean_ctor_set(v___x_154_, 1, v___x_153_);
v___x_155_ = l_Lean_Syntax_node1(v___x_139_, v___x_152_, v___x_154_);
v___x_156_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__22));
v___x_157_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_157_, 0, v___x_139_);
lean_ctor_set(v___x_157_, 1, v___x_156_);
v___x_158_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__24));
v___x_159_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__26));
v___x_160_ = lean_obj_once(&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__27, &lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__27_once, _init_lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__27);
v___x_161_ = l_Lean_addMacroScope(v_quotContext_135_, v___x_147_, v_currMacroScope_136_);
v___x_162_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__29));
v___x_163_ = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(v___x_163_, 0, v___x_139_);
lean_ctor_set(v___x_163_, 1, v___x_160_);
lean_ctor_set(v___x_163_, 2, v___x_161_);
lean_ctor_set(v___x_163_, 3, v___x_162_);
v___x_164_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__31));
v___x_165_ = lean_obj_once(&lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__33, &lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__33_once, _init_lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__33);
v___x_166_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__34));
v___x_167_ = l_Lean_addMacroScope(v_quotContext_135_, v___x_166_, v_currMacroScope_136_);
v___x_168_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__41));
v___x_169_ = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(v___x_169_, 0, v___x_139_);
lean_ctor_set(v___x_169_, 1, v___x_165_);
lean_ctor_set(v___x_169_, 2, v___x_167_);
lean_ctor_set(v___x_169_, 3, v___x_168_);
v___x_170_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__42));
v___x_171_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_171_, 0, v___x_139_);
lean_ctor_set(v___x_171_, 1, v___x_170_);
v___x_172_ = l_Lean_Syntax_node1(v___x_139_, v___x_152_, v___x_171_);
v___x_173_ = l_Lean_Syntax_node1(v___x_139_, v___x_158_, v___x_172_);
v___x_174_ = l_Lean_Syntax_node2(v___x_139_, v___x_159_, v___x_169_, v___x_173_);
v___x_175_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__43));
v___x_176_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_176_, 0, v___x_139_);
lean_ctor_set(v___x_176_, 1, v___x_175_);
lean_inc_ref(v___x_176_);
lean_inc(v___x_151_);
v___x_177_ = l_Lean_Syntax_node3(v___x_139_, v___x_164_, v___x_151_, v___x_174_, v___x_176_);
v___x_178_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__45));
v___x_179_ = ((lean_object*)(lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___closed__46));
v___x_180_ = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(v___x_180_, 0, v___x_139_);
lean_ctor_set(v___x_180_, 1, v___x_179_);
v___x_181_ = l_Lean_Syntax_node1(v___x_139_, v___x_178_, v___x_180_);
lean_inc(v___x_177_);
v___x_182_ = l_Lean_Syntax_node3(v___x_139_, v___x_158_, v___x_177_, v___x_177_, v___x_181_);
v___x_183_ = l_Lean_Syntax_node2(v___x_139_, v___x_159_, v___x_163_, v___x_182_);
v___x_184_ = l_Lean_Syntax_node1(v___x_139_, v___x_158_, v___x_183_);
v___x_185_ = l_Lean_Syntax_node5(v___x_139_, v___x_140_, v___x_151_, v___x_155_, v___x_157_, v___x_184_, v___x_176_);
v___x_186_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_186_, 0, v___x_185_);
lean_ctor_set(v___x_186_, 1, v_a_129_);
return v___x_186_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1___boxed(lean_object* v_x_187_, lean_object* v_a_188_, lean_object* v_a_189_){
_start:
{
lean_object* v_res_190_; 
v_res_190_ = lp_c3formal___private_C3formal_IntPart_0__C3___aux__C3formal__IntPart______macroRules____private__C3formal__IntPart__0__C3__term_U0001d7d9__1(v_x_187_, v_a_188_, v_a_189_);
lean_dec_ref(v_a_188_);
return v_res_190_;
}
}
static lean_object* _init_lp_c3formal_C3_ones___redArg___closed__0(void){
_start:
{
lean_object* v___x_191_; lean_object* v___x_192_; 
v___x_191_ = lean_unsigned_to_nat(1u);
v___x_192_ = lean_nat_to_int(v___x_191_);
return v___x_192_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_ones___redArg(){
_start:
{
lean_object* v___x_194_; 
v___x_194_ = lean_obj_once(&lp_c3formal_C3_ones___redArg___closed__0, &lp_c3formal_C3_ones___redArg___closed__0_once, _init_lp_c3formal_C3_ones___redArg___closed__0);
return v___x_194_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_ones___redArg___boxed(lean_object* v___dummy_195_){
_start:
{
lean_object* v_res_196_; 
v_res_196_ = lp_c3formal_C3_ones___redArg();
return v_res_196_;
}
}
static lean_object* _init_lp_c3formal_C3_ones___closed__0(void){
_start:
{
lean_object* v___x_197_; 
v___x_197_ = lp_c3formal_C3_ones___redArg();
return v___x_197_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_ones(lean_object* v_x_198_){
_start:
{
lean_object* v___x_199_; 
v___x_199_ = lean_obj_once(&lp_c3formal_C3_ones___closed__0, &lp_c3formal_C3_ones___closed__0_once, _init_lp_c3formal_C3_ones___closed__0);
return v___x_199_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_ones___boxed(lean_object* v_x_200_){
_start:
{
lean_object* v_res_201_; 
v_res_201_ = lp_c3formal_C3_ones(v_x_200_);
lean_dec(v_x_200_);
return v_res_201_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Step5(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Saturated(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_NumberTheory(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_LinearAlgebra_Matrix_Block(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_LinearAlgebra_Matrix_PosDef(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Data_Matrix_ColumnRowPartitioned(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Data_Int_Star(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_Module(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_IntPart(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Step5(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Saturated(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_NumberTheory(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_LinearAlgebra_Matrix_Block(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_LinearAlgebra_Matrix_PosDef(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Data_Matrix_ColumnRowPartitioned(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Data_Int_Star(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_Module(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
