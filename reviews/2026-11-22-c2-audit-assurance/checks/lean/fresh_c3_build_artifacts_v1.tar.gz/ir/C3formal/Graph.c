// Lean compiler output
// Module: C3formal.Graph
// Imports: public import Init public meta import Init public import C3formal.Bridge public import Mathlib.Combinatorics.SimpleGraph.StronglyRegular public import Mathlib.Combinatorics.SimpleGraph.AdjMatrix public import Mathlib.Data.Fintype.Quotient
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_ZMod_val(lean_object*, lean_object*);
lean_object* lp_mathlib_Nat_iterate___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_sp(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid___redArg();
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___redArg___lam__0(lean_object* v_00_u03c3_1_, lean_object* v___y_2_){
_start:
{
lean_object* v_toFun_3_; lean_object* v___x_4_; 
v_toFun_3_ = lean_ctor_get(v_00_u03c3_1_, 0);
lean_inc(v_toFun_3_);
lean_dec_ref(v_00_u03c3_1_);
v___x_4_ = lean_apply_1(v_toFun_3_, v___y_2_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___redArg(lean_object* v_00_u03c3_5_, lean_object* v_k_6_, lean_object* v_v_7_){
_start:
{
lean_object* v___f_8_; lean_object* v___x_9_; lean_object* v___x_10_; lean_object* v___x_11_; 
v___f_8_ = lean_alloc_closure((void*)(lp_c3formal_C3_sp___redArg___lam__0), 2, 1);
lean_closure_set(v___f_8_, 0, v_00_u03c3_5_);
v___x_9_ = lean_unsigned_to_nat(3u);
v___x_10_ = lp_mathlib_ZMod_val(v___x_9_, v_k_6_);
v___x_11_ = lp_mathlib_Nat_iterate___redArg(v___f_8_, v___x_10_, v_v_7_);
return v___x_11_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___redArg___boxed(lean_object* v_00_u03c3_12_, lean_object* v_k_13_, lean_object* v_v_14_){
_start:
{
lean_object* v_res_15_; 
v_res_15_ = lp_c3formal_C3_sp___redArg(v_00_u03c3_12_, v_k_13_, v_v_14_);
lean_dec(v_k_13_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_sp(lean_object* v_V_16_, lean_object* v_00_u03c3_17_, lean_object* v_k_18_, lean_object* v_v_19_){
_start:
{
lean_object* v___x_20_; 
v___x_20_ = lp_c3formal_C3_sp___redArg(v_00_u03c3_17_, v_k_18_, v_v_19_);
return v___x_20_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_sp___boxed(lean_object* v_V_21_, lean_object* v_00_u03c3_22_, lean_object* v_k_23_, lean_object* v_v_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = lp_c3formal_C3_sp(v_V_21_, v_00_u03c3_22_, v_k_23_, v_v_24_);
lean_dec(v_k_23_);
return v_res_25_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid___redArg(){
_start:
{
lean_object* v___x_27_; 
v___x_27_ = lean_box(0);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid___redArg___boxed(lean_object* v___dummy_28_){
_start:
{
lean_object* v_res_29_; 
v_res_29_ = lp_c3formal_C3_orbitSetoid___redArg();
return v_res_29_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid(lean_object* v_V_30_, lean_object* v_inst_31_, lean_object* v_inst_32_, lean_object* v_00_u03c3_33_, lean_object* v_h3_34_){
_start:
{
lean_object* v___x_35_; 
v___x_35_ = lean_box(0);
return v___x_35_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_orbitSetoid___boxed(lean_object* v_V_36_, lean_object* v_inst_37_, lean_object* v_inst_38_, lean_object* v_00_u03c3_39_, lean_object* v_h3_40_){
_start:
{
lean_object* v_res_41_; 
v_res_41_ = lp_c3formal_C3_orbitSetoid(v_V_36_, v_inst_37_, v_inst_38_, v_00_u03c3_39_, v_h3_40_);
lean_dec_ref(v_00_u03c3_39_);
lean_dec_ref(v_inst_38_);
lean_dec(v_inst_37_);
return v_res_41_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Bridge(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Combinatorics_SimpleGraph_StronglyRegular(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Combinatorics_SimpleGraph_AdjMatrix(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Data_Fintype_Quotient(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_Graph(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Bridge(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Combinatorics_SimpleGraph_StronglyRegular(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Combinatorics_SimpleGraph_AdjMatrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Data_Fintype_Quotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
