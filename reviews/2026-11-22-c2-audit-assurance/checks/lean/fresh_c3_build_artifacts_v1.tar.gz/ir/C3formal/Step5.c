// Lean compiler output
// Module: C3formal.Step5
// Imports: public import Init public meta import Init public import C3formal.Eis public import Mathlib.LinearAlgebra.Matrix.Rank public import Mathlib.LinearAlgebra.Matrix.NonsingularInverse public import Mathlib.Tactic.LinearCombination public import Mathlib.Algebra.Field.ZMod
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lp_c3formal_Eis_ofInt(lean_object*);
lean_object* lp_mathlib_Equiv_refl___redArg();
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
lean_object* lp_mathlib_ZMod_commRing(lean_object*);
lean_object* lp_mathlib_Ring_toNonAssocRing___redArg(lean_object*);
lean_object* lp_mathlib_Int_castRingHom___redArg(lean_object*);
static lean_once_cell_t lp_c3formal_C3_J___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_J___redArg___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_J___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_J___redArg___lam__0___boxed(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_J___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_J___redArg___closed__0;
static const lean_closure_object lp_c3formal_C3_J___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_J___redArg___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_J___redArg___closed__1 = (const lean_object*)&lp_c3formal_C3_J___redArg___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_J___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_J(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_J___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_NQ___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_NQ___lam__0___boxed(lean_object*);
static const lean_closure_object lp_c3formal_C3_NQ___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_NQ___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_NQ___closed__0 = (const lean_object*)&lp_c3formal_C3_NQ___closed__0_value;
static lean_once_cell_t lp_c3formal_C3_NQ___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NQ___closed__1;
static lean_once_cell_t lp_c3formal_C3_NQ___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NQ___closed__2;
static lean_once_cell_t lp_c3formal_C3_NQ___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NQ___closed__3;
LEAN_EXPORT lean_object* lp_c3formal_C3_NQ(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_NM___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NM___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_NM___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_NM___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Nat_cast___at___00C3_NM_spec__0(lean_object*);
static lean_once_cell_t lp_c3formal_C3_NM___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NM___closed__0;
static const lean_closure_object lp_c3formal_C3_NM___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_NM___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_NM___closed__1 = (const lean_object*)&lp_c3formal_C3_NM___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_NM(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_00_u03c63___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_00_u03c63___closed__0;
static lean_once_cell_t lp_c3formal_C3_00_u03c63___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_00_u03c63___closed__1;
static lean_once_cell_t lp_c3formal_C3_00_u03c63___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_00_u03c63___closed__2;
LEAN_EXPORT lean_object* lp_c3formal_C3_00_u03c63;
static lean_object* _init_lp_c3formal_C3_J___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(1u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_J___redArg___lam__0(lean_object* v_x_3_, lean_object* v_x_4_){
_start:
{
lean_object* v___x_5_; 
v___x_5_ = lean_obj_once(&lp_c3formal_C3_J___redArg___lam__0___closed__0, &lp_c3formal_C3_J___redArg___lam__0___closed__0_once, _init_lp_c3formal_C3_J___redArg___lam__0___closed__0);
return v___x_5_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_J___redArg___lam__0___boxed(lean_object* v_x_6_, lean_object* v_x_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_c3formal_C3_J___redArg___lam__0(v_x_6_, v_x_7_);
lean_dec(v_x_7_);
lean_dec(v_x_6_);
return v_res_8_;
}
}
static lean_object* _init_lp_c3formal_C3_J___redArg___closed__0(void){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lp_mathlib_Equiv_refl___redArg();
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_J___redArg(lean_object* v_a_11_, lean_object* v_a_12_){
_start:
{
lean_object* v___x_13_; lean_object* v_toFun_14_; lean_object* v___f_15_; lean_object* v___x_16_; 
v___x_13_ = lean_obj_once(&lp_c3formal_C3_J___redArg___closed__0, &lp_c3formal_C3_J___redArg___closed__0_once, _init_lp_c3formal_C3_J___redArg___closed__0);
v_toFun_14_ = lean_ctor_get(v___x_13_, 0);
v___f_15_ = ((lean_object*)(lp_c3formal_C3_J___redArg___closed__1));
lean_inc(v_toFun_14_);
v___x_16_ = lean_apply_3(v_toFun_14_, v___f_15_, v_a_11_, v_a_12_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_J(lean_object* v_n_17_, lean_object* v_a_18_, lean_object* v_a_19_){
_start:
{
lean_object* v___x_20_; 
v___x_20_ = lp_c3formal_C3_J___redArg(v_a_18_, v_a_19_);
return v___x_20_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_J___boxed(lean_object* v_n_21_, lean_object* v_a_22_, lean_object* v_a_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_c3formal_C3_J(v_n_21_, v_a_22_, v_a_23_);
lean_dec(v_n_21_);
return v_res_24_;
}
}
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0(void){
_start:
{
lean_object* v___x_25_; lean_object* v___x_26_; 
v___x_25_ = lean_unsigned_to_nat(0u);
v___x_26_ = lean_nat_to_int(v___x_25_);
return v___x_26_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0(lean_object* v_d_27_, lean_object* v_i_28_, lean_object* v_j_29_){
_start:
{
uint8_t v___x_30_; 
v___x_30_ = lean_nat_dec_eq(v_i_28_, v_j_29_);
if (v___x_30_ == 0)
{
lean_object* v___x_31_; 
lean_dec(v_i_28_);
lean_dec_ref(v_d_27_);
v___x_31_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0, &lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0);
return v___x_31_;
}
else
{
lean_object* v___x_32_; 
v___x_32_ = lean_apply_1(v_d_27_, v_i_28_);
return v___x_32_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___boxed(lean_object* v_d_33_, lean_object* v_i_34_, lean_object* v_j_35_){
_start:
{
lean_object* v_res_36_; 
v_res_36_ = lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0(v_d_33_, v_i_34_, v_j_35_);
lean_dec(v_j_35_);
return v_res_36_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0(lean_object* v_d_37_, lean_object* v_a_38_, lean_object* v_a_39_){
_start:
{
lean_object* v___x_40_; lean_object* v_toFun_41_; lean_object* v___f_42_; lean_object* v___x_43_; 
v___x_40_ = lean_obj_once(&lp_c3formal_C3_J___redArg___closed__0, &lp_c3formal_C3_J___redArg___closed__0_once, _init_lp_c3formal_C3_J___redArg___closed__0);
v_toFun_41_ = lean_ctor_get(v___x_40_, 0);
v___f_42_ = lean_alloc_closure((void*)(lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___boxed), 3, 1);
lean_closure_set(v___f_42_, 0, v_d_37_);
lean_inc(v_toFun_41_);
v___x_43_ = lean_apply_3(v_toFun_41_, v___f_42_, v_a_38_, v_a_39_);
return v___x_43_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NQ___lam__0(lean_object* v_x_44_){
_start:
{
lean_object* v___x_45_; 
v___x_45_ = lean_obj_once(&lp_c3formal_C3_J___redArg___lam__0___closed__0, &lp_c3formal_C3_J___redArg___lam__0___closed__0_once, _init_lp_c3formal_C3_J___redArg___lam__0___closed__0);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NQ___lam__0___boxed(lean_object* v_x_46_){
_start:
{
lean_object* v_res_47_; 
v_res_47_ = lp_c3formal_C3_NQ___lam__0(v_x_46_);
lean_dec(v_x_46_);
return v_res_47_;
}
}
static lean_object* _init_lp_c3formal_C3_NQ___closed__1(void){
_start:
{
lean_object* v___x_49_; lean_object* v___x_50_; 
v___x_49_ = lean_unsigned_to_nat(11u);
v___x_50_ = lean_nat_to_int(v___x_49_);
return v___x_50_;
}
}
static lean_object* _init_lp_c3formal_C3_NQ___closed__2(void){
_start:
{
lean_object* v___x_51_; lean_object* v___x_52_; 
v___x_51_ = lean_unsigned_to_nat(4u);
v___x_52_ = lean_nat_to_int(v___x_51_);
return v___x_52_;
}
}
static lean_object* _init_lp_c3formal_C3_NQ___closed__3(void){
_start:
{
lean_object* v___x_53_; lean_object* v___x_54_; 
v___x_53_ = lean_unsigned_to_nat(6u);
v___x_54_ = lean_nat_to_int(v___x_53_);
return v___x_54_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NQ(lean_object* v_Q_55_, lean_object* v_a_56_, lean_object* v_a_57_){
_start:
{
lean_object* v___f_58_; lean_object* v___x_59_; lean_object* v___x_60_; lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; lean_object* v___x_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; 
v___f_58_ = ((lean_object*)(lp_c3formal_C3_NQ___closed__0));
v___x_59_ = lean_obj_once(&lp_c3formal_C3_NQ___closed__1, &lp_c3formal_C3_NQ___closed__1_once, _init_lp_c3formal_C3_NQ___closed__1);
v___x_60_ = lean_obj_once(&lp_c3formal_C3_NQ___closed__2, &lp_c3formal_C3_NQ___closed__2_once, _init_lp_c3formal_C3_NQ___closed__2);
v___x_61_ = lean_obj_once(&lp_c3formal_C3_NQ___closed__3, &lp_c3formal_C3_NQ___closed__3_once, _init_lp_c3formal_C3_NQ___closed__3);
lean_inc_n(v_a_57_, 2);
lean_inc_n(v_a_56_, 2);
v___x_62_ = lean_apply_2(v_Q_55_, v_a_56_, v_a_57_);
v___x_63_ = lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0(v___f_58_, v_a_56_, v_a_57_);
v___x_64_ = lean_int_mul(v___x_60_, v___x_63_);
lean_dec(v___x_63_);
v___x_65_ = lean_int_add(v___x_62_, v___x_64_);
lean_dec(v___x_64_);
lean_dec(v___x_62_);
v___x_66_ = lean_int_mul(v___x_59_, v___x_65_);
lean_dec(v___x_65_);
v___x_67_ = lp_c3formal_C3_J___redArg(v_a_56_, v_a_57_);
v___x_68_ = lean_int_mul(v___x_61_, v___x_67_);
lean_dec(v___x_67_);
v___x_69_ = lean_int_sub(v___x_66_, v___x_68_);
lean_dec(v___x_68_);
lean_dec(v___x_66_);
return v___x_69_;
}
}
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___closed__0(void){
_start:
{
lean_object* v___x_70_; lean_object* v___x_71_; 
v___x_70_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0, &lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_NQ_spec__0___lam__0___closed__0);
v___x_71_ = lp_c3formal_Eis_ofInt(v___x_70_);
return v___x_71_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0(lean_object* v_d_72_, lean_object* v_i_73_, lean_object* v_j_74_){
_start:
{
uint8_t v___x_75_; 
v___x_75_ = lean_nat_dec_eq(v_i_73_, v_j_74_);
if (v___x_75_ == 0)
{
lean_object* v___x_76_; 
lean_dec(v_i_73_);
lean_dec_ref(v_d_72_);
v___x_76_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___closed__0, &lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___closed__0_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___closed__0);
return v___x_76_;
}
else
{
lean_object* v___x_77_; 
v___x_77_ = lean_apply_1(v_d_72_, v_i_73_);
return v___x_77_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___boxed(lean_object* v_d_78_, lean_object* v_i_79_, lean_object* v_j_80_){
_start:
{
lean_object* v_res_81_; 
v_res_81_ = lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0(v_d_78_, v_i_79_, v_j_80_);
lean_dec(v_j_80_);
return v_res_81_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1(lean_object* v_d_82_, lean_object* v_a_83_, lean_object* v_a_84_){
_start:
{
lean_object* v___x_85_; lean_object* v_toFun_86_; lean_object* v___f_87_; lean_object* v___x_88_; 
v___x_85_ = lean_obj_once(&lp_c3formal_C3_J___redArg___closed__0, &lp_c3formal_C3_J___redArg___closed__0_once, _init_lp_c3formal_C3_J___redArg___closed__0);
v_toFun_86_ = lean_ctor_get(v___x_85_, 0);
v___f_87_ = lean_alloc_closure((void*)(lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1___lam__0___boxed), 3, 1);
lean_closure_set(v___f_87_, 0, v_d_82_);
lean_inc(v_toFun_86_);
v___x_88_ = lean_apply_3(v_toFun_86_, v___f_87_, v_a_83_, v_a_84_);
return v___x_88_;
}
}
static lean_object* _init_lp_c3formal_C3_NM___lam__0___closed__0(void){
_start:
{
lean_object* v___x_89_; lean_object* v___x_90_; 
v___x_89_ = lean_obj_once(&lp_c3formal_C3_J___redArg___lam__0___closed__0, &lp_c3formal_C3_J___redArg___lam__0___closed__0_once, _init_lp_c3formal_C3_J___redArg___lam__0___closed__0);
v___x_90_ = lp_c3formal_Eis_ofInt(v___x_89_);
return v___x_90_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NM___lam__0(lean_object* v_x_91_){
_start:
{
lean_object* v___x_92_; 
v___x_92_ = lean_obj_once(&lp_c3formal_C3_NM___lam__0___closed__0, &lp_c3formal_C3_NM___lam__0___closed__0_once, _init_lp_c3formal_C3_NM___lam__0___closed__0);
return v___x_92_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NM___lam__0___boxed(lean_object* v_x_93_){
_start:
{
lean_object* v_res_94_; 
v_res_94_ = lp_c3formal_C3_NM___lam__0(v_x_93_);
lean_dec(v_x_93_);
return v_res_94_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Nat_cast___at___00C3_NM_spec__0(lean_object* v_a_95_){
_start:
{
lean_object* v___x_96_; lean_object* v___x_97_; 
v___x_96_ = lean_nat_to_int(v_a_95_);
v___x_97_ = lp_c3formal_Eis_ofInt(v___x_96_);
return v___x_97_;
}
}
static lean_object* _init_lp_c3formal_C3_NM___closed__0(void){
_start:
{
lean_object* v___x_98_; lean_object* v___x_99_; 
v___x_98_ = lean_unsigned_to_nat(4u);
v___x_99_ = lp_c3formal_Nat_cast___at___00C3_NM_spec__0(v___x_98_);
return v___x_99_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NM(lean_object* v_M_101_, lean_object* v_a_102_, lean_object* v_a_103_){
_start:
{
lean_object* v___x_104_; lean_object* v_re_105_; lean_object* v_im_106_; lean_object* v___x_107_; lean_object* v___f_108_; lean_object* v___x_109_; lean_object* v_re_110_; lean_object* v_im_111_; lean_object* v_re_112_; lean_object* v_im_113_; lean_object* v___x_115_; uint8_t v_isShared_116_; uint8_t v_isSharedCheck_129_; 
v___x_104_ = lean_obj_once(&lp_c3formal_C3_NM___closed__0, &lp_c3formal_C3_NM___closed__0_once, _init_lp_c3formal_C3_NM___closed__0);
v_re_105_ = lean_ctor_get(v___x_104_, 0);
v_im_106_ = lean_ctor_get(v___x_104_, 1);
lean_inc(v_a_103_);
lean_inc(v_a_102_);
v___x_107_ = lean_apply_2(v_M_101_, v_a_102_, v_a_103_);
v___f_108_ = ((lean_object*)(lp_c3formal_C3_NM___closed__1));
v___x_109_ = lp_c3formal_Matrix_diagonal___at___00C3_NM_spec__1(v___f_108_, v_a_102_, v_a_103_);
v_re_110_ = lean_ctor_get(v___x_109_, 0);
lean_inc(v_re_110_);
v_im_111_ = lean_ctor_get(v___x_109_, 1);
lean_inc(v_im_111_);
lean_dec_ref(v___x_109_);
v_re_112_ = lean_ctor_get(v___x_107_, 0);
v_im_113_ = lean_ctor_get(v___x_107_, 1);
v_isSharedCheck_129_ = !lean_is_exclusive(v___x_107_);
if (v_isSharedCheck_129_ == 0)
{
v___x_115_ = v___x_107_;
v_isShared_116_ = v_isSharedCheck_129_;
goto v_resetjp_114_;
}
else
{
lean_inc(v_im_113_);
lean_inc(v_re_112_);
lean_dec(v___x_107_);
v___x_115_ = lean_box(0);
v_isShared_116_ = v_isSharedCheck_129_;
goto v_resetjp_114_;
}
v_resetjp_114_:
{
lean_object* v___x_117_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_120_; lean_object* v___x_121_; lean_object* v___x_122_; lean_object* v___x_123_; lean_object* v___x_124_; lean_object* v___x_125_; lean_object* v___x_127_; 
v___x_117_ = lean_int_mul(v_re_105_, v_re_110_);
v___x_118_ = lean_int_mul(v_im_106_, v_im_111_);
v___x_119_ = lean_int_sub(v___x_117_, v___x_118_);
lean_dec(v___x_117_);
v___x_120_ = lean_int_mul(v_re_105_, v_im_111_);
lean_dec(v_im_111_);
v___x_121_ = lean_int_mul(v_im_106_, v_re_110_);
lean_dec(v_re_110_);
v___x_122_ = lean_int_add(v___x_120_, v___x_121_);
lean_dec(v___x_121_);
lean_dec(v___x_120_);
v___x_123_ = lean_int_sub(v___x_122_, v___x_118_);
lean_dec(v___x_118_);
lean_dec(v___x_122_);
v___x_124_ = lean_int_add(v_re_112_, v___x_119_);
lean_dec(v___x_119_);
lean_dec(v_re_112_);
v___x_125_ = lean_int_add(v_im_113_, v___x_123_);
lean_dec(v___x_123_);
lean_dec(v_im_113_);
if (v_isShared_116_ == 0)
{
lean_ctor_set(v___x_115_, 1, v___x_125_);
lean_ctor_set(v___x_115_, 0, v___x_124_);
v___x_127_ = v___x_115_;
goto v_reusejp_126_;
}
else
{
lean_object* v_reuseFailAlloc_128_; 
v_reuseFailAlloc_128_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_128_, 0, v___x_124_);
lean_ctor_set(v_reuseFailAlloc_128_, 1, v___x_125_);
v___x_127_ = v_reuseFailAlloc_128_;
goto v_reusejp_126_;
}
v_reusejp_126_:
{
return v___x_127_;
}
}
}
}
static lean_object* _init_lp_c3formal_C3_00_u03c63___closed__0(void){
_start:
{
lean_object* v___x_130_; lean_object* v___x_131_; 
v___x_130_ = lean_unsigned_to_nat(3u);
v___x_131_ = lp_mathlib_ZMod_commRing(v___x_130_);
return v___x_131_;
}
}
static lean_object* _init_lp_c3formal_C3_00_u03c63___closed__1(void){
_start:
{
lean_object* v___x_132_; lean_object* v___x_133_; 
v___x_132_ = lean_obj_once(&lp_c3formal_C3_00_u03c63___closed__0, &lp_c3formal_C3_00_u03c63___closed__0_once, _init_lp_c3formal_C3_00_u03c63___closed__0);
v___x_133_ = lp_mathlib_Ring_toNonAssocRing___redArg(v___x_132_);
return v___x_133_;
}
}
static lean_object* _init_lp_c3formal_C3_00_u03c63___closed__2(void){
_start:
{
lean_object* v___x_134_; lean_object* v___x_135_; 
v___x_134_ = lean_obj_once(&lp_c3formal_C3_00_u03c63___closed__1, &lp_c3formal_C3_00_u03c63___closed__1_once, _init_lp_c3formal_C3_00_u03c63___closed__1);
v___x_135_ = lp_mathlib_Int_castRingHom___redArg(v___x_134_);
return v___x_135_;
}
}
static lean_object* _init_lp_c3formal_C3_00_u03c63(void){
_start:
{
lean_object* v___x_136_; 
v___x_136_ = lean_obj_once(&lp_c3formal_C3_00_u03c63___closed__2, &lp_c3formal_C3_00_u03c63___closed__2_once, _init_lp_c3formal_C3_00_u03c63___closed__2);
return v___x_136_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Eis(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_LinearAlgebra_Matrix_Rank(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_LinearAlgebra_Matrix_NonsingularInverse(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_LinearCombination(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Algebra_Field_ZMod(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_Step5(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Eis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_LinearAlgebra_Matrix_Rank(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_LinearAlgebra_Matrix_NonsingularInverse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_LinearCombination(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Algebra_Field_ZMod(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_c3formal_C3_00_u03c63 = _init_lp_c3formal_C3_00_u03c63();
lean_mark_persistent(lp_c3formal_C3_00_u03c63);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
