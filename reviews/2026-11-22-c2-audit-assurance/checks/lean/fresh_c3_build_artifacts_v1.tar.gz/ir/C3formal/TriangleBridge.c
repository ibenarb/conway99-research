// Lean compiler output
// Module: C3formal.TriangleBridge
// Imports: public import Init public meta import Init public import C3formal.TriangleStep4 public import C3formal.Bridge
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_c3formal_Eis_ofInt(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lp_c3formal_C3_wpow(lean_object*);
lean_object* l_Sum_elim___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_ZMod_decidableEq___boxed(lean_object*, lean_object*, lean_object*);
uint8_t l_instDecidableEqProd___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl___redArg();
lean_object* lp_mathlib_ZMod_instField___redArg(lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
uint8_t l_instDecidableEqSum_decEq___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Sum_map___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__1___boxed(lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_orb___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_orb___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_orb___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_orb___closed__0_value;
static const lean_closure_object lp_c3formal_C3_Tri_orb___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_orb___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_orb___closed__1 = (const lean_object*)&lp_c3formal_C3_Tri_orb___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb(lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_rep___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_rep___lam__0___closed__0;
static lean_once_cell_t lp_c3formal_C3_Tri_rep___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_rep___lam__0___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_rep___lam__0(lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_rep___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_rep___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_rep___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_rep___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_rep(lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_Em___lam__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instDecidableEqFin___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(32) << 1) | 1))} };
static const lean_object* lp_c3formal_C3_Tri_Em___lam__0___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_Em___lam__0___closed__0_value;
static const lean_closure_object lp_c3formal_C3_Tri_Em___lam__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instDecidableEqFin___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))} };
static const lean_object* lp_c3formal_C3_Tri_Em___lam__0___closed__1 = (const lean_object*)&lp_c3formal_C3_Tri_Em___lam__0___closed__1_value;
static lean_once_cell_t lp_c3formal_C3_Tri_Em___lam__0___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Em___lam__0___closed__2;
static lean_once_cell_t lp_c3formal_C3_Tri_Em___lam__0___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Em___lam__0___closed__3;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Em___lam__0(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_Em___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Em___closed__0;
static const lean_closure_object lp_c3formal_C3_Tri_Em___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Em___lam__0, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_Em___closed__1 = (const lean_object*)&lp_c3formal_C3_Tri_Em___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Em(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_Rm___lam__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_ZMod_decidableEq___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))} };
static const lean_object* lp_c3formal_C3_Tri_Rm___lam__0___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_Rm___lam__0___closed__0_value;
LEAN_EXPORT uint8_t lp_c3formal_C3_Tri_Rm___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rm___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rm___lam__1(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_Rm___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Rm___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_Rm___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_Rm___closed__0_value;
static const lean_closure_object lp_c3formal_C3_Tri_Rm___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Rm___lam__1, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_c3formal_C3_Tri_Rm___closed__0_value)} };
static const lean_object* lp_c3formal_C3_Tri_Rm___closed__1 = (const lean_object*)&lp_c3formal_C3_Tri_Rm___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rm(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_Ew___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Ew___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__2(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_Ew___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Ew___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_Ew___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_Ew___closed__0_value;
static const lean_closure_object lp_c3formal_C3_Tri_Ew___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Ew___lam__2, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_c3formal_C3_Tri_Ew___closed__0_value)} };
static const lean_object* lp_c3formal_C3_Tri_Ew___closed__1 = (const lean_object*)&lp_c3formal_C3_Tri_Ew___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_Rw___lam__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Rw___lam__1___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rw___lam__1(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_Rw___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Rw___lam__1, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_c3formal_C3_Tri_Rm___closed__0_value)} };
static const lean_object* lp_c3formal_C3_Tri_Rw___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_Rw___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rw(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__0(lean_object* v_self_1_){
_start:
{
lean_object* v_fst_2_; 
v_fst_2_ = lean_ctor_get(v_self_1_, 0);
lean_inc(v_fst_2_);
return v_fst_2_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__0___boxed(lean_object* v_self_3_){
_start:
{
lean_object* v_res_4_; 
v_res_4_ = lp_c3formal_C3_Tri_orb___lam__0(v_self_3_);
lean_dec_ref(v_self_3_);
return v_res_4_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__1(lean_object* v___y_5_){
_start:
{
lean_inc(v___y_5_);
return v___y_5_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb___lam__1___boxed(lean_object* v___y_6_){
_start:
{
lean_object* v_res_7_; 
v_res_7_ = lp_c3formal_C3_Tri_orb___lam__1(v___y_6_);
lean_dec(v___y_6_);
return v_res_7_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_orb(lean_object* v_a_10_){
_start:
{
lean_object* v___f_11_; lean_object* v___f_12_; lean_object* v___x_13_; 
v___f_11_ = ((lean_object*)(lp_c3formal_C3_Tri_orb___closed__0));
v___f_12_ = ((lean_object*)(lp_c3formal_C3_Tri_orb___closed__1));
v___x_13_ = l_Sum_map___redArg(v___f_11_, v___f_12_, v_a_10_);
return v___x_13_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_rep___lam__0___closed__0(void){
_start:
{
lean_object* v___x_14_; lean_object* v___x_15_; 
v___x_14_ = lean_unsigned_to_nat(3u);
v___x_15_ = lp_mathlib_ZMod_instField___redArg(v___x_14_);
return v___x_15_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_rep___lam__0___closed__1(void){
_start:
{
lean_object* v___x_16_; lean_object* v___x_17_; 
v___x_16_ = lean_obj_once(&lp_c3formal_C3_Tri_rep___lam__0___closed__0, &lp_c3formal_C3_Tri_rep___lam__0___closed__0_once, _init_lp_c3formal_C3_Tri_rep___lam__0___closed__0);
v___x_17_ = lp_mathlib_Field_toSemifield___redArg(v___x_16_);
return v___x_17_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_rep___lam__0(lean_object* v_U_18_){
_start:
{
lean_object* v___x_19_; lean_object* v_toCommSemiring_20_; lean_object* v___x_21_; lean_object* v_toZero_22_; lean_object* v___x_24_; uint8_t v_isShared_25_; uint8_t v_isSharedCheck_29_; 
v___x_19_ = lean_obj_once(&lp_c3formal_C3_Tri_rep___lam__0___closed__1, &lp_c3formal_C3_Tri_rep___lam__0___closed__1_once, _init_lp_c3formal_C3_Tri_rep___lam__0___closed__1);
v_toCommSemiring_20_ = lean_ctor_get(v___x_19_, 0);
lean_inc_ref(v_toCommSemiring_20_);
v___x_21_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toCommSemiring_20_);
v_toZero_22_ = lean_ctor_get(v___x_21_, 1);
v_isSharedCheck_29_ = !lean_is_exclusive(v___x_21_);
if (v_isSharedCheck_29_ == 0)
{
lean_object* v_unused_30_; 
v_unused_30_ = lean_ctor_get(v___x_21_, 0);
lean_dec(v_unused_30_);
v___x_24_ = v___x_21_;
v_isShared_25_ = v_isSharedCheck_29_;
goto v_resetjp_23_;
}
else
{
lean_inc(v_toZero_22_);
lean_dec(v___x_21_);
v___x_24_ = lean_box(0);
v_isShared_25_ = v_isSharedCheck_29_;
goto v_resetjp_23_;
}
v_resetjp_23_:
{
lean_object* v___x_27_; 
if (v_isShared_25_ == 0)
{
lean_ctor_set(v___x_24_, 0, v_U_18_);
v___x_27_ = v___x_24_;
goto v_reusejp_26_;
}
else
{
lean_object* v_reuseFailAlloc_28_; 
v_reuseFailAlloc_28_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_28_, 0, v_U_18_);
lean_ctor_set(v_reuseFailAlloc_28_, 1, v_toZero_22_);
v___x_27_ = v_reuseFailAlloc_28_;
goto v_reusejp_26_;
}
v_reusejp_26_:
{
return v___x_27_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_rep(lean_object* v_a_32_){
_start:
{
lean_object* v___f_33_; lean_object* v___f_34_; lean_object* v___x_35_; 
v___f_33_ = ((lean_object*)(lp_c3formal_C3_Tri_rep___closed__0));
v___f_34_ = ((lean_object*)(lp_c3formal_C3_Tri_orb___closed__1));
v___x_35_ = l_Sum_map___redArg(v___f_33_, v___f_34_, v_a_32_);
return v___x_35_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Em___lam__0___closed__2(void){
_start:
{
lean_object* v___x_40_; lean_object* v___x_41_; 
v___x_40_ = lean_unsigned_to_nat(0u);
v___x_41_ = lean_nat_to_int(v___x_40_);
return v___x_41_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Em___lam__0___closed__3(void){
_start:
{
lean_object* v___x_42_; lean_object* v___x_43_; 
v___x_42_ = lean_unsigned_to_nat(1u);
v___x_43_ = lean_nat_to_int(v___x_42_);
return v___x_43_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Em___lam__0(lean_object* v_x_44_, lean_object* v_o_45_){
_start:
{
lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_48_; uint8_t v___x_49_; 
v___x_46_ = ((lean_object*)(lp_c3formal_C3_Tri_Em___lam__0___closed__0));
v___x_47_ = ((lean_object*)(lp_c3formal_C3_Tri_Em___lam__0___closed__1));
v___x_48_ = lp_c3formal_C3_Tri_orb(v_x_44_);
v___x_49_ = l_instDecidableEqSum_decEq___redArg(v___x_46_, v___x_47_, v___x_48_, v_o_45_);
if (v___x_49_ == 0)
{
lean_object* v___x_50_; 
v___x_50_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___lam__0___closed__2, &lp_c3formal_C3_Tri_Em___lam__0___closed__2_once, _init_lp_c3formal_C3_Tri_Em___lam__0___closed__2);
return v___x_50_;
}
else
{
lean_object* v___x_51_; 
v___x_51_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___lam__0___closed__3, &lp_c3formal_C3_Tri_Em___lam__0___closed__3_once, _init_lp_c3formal_C3_Tri_Em___lam__0___closed__3);
return v___x_51_;
}
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Em___closed__0(void){
_start:
{
lean_object* v___x_52_; 
v___x_52_ = lp_mathlib_Equiv_refl___redArg();
return v___x_52_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Em(lean_object* v_a_54_, lean_object* v_a_55_){
_start:
{
lean_object* v___x_56_; lean_object* v_toFun_57_; lean_object* v___f_58_; lean_object* v___x_59_; 
v___x_56_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___closed__0, &lp_c3formal_C3_Tri_Em___closed__0_once, _init_lp_c3formal_C3_Tri_Em___closed__0);
v_toFun_57_ = lean_ctor_get(v___x_56_, 0);
v___f_58_ = ((lean_object*)(lp_c3formal_C3_Tri_Em___closed__1));
lean_inc(v_toFun_57_);
v___x_59_ = lean_apply_3(v_toFun_57_, v___f_58_, v_a_54_, v_a_55_);
return v___x_59_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_C3_Tri_Rm___lam__0(lean_object* v_a_62_, lean_object* v_b_63_){
_start:
{
lean_object* v___x_64_; lean_object* v___x_65_; uint8_t v___x_66_; 
v___x_64_ = ((lean_object*)(lp_c3formal_C3_Tri_Em___lam__0___closed__0));
v___x_65_ = ((lean_object*)(lp_c3formal_C3_Tri_Rm___lam__0___closed__0));
v___x_66_ = l_instDecidableEqProd___redArg(v___x_64_, v___x_65_, v_a_62_, v_b_63_);
return v___x_66_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rm___lam__0___boxed(lean_object* v_a_67_, lean_object* v_b_68_){
_start:
{
uint8_t v_res_69_; lean_object* v_r_70_; 
v_res_69_ = lp_c3formal_C3_Tri_Rm___lam__0(v_a_67_, v_b_68_);
v_r_70_ = lean_box(v_res_69_);
return v_r_70_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rm___lam__1(lean_object* v___f_71_, lean_object* v_o_72_, lean_object* v_x_73_){
_start:
{
lean_object* v___x_74_; lean_object* v___x_75_; uint8_t v___x_76_; 
v___x_74_ = ((lean_object*)(lp_c3formal_C3_Tri_Em___lam__0___closed__1));
v___x_75_ = lp_c3formal_C3_Tri_rep(v_o_72_);
v___x_76_ = l_instDecidableEqSum_decEq___redArg(v___f_71_, v___x_74_, v_x_73_, v___x_75_);
if (v___x_76_ == 0)
{
lean_object* v___x_77_; 
v___x_77_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___lam__0___closed__2, &lp_c3formal_C3_Tri_Em___lam__0___closed__2_once, _init_lp_c3formal_C3_Tri_Em___lam__0___closed__2);
return v___x_77_;
}
else
{
lean_object* v___x_78_; 
v___x_78_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___lam__0___closed__3, &lp_c3formal_C3_Tri_Em___lam__0___closed__3_once, _init_lp_c3formal_C3_Tri_Em___lam__0___closed__3);
return v___x_78_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rm(lean_object* v_a_82_, lean_object* v_a_83_){
_start:
{
lean_object* v___x_84_; lean_object* v_toFun_85_; lean_object* v___f_86_; lean_object* v___x_87_; 
v___x_84_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___closed__0, &lp_c3formal_C3_Tri_Em___closed__0_once, _init_lp_c3formal_C3_Tri_Em___closed__0);
v_toFun_85_ = lean_ctor_get(v___x_84_, 0);
v___f_86_ = ((lean_object*)(lp_c3formal_C3_Tri_Rm___closed__1));
lean_inc(v_toFun_85_);
v___x_87_ = lean_apply_3(v_toFun_85_, v___f_86_, v_a_82_, v_a_83_);
return v___x_87_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Ew___lam__0___closed__0(void){
_start:
{
lean_object* v___x_88_; lean_object* v___x_89_; 
v___x_88_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___lam__0___closed__2, &lp_c3formal_C3_Tri_Em___lam__0___closed__2_once, _init_lp_c3formal_C3_Tri_Em___lam__0___closed__2);
v___x_89_ = lp_c3formal_Eis_ofInt(v___x_88_);
return v___x_89_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__0(lean_object* v_x_90_){
_start:
{
lean_object* v___x_91_; 
v___x_91_ = lean_obj_once(&lp_c3formal_C3_Tri_Ew___lam__0___closed__0, &lp_c3formal_C3_Tri_Ew___lam__0___closed__0_once, _init_lp_c3formal_C3_Tri_Ew___lam__0___closed__0);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__0___boxed(lean_object* v_x_92_){
_start:
{
lean_object* v_res_93_; 
v_res_93_ = lp_c3formal_C3_Tri_Ew___lam__0(v_x_92_);
lean_dec(v_x_92_);
return v_res_93_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__1(lean_object* v_V_94_, lean_object* v_p_95_){
_start:
{
lean_object* v_fst_96_; lean_object* v_snd_97_; uint8_t v___x_98_; 
v_fst_96_ = lean_ctor_get(v_p_95_, 0);
v_snd_97_ = lean_ctor_get(v_p_95_, 1);
v___x_98_ = lean_nat_dec_eq(v_fst_96_, v_V_94_);
if (v___x_98_ == 0)
{
lean_object* v___x_99_; 
v___x_99_ = lean_obj_once(&lp_c3formal_C3_Tri_Ew___lam__0___closed__0, &lp_c3formal_C3_Tri_Ew___lam__0___closed__0_once, _init_lp_c3formal_C3_Tri_Ew___lam__0___closed__0);
return v___x_99_;
}
else
{
lean_object* v___x_100_; 
v___x_100_ = lp_c3formal_C3_wpow(v_snd_97_);
return v___x_100_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__1___boxed(lean_object* v_V_101_, lean_object* v_p_102_){
_start:
{
lean_object* v_res_103_; 
v_res_103_ = lp_c3formal_C3_Tri_Ew___lam__1(v_V_101_, v_p_102_);
lean_dec_ref(v_p_102_);
lean_dec(v_V_101_);
return v_res_103_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew___lam__2(lean_object* v___f_104_, lean_object* v_x_105_, lean_object* v_V_106_){
_start:
{
lean_object* v___f_107_; lean_object* v___x_108_; 
v___f_107_ = lean_alloc_closure((void*)(lp_c3formal_C3_Tri_Ew___lam__1___boxed), 2, 1);
lean_closure_set(v___f_107_, 0, v_V_106_);
v___x_108_ = l_Sum_elim___redArg(v___f_107_, v___f_104_, v_x_105_);
return v___x_108_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Ew(lean_object* v_a_112_, lean_object* v_a_113_){
_start:
{
lean_object* v___x_114_; lean_object* v_toFun_115_; lean_object* v___f_116_; lean_object* v___x_117_; 
v___x_114_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___closed__0, &lp_c3formal_C3_Tri_Em___closed__0_once, _init_lp_c3formal_C3_Tri_Em___closed__0);
v_toFun_115_ = lean_ctor_get(v___x_114_, 0);
v___f_116_ = ((lean_object*)(lp_c3formal_C3_Tri_Ew___closed__1));
lean_inc(v_toFun_115_);
v___x_117_ = lean_apply_3(v_toFun_115_, v___f_116_, v_a_112_, v_a_113_);
return v___x_117_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Rw___lam__1___closed__0(void){
_start:
{
lean_object* v___x_118_; lean_object* v___x_119_; 
v___x_118_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___lam__0___closed__3, &lp_c3formal_C3_Tri_Em___lam__0___closed__3_once, _init_lp_c3formal_C3_Tri_Em___lam__0___closed__3);
v___x_119_ = lp_c3formal_Eis_ofInt(v___x_118_);
return v___x_119_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rw___lam__1(lean_object* v___f_120_, lean_object* v_U_121_, lean_object* v_x_122_){
_start:
{
lean_object* v___x_123_; lean_object* v_toCommSemiring_124_; lean_object* v___x_125_; lean_object* v_toZero_126_; lean_object* v___x_128_; uint8_t v_isShared_129_; uint8_t v_isSharedCheck_138_; 
v___x_123_ = lean_obj_once(&lp_c3formal_C3_Tri_rep___lam__0___closed__1, &lp_c3formal_C3_Tri_rep___lam__0___closed__1_once, _init_lp_c3formal_C3_Tri_rep___lam__0___closed__1);
v_toCommSemiring_124_ = lean_ctor_get(v___x_123_, 0);
lean_inc_ref(v_toCommSemiring_124_);
v___x_125_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toCommSemiring_124_);
v_toZero_126_ = lean_ctor_get(v___x_125_, 1);
v_isSharedCheck_138_ = !lean_is_exclusive(v___x_125_);
if (v_isSharedCheck_138_ == 0)
{
lean_object* v_unused_139_; 
v_unused_139_ = lean_ctor_get(v___x_125_, 0);
lean_dec(v_unused_139_);
v___x_128_ = v___x_125_;
v_isShared_129_ = v_isSharedCheck_138_;
goto v_resetjp_127_;
}
else
{
lean_inc(v_toZero_126_);
lean_dec(v___x_125_);
v___x_128_ = lean_box(0);
v_isShared_129_ = v_isSharedCheck_138_;
goto v_resetjp_127_;
}
v_resetjp_127_:
{
lean_object* v___x_130_; lean_object* v___x_132_; 
v___x_130_ = ((lean_object*)(lp_c3formal_C3_Tri_Em___lam__0___closed__1));
if (v_isShared_129_ == 0)
{
lean_ctor_set(v___x_128_, 0, v_U_121_);
v___x_132_ = v___x_128_;
goto v_reusejp_131_;
}
else
{
lean_object* v_reuseFailAlloc_137_; 
v_reuseFailAlloc_137_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_137_, 0, v_U_121_);
lean_ctor_set(v_reuseFailAlloc_137_, 1, v_toZero_126_);
v___x_132_ = v_reuseFailAlloc_137_;
goto v_reusejp_131_;
}
v_reusejp_131_:
{
lean_object* v___x_133_; uint8_t v___x_134_; 
v___x_133_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_133_, 0, v___x_132_);
v___x_134_ = l_instDecidableEqSum_decEq___redArg(v___f_120_, v___x_130_, v_x_122_, v___x_133_);
if (v___x_134_ == 0)
{
lean_object* v___x_135_; 
v___x_135_ = lean_obj_once(&lp_c3formal_C3_Tri_Ew___lam__0___closed__0, &lp_c3formal_C3_Tri_Ew___lam__0___closed__0_once, _init_lp_c3formal_C3_Tri_Ew___lam__0___closed__0);
return v___x_135_;
}
else
{
lean_object* v___x_136_; 
v___x_136_ = lean_obj_once(&lp_c3formal_C3_Tri_Rw___lam__1___closed__0, &lp_c3formal_C3_Tri_Rw___lam__1___closed__0_once, _init_lp_c3formal_C3_Tri_Rw___lam__1___closed__0);
return v___x_136_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Rw(lean_object* v_a_142_, lean_object* v_a_143_){
_start:
{
lean_object* v___x_144_; lean_object* v_toFun_145_; lean_object* v___f_146_; lean_object* v___x_147_; 
v___x_144_ = lean_obj_once(&lp_c3formal_C3_Tri_Em___closed__0, &lp_c3formal_C3_Tri_Em___closed__0_once, _init_lp_c3formal_C3_Tri_Em___closed__0);
v_toFun_145_ = lean_ctor_get(v___x_144_, 0);
v___f_146_ = ((lean_object*)(lp_c3formal_C3_Tri_Rw___closed__0));
lean_inc(v_toFun_145_);
v___x_147_ = lean_apply_3(v_toFun_145_, v___f_146_, v_a_142_, v_a_143_);
return v___x_147_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleStep4(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Bridge(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_TriangleBridge(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleStep4(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Bridge(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
