// Lean compiler output
// Module: C3formal.TriangleMain
// Imports: public import Init public meta import Init public import C3formal.TriangleMatrix public import Mathlib.Data.Matrix.ColumnRowPartitioned public import Mathlib.LinearAlgebra.Matrix.Block
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_c3formal_C3_Tri_wt_x27(lean_object*);
lean_object* lp_mathlib_Equiv_refl___redArg();
uint8_t l_instDecidableEqSum_decEq___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_c3formal_C3_Tri_wt(lean_object*);
lean_object* lp_c3formal_C3_Tri_At(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
lean_object* lp_c3formal_C3_Tri_Jw(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instDecidableEqFin___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(32) << 1) | 1))} };
static const lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__0 = (const lean_object*)&lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__0_value;
static const lean_closure_object lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_instDecidableEqFin___boxed, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)(((size_t)(3) << 1) | 1))} };
static const lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__1 = (const lean_object*)&lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__1_value;
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__2;
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0(lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_Dm___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_wt, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_Dm___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_Dm___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Dm(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_00_u0394m___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_wt_x27, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_00_u0394m___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_00_u0394m___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_00_u0394m(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_Nt___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Nt___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Nt___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Nt___lam__0___boxed(lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_Nt___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Nt___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_Nt___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_Nt___closed__0_value;
static lean_once_cell_t lp_c3formal_C3_Tri_Nt___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Nt___closed__1;
static lean_once_cell_t lp_c3formal_C3_Tri_Nt___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Nt___closed__2;
static lean_once_cell_t lp_c3formal_C3_Tri_Nt___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Nt___closed__3;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Nt(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__2(void){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_5_ = lean_unsigned_to_nat(0u);
v___x_6_ = lean_nat_to_int(v___x_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0(lean_object* v_d_7_, lean_object* v_i_8_, lean_object* v_j_9_){
_start:
{
lean_object* v___x_10_; lean_object* v___x_11_; uint8_t v___x_12_; 
v___x_10_ = ((lean_object*)(lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__0));
v___x_11_ = ((lean_object*)(lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__1));
lean_inc_ref(v_i_8_);
v___x_12_ = l_instDecidableEqSum_decEq___redArg(v___x_10_, v___x_11_, v_i_8_, v_j_9_);
if (v___x_12_ == 0)
{
lean_object* v___x_13_; 
lean_dec_ref(v_i_8_);
lean_dec_ref(v_d_7_);
v___x_13_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__2, &lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__2_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0___closed__2);
return v___x_13_;
}
else
{
lean_object* v___x_14_; 
v___x_14_ = lean_apply_1(v_d_7_, v_i_8_);
return v___x_14_;
}
}
}
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___closed__0(void){
_start:
{
lean_object* v___x_15_; 
v___x_15_ = lp_mathlib_Equiv_refl___redArg();
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0(lean_object* v_d_16_, lean_object* v_a_17_, lean_object* v_a_18_){
_start:
{
lean_object* v___x_19_; lean_object* v_toFun_20_; lean_object* v___f_21_; lean_object* v___x_22_; 
v___x_19_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___closed__0, &lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___closed__0_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___closed__0);
v_toFun_20_ = lean_ctor_get(v___x_19_, 0);
v___f_21_ = lean_alloc_closure((void*)(lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0___lam__0), 3, 1);
lean_closure_set(v___f_21_, 0, v_d_16_);
lean_inc(v_toFun_20_);
v___x_22_ = lean_apply_3(v_toFun_20_, v___f_21_, v_a_17_, v_a_18_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Dm(lean_object* v_a_24_, lean_object* v_a_25_){
_start:
{
lean_object* v___x_26_; lean_object* v___x_27_; 
v___x_26_ = ((lean_object*)(lp_c3formal_C3_Tri_Dm___closed__0));
v___x_27_ = lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0(v___x_26_, v_a_24_, v_a_25_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_00_u0394m(lean_object* v_a_29_, lean_object* v_a_30_){
_start:
{
lean_object* v___x_31_; lean_object* v___x_32_; 
v___x_31_ = ((lean_object*)(lp_c3formal_C3_Tri_00_u0394m___closed__0));
v___x_32_ = lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0(v___x_31_, v_a_29_, v_a_30_);
return v___x_32_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Nt___lam__0___closed__0(void){
_start:
{
lean_object* v___x_33_; lean_object* v___x_34_; 
v___x_33_ = lean_unsigned_to_nat(1u);
v___x_34_ = lean_nat_to_int(v___x_33_);
return v___x_34_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Nt___lam__0(lean_object* v_x_35_){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = lean_obj_once(&lp_c3formal_C3_Tri_Nt___lam__0___closed__0, &lp_c3formal_C3_Tri_Nt___lam__0___closed__0_once, _init_lp_c3formal_C3_Tri_Nt___lam__0___closed__0);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Nt___lam__0___boxed(lean_object* v_x_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_c3formal_C3_Tri_Nt___lam__0(v_x_37_);
lean_dec_ref(v_x_37_);
return v_res_38_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Nt___closed__1(void){
_start:
{
lean_object* v___x_40_; lean_object* v___x_41_; 
v___x_40_ = lean_unsigned_to_nat(11u);
v___x_41_ = lean_nat_to_int(v___x_40_);
return v___x_41_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Nt___closed__2(void){
_start:
{
lean_object* v___x_42_; lean_object* v___x_43_; 
v___x_42_ = lean_unsigned_to_nat(4u);
v___x_43_ = lean_nat_to_int(v___x_42_);
return v___x_43_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Nt___closed__3(void){
_start:
{
lean_object* v___x_44_; lean_object* v___x_45_; 
v___x_44_ = lean_unsigned_to_nat(2u);
v___x_45_ = lean_nat_to_int(v___x_44_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Nt(lean_object* v_Q_46_, lean_object* v_a_47_, lean_object* v_a_48_, lean_object* v_a_49_){
_start:
{
lean_object* v___f_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; lean_object* v___x_57_; lean_object* v___x_58_; lean_object* v___x_59_; lean_object* v___x_60_; lean_object* v___x_61_; 
v___f_50_ = ((lean_object*)(lp_c3formal_C3_Tri_Nt___closed__0));
v___x_51_ = lean_obj_once(&lp_c3formal_C3_Tri_Nt___closed__1, &lp_c3formal_C3_Tri_Nt___closed__1_once, _init_lp_c3formal_C3_Tri_Nt___closed__1);
v___x_52_ = lean_obj_once(&lp_c3formal_C3_Tri_Nt___closed__2, &lp_c3formal_C3_Tri_Nt___closed__2_once, _init_lp_c3formal_C3_Tri_Nt___closed__2);
v___x_53_ = lean_obj_once(&lp_c3formal_C3_Tri_Nt___closed__3, &lp_c3formal_C3_Tri_Nt___closed__3_once, _init_lp_c3formal_C3_Tri_Nt___closed__3);
lean_inc_ref_n(v_a_49_, 2);
lean_inc_ref_n(v_a_48_, 2);
v___x_54_ = lp_c3formal_C3_Tri_At(v_Q_46_, v_a_47_, v_a_48_, v_a_49_);
v___x_55_ = lp_c3formal_Matrix_diagonal___at___00C3_Tri_Dm_spec__0(v___f_50_, v_a_48_, v_a_49_);
v___x_56_ = lean_int_mul(v___x_52_, v___x_55_);
lean_dec(v___x_55_);
v___x_57_ = lean_int_add(v___x_54_, v___x_56_);
lean_dec(v___x_56_);
lean_dec(v___x_54_);
v___x_58_ = lean_int_mul(v___x_51_, v___x_57_);
lean_dec(v___x_57_);
v___x_59_ = lp_c3formal_C3_Tri_Jw(v_a_48_, v_a_49_);
v___x_60_ = lean_int_mul(v___x_53_, v___x_59_);
lean_dec(v___x_59_);
v___x_61_ = lean_int_sub(v___x_58_, v___x_60_);
lean_dec(v___x_60_);
lean_dec(v___x_58_);
return v___x_61_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleMatrix(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Data_Matrix_ColumnRowPartitioned(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_LinearAlgebra_Matrix_Block(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_TriangleMain(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleMatrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Data_Matrix_ColumnRowPartitioned(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_LinearAlgebra_Matrix_Block(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
