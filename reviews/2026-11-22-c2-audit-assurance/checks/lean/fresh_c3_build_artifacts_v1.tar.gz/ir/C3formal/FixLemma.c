// Lean compiler output
// Module: C3formal.FixLemma
// Imports: public import Init public meta import Init public import C3formal.TriangleGraph public import Mathlib.Combinatorics.Enumerative.DoubleCounting public import Mathlib.GroupTheory.Perm.Cycle.Type
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_toEmbedding___redArg___lam__0(lean_object*, lean_object*);
lean_object* lp_mathlib_Multiset_filter___redArg(lean_object*, lean_object*);
lean_object* l_List_lengthTR___redArg(lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_C3_fixF___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_fixF___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_fixF___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_fixF(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_C3_nfix___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_nfix___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_nfix___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_nfix(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_C3_nnon___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_nnon___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_nnon___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_nnon(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_C3_fixF___redArg___lam__0(lean_object* v_00_u03c3_1_, lean_object* v_inst_2_, lean_object* v_a_3_){
_start:
{
lean_object* v___x_4_; lean_object* v___x_5_; uint8_t v___x_6_; 
lean_inc(v_a_3_);
v___x_4_ = lp_mathlib_Equiv_toEmbedding___redArg___lam__0(v_00_u03c3_1_, v_a_3_);
v___x_5_ = lean_apply_2(v_inst_2_, v___x_4_, v_a_3_);
v___x_6_ = lean_unbox(v___x_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_fixF___redArg___lam__0___boxed(lean_object* v_00_u03c3_7_, lean_object* v_inst_8_, lean_object* v_a_9_){
_start:
{
uint8_t v_res_10_; lean_object* v_r_11_; 
v_res_10_ = lp_c3formal_C3_fixF___redArg___lam__0(v_00_u03c3_7_, v_inst_8_, v_a_9_);
v_r_11_ = lean_box(v_res_10_);
return v_r_11_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_fixF___redArg(lean_object* v_inst_12_, lean_object* v_inst_13_, lean_object* v_00_u03c3_14_){
_start:
{
lean_object* v___f_15_; lean_object* v___x_16_; 
v___f_15_ = lean_alloc_closure((void*)(lp_c3formal_C3_fixF___redArg___lam__0___boxed), 3, 2);
lean_closure_set(v___f_15_, 0, v_00_u03c3_14_);
lean_closure_set(v___f_15_, 1, v_inst_13_);
v___x_16_ = lp_mathlib_Multiset_filter___redArg(v___f_15_, v_inst_12_);
return v___x_16_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_fixF(lean_object* v_V_17_, lean_object* v_inst_18_, lean_object* v_inst_19_, lean_object* v_G_20_, lean_object* v_00_u03c3_21_){
_start:
{
lean_object* v___x_22_; 
v___x_22_ = lp_c3formal_C3_fixF___redArg(v_inst_18_, v_inst_19_, v_00_u03c3_21_);
return v___x_22_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_C3_nfix___redArg___lam__0(lean_object* v_inst_23_, lean_object* v_y_24_, lean_object* v_00_u03c3_25_, lean_object* v_inst_26_, lean_object* v_a_27_){
_start:
{
lean_object* v___x_28_; uint8_t v___x_29_; 
lean_inc(v_a_27_);
v___x_28_ = lean_apply_2(v_inst_23_, v_y_24_, v_a_27_);
v___x_29_ = lean_unbox(v___x_28_);
if (v___x_29_ == 0)
{
uint8_t v___x_30_; 
lean_dec(v_a_27_);
lean_dec_ref(v_inst_26_);
lean_dec_ref(v_00_u03c3_25_);
v___x_30_ = lean_unbox(v___x_28_);
return v___x_30_;
}
else
{
lean_object* v___x_31_; lean_object* v___x_32_; uint8_t v___x_33_; 
lean_inc(v_a_27_);
v___x_31_ = lp_mathlib_Equiv_toEmbedding___redArg___lam__0(v_00_u03c3_25_, v_a_27_);
v___x_32_ = lean_apply_2(v_inst_26_, v___x_31_, v_a_27_);
v___x_33_ = lean_unbox(v___x_32_);
return v___x_33_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_nfix___redArg___lam__0___boxed(lean_object* v_inst_34_, lean_object* v_y_35_, lean_object* v_00_u03c3_36_, lean_object* v_inst_37_, lean_object* v_a_38_){
_start:
{
uint8_t v_res_39_; lean_object* v_r_40_; 
v_res_39_ = lp_c3formal_C3_nfix___redArg___lam__0(v_inst_34_, v_y_35_, v_00_u03c3_36_, v_inst_37_, v_a_38_);
v_r_40_ = lean_box(v_res_39_);
return v_r_40_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_nfix___redArg(lean_object* v_inst_41_, lean_object* v_inst_42_, lean_object* v_inst_43_, lean_object* v_00_u03c3_44_, lean_object* v_y_45_){
_start:
{
lean_object* v___f_46_; lean_object* v___x_47_; lean_object* v___x_48_; 
v___f_46_ = lean_alloc_closure((void*)(lp_c3formal_C3_nfix___redArg___lam__0___boxed), 5, 4);
lean_closure_set(v___f_46_, 0, v_inst_43_);
lean_closure_set(v___f_46_, 1, v_y_45_);
lean_closure_set(v___f_46_, 2, v_00_u03c3_44_);
lean_closure_set(v___f_46_, 3, v_inst_42_);
v___x_47_ = lp_mathlib_Multiset_filter___redArg(v___f_46_, v_inst_41_);
v___x_48_ = l_List_lengthTR___redArg(v___x_47_);
lean_dec(v___x_47_);
return v___x_48_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_nfix(lean_object* v_V_49_, lean_object* v_inst_50_, lean_object* v_inst_51_, lean_object* v_G_52_, lean_object* v_inst_53_, lean_object* v_00_u03c3_54_, lean_object* v_y_55_){
_start:
{
lean_object* v___x_56_; 
v___x_56_ = lp_c3formal_C3_nfix___redArg(v_inst_50_, v_inst_51_, v_inst_53_, v_00_u03c3_54_, v_y_55_);
return v___x_56_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_C3_nnon___redArg___lam__0(lean_object* v_inst_57_, lean_object* v_y_58_, lean_object* v_00_u03c3_59_, lean_object* v_inst_60_, lean_object* v_a_61_){
_start:
{
lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; uint8_t v___x_65_; 
lean_inc_n(v_a_61_, 2);
v___x_62_ = lean_apply_2(v_inst_57_, v_y_58_, v_a_61_);
v___x_63_ = lp_mathlib_Equiv_toEmbedding___redArg___lam__0(v_00_u03c3_59_, v_a_61_);
v___x_64_ = lean_apply_2(v_inst_60_, v___x_63_, v_a_61_);
v___x_65_ = lean_unbox(v___x_64_);
if (v___x_65_ == 0)
{
uint8_t v___x_66_; 
v___x_66_ = lean_unbox(v___x_62_);
return v___x_66_;
}
else
{
uint8_t v___x_67_; 
v___x_67_ = lean_unbox(v___x_62_);
if (v___x_67_ == 0)
{
uint8_t v___x_68_; 
v___x_68_ = lean_unbox(v___x_62_);
return v___x_68_;
}
else
{
uint8_t v___x_69_; 
v___x_69_ = 0;
return v___x_69_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_nnon___redArg___lam__0___boxed(lean_object* v_inst_70_, lean_object* v_y_71_, lean_object* v_00_u03c3_72_, lean_object* v_inst_73_, lean_object* v_a_74_){
_start:
{
uint8_t v_res_75_; lean_object* v_r_76_; 
v_res_75_ = lp_c3formal_C3_nnon___redArg___lam__0(v_inst_70_, v_y_71_, v_00_u03c3_72_, v_inst_73_, v_a_74_);
v_r_76_ = lean_box(v_res_75_);
return v_r_76_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_nnon___redArg(lean_object* v_inst_77_, lean_object* v_inst_78_, lean_object* v_inst_79_, lean_object* v_00_u03c3_80_, lean_object* v_y_81_){
_start:
{
lean_object* v___f_82_; lean_object* v___x_83_; lean_object* v___x_84_; 
v___f_82_ = lean_alloc_closure((void*)(lp_c3formal_C3_nnon___redArg___lam__0___boxed), 5, 4);
lean_closure_set(v___f_82_, 0, v_inst_79_);
lean_closure_set(v___f_82_, 1, v_y_81_);
lean_closure_set(v___f_82_, 2, v_00_u03c3_80_);
lean_closure_set(v___f_82_, 3, v_inst_78_);
v___x_83_ = lp_mathlib_Multiset_filter___redArg(v___f_82_, v_inst_77_);
v___x_84_ = l_List_lengthTR___redArg(v___x_83_);
lean_dec(v___x_83_);
return v___x_84_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_nnon(lean_object* v_V_85_, lean_object* v_inst_86_, lean_object* v_inst_87_, lean_object* v_G_88_, lean_object* v_inst_89_, lean_object* v_00_u03c3_90_, lean_object* v_y_91_){
_start:
{
lean_object* v___x_92_; 
v___x_92_ = lp_c3formal_C3_nnon___redArg(v_inst_86_, v_inst_87_, v_inst_89_, v_00_u03c3_90_, v_y_91_);
return v___x_92_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleGraph(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Combinatorics_Enumerative_DoubleCounting(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_GroupTheory_Perm_Cycle_Type(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_FixLemma(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleGraph(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Combinatorics_Enumerative_DoubleCounting(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_GroupTheory_Perm_Cycle_Type(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
