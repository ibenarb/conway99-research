// Lean compiler output
// Module: C3formal.TriangleStep4
// Imports: public import Init public meta import Init public import C3formal.TriangleStep5
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_onesT___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_onesT___redArg___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT___redArg();
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT___redArg___boxed(lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_onesT___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_onesT___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT___boxed(lean_object*);
static lean_object* _init_lp_c3formal_C3_Tri_onesT___redArg___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(1u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT___redArg(){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_obj_once(&lp_c3formal_C3_Tri_onesT___redArg___closed__0, &lp_c3formal_C3_Tri_onesT___redArg___closed__0_once, _init_lp_c3formal_C3_Tri_onesT___redArg___closed__0);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT___redArg___boxed(lean_object* v___dummy_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = lp_c3formal_C3_Tri_onesT___redArg();
return v_res_6_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_onesT___closed__0(void){
_start:
{
lean_object* v___x_7_; 
v___x_7_ = lp_c3formal_C3_Tri_onesT___redArg();
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT(lean_object* v_x_8_){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lean_obj_once(&lp_c3formal_C3_Tri_onesT___closed__0, &lp_c3formal_C3_Tri_onesT___closed__0_once, _init_lp_c3formal_C3_Tri_onesT___closed__0);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_onesT___boxed(lean_object* v_x_10_){
_start:
{
lean_object* v_res_11_; 
v_res_11_ = lp_c3formal_C3_Tri_onesT(v_x_10_);
lean_dec_ref(v_x_10_);
return v_res_11_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleStep5(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_TriangleStep4(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleStep5(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
