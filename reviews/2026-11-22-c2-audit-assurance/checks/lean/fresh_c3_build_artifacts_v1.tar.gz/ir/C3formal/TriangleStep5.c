// Lean compiler output
// Module: C3formal.TriangleStep5
// Imports: public import Init public meta import Init public import C3formal.TriangleMain
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Int_add___boxed(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* lp_mathlib_Equiv_refl___redArg();
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lp_mathlib_Multiset_map___redArg(lean_object*, lean_object*);
lean_object* l_List_foldrTR___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_int_ediv(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)l_Int_add___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__0 = (const lean_object*)&lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__0_value;
static lean_once_cell_t lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Finset_sum___at___00C3_Tri_Gt_spec__0___redArg(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__0;
static lean_once_cell_t lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__1;
static lean_once_cell_t lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__2;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__2(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_Gt___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Gt___redArg___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Finset_sum___at___00C3_Tri_Gt_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__0(lean_object* v_B_1_, lean_object* v_i_2_, lean_object* v_j_3_, lean_object* v_U_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; 
v___x_5_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_5_, 0, v_U_4_);
lean_inc_ref(v_B_1_);
lean_inc_ref(v___x_5_);
v___x_6_ = lean_apply_2(v_B_1_, v___x_5_, v_i_2_);
v___x_7_ = lean_apply_2(v_B_1_, v___x_5_, v_j_3_);
v___x_8_ = lean_int_mul(v___x_6_, v___x_7_);
lean_dec(v___x_7_);
lean_dec(v___x_6_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__1(lean_object* v_B_9_, lean_object* v_i_10_, lean_object* v___x_11_, lean_object* v_j_12_, lean_object* v_t_13_){
_start:
{
lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; 
v___x_14_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_14_, 0, v_t_13_);
lean_inc_ref(v_B_9_);
lean_inc_ref(v___x_14_);
v___x_15_ = lean_apply_2(v_B_9_, v___x_14_, v_i_10_);
v___x_16_ = lean_int_ediv(v___x_15_, v___x_11_);
lean_dec(v___x_15_);
v___x_17_ = lean_apply_2(v_B_9_, v___x_14_, v_j_12_);
v___x_18_ = lean_int_ediv(v___x_17_, v___x_11_);
lean_dec(v___x_17_);
v___x_19_ = lean_int_mul(v___x_16_, v___x_18_);
lean_dec(v___x_18_);
lean_dec(v___x_16_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__1___boxed(lean_object* v_B_20_, lean_object* v_i_21_, lean_object* v___x_22_, lean_object* v_j_23_, lean_object* v_t_24_){
_start:
{
lean_object* v_res_25_; 
v_res_25_ = lp_c3formal_C3_Tri_Gt___redArg___lam__1(v_B_20_, v_i_21_, v___x_22_, v_j_23_, v_t_24_);
lean_dec(v___x_22_);
return v_res_25_;
}
}
static lean_object* _init_lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__1(void){
_start:
{
lean_object* v___x_27_; lean_object* v___x_28_; 
v___x_27_ = lean_unsigned_to_nat(0u);
v___x_28_ = lean_nat_to_int(v___x_27_);
return v___x_28_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0(lean_object* v_s_29_){
_start:
{
lean_object* v___f_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v___f_30_ = ((lean_object*)(lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__0));
v___x_31_ = lean_obj_once(&lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__1, &lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__1_once, _init_lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0___closed__1);
v___x_32_ = l_List_foldrTR___redArg(v___f_30_, v___x_31_, v_s_29_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Finset_sum___at___00C3_Tri_Gt_spec__0___redArg(lean_object* v_s_33_, lean_object* v_f_34_){
_start:
{
lean_object* v___x_35_; lean_object* v___x_36_; 
v___x_35_ = lp_mathlib_Multiset_map___redArg(v_f_34_, v_s_33_);
v___x_36_ = lp_c3formal_Multiset_sum___at___00Finset_sum___at___00C3_Tri_Gt_spec__0_spec__0(v___x_35_);
return v___x_36_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__0(void){
_start:
{
lean_object* v___x_37_; lean_object* v___x_38_; 
v___x_37_ = lean_unsigned_to_nat(32u);
v___x_38_ = l_List_finRange(v___x_37_);
return v___x_38_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__1(void){
_start:
{
lean_object* v___x_39_; lean_object* v___x_40_; 
v___x_39_ = lean_unsigned_to_nat(3u);
v___x_40_ = lean_nat_to_int(v___x_39_);
return v___x_40_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__2(void){
_start:
{
lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_41_ = lean_unsigned_to_nat(3u);
v___x_42_ = l_List_finRange(v___x_41_);
return v___x_42_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg___lam__2(lean_object* v_B_43_, lean_object* v_i_44_, lean_object* v_j_45_){
_start:
{
lean_object* v___f_46_; lean_object* v___x_47_; lean_object* v___x_48_; lean_object* v___x_49_; lean_object* v___f_50_; lean_object* v___x_51_; lean_object* v___x_52_; lean_object* v___x_53_; lean_object* v___x_54_; 
lean_inc(v_j_45_);
lean_inc(v_i_44_);
lean_inc_ref(v_B_43_);
v___f_46_ = lean_alloc_closure((void*)(lp_c3formal_C3_Tri_Gt___redArg___lam__0), 4, 3);
lean_closure_set(v___f_46_, 0, v_B_43_);
lean_closure_set(v___f_46_, 1, v_i_44_);
lean_closure_set(v___f_46_, 2, v_j_45_);
v___x_47_ = lean_obj_once(&lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__0, &lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__0_once, _init_lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__0);
v___x_48_ = lp_c3formal_Finset_sum___at___00C3_Tri_Gt_spec__0___redArg(v___x_47_, v___f_46_);
v___x_49_ = lean_obj_once(&lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__1, &lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__1_once, _init_lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__1);
v___f_50_ = lean_alloc_closure((void*)(lp_c3formal_C3_Tri_Gt___redArg___lam__1___boxed), 5, 4);
lean_closure_set(v___f_50_, 0, v_B_43_);
lean_closure_set(v___f_50_, 1, v_i_44_);
lean_closure_set(v___f_50_, 2, v___x_49_);
lean_closure_set(v___f_50_, 3, v_j_45_);
v___x_51_ = lean_obj_once(&lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__2, &lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__2_once, _init_lp_c3formal_C3_Tri_Gt___redArg___lam__2___closed__2);
v___x_52_ = lp_c3formal_Finset_sum___at___00C3_Tri_Gt_spec__0___redArg(v___x_51_, v___f_50_);
v___x_53_ = lean_int_mul(v___x_49_, v___x_52_);
lean_dec(v___x_52_);
v___x_54_ = lean_int_add(v___x_48_, v___x_53_);
lean_dec(v___x_53_);
lean_dec(v___x_48_);
return v___x_54_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Gt___redArg___closed__0(void){
_start:
{
lean_object* v___x_55_; 
v___x_55_ = lp_mathlib_Equiv_refl___redArg();
return v___x_55_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___redArg(lean_object* v_B_56_, lean_object* v_a_57_, lean_object* v_a_58_){
_start:
{
lean_object* v___x_59_; lean_object* v_toFun_60_; lean_object* v___f_61_; lean_object* v___x_62_; 
v___x_59_ = lean_obj_once(&lp_c3formal_C3_Tri_Gt___redArg___closed__0, &lp_c3formal_C3_Tri_Gt___redArg___closed__0_once, _init_lp_c3formal_C3_Tri_Gt___redArg___closed__0);
v_toFun_60_ = lean_ctor_get(v___x_59_, 0);
v___f_61_ = lean_alloc_closure((void*)(lp_c3formal_C3_Tri_Gt___redArg___lam__2), 3, 1);
lean_closure_set(v___f_61_, 0, v_B_56_);
lean_inc(v_toFun_60_);
v___x_62_ = lean_apply_3(v_toFun_60_, v___f_61_, v_a_57_, v_a_58_);
return v___x_62_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt(lean_object* v_r_63_, lean_object* v_B_64_, lean_object* v_a_65_, lean_object* v_a_66_){
_start:
{
lean_object* v___x_67_; 
v___x_67_ = lp_c3formal_C3_Tri_Gt___redArg(v_B_64_, v_a_65_, v_a_66_);
return v___x_67_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Gt___boxed(lean_object* v_r_68_, lean_object* v_B_69_, lean_object* v_a_70_, lean_object* v_a_71_){
_start:
{
lean_object* v_res_72_; 
v_res_72_ = lp_c3formal_C3_Tri_Gt(v_r_68_, v_B_69_, v_a_70_, v_a_71_);
lean_dec(v_r_68_);
return v_res_72_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Finset_sum___at___00C3_Tri_Gt_spec__0(lean_object* v_00_u03b9_73_, lean_object* v_s_74_, lean_object* v_f_75_){
_start:
{
lean_object* v___x_76_; 
v___x_76_ = lp_c3formal_Finset_sum___at___00C3_Tri_Gt_spec__0___redArg(v_s_74_, v_f_75_);
return v___x_76_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleMain(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_TriangleStep5(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleMain(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
