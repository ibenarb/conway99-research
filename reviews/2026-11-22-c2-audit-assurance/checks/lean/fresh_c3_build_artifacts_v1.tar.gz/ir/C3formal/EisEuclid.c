// Lean compiler output
// Module: C3formal.EisEuclid
// Imports: public import Init public meta import Init public import C3formal.Eis public import Mathlib.Algebra.EuclideanDomain.Basic public import Mathlib.Algebra.EuclideanDomain.Int public import Mathlib.RingTheory.PrincipalIdealDomain public import Mathlib.Tactic.Linarith public import Mathlib.Tactic.LinearCombination
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* lean_int_neg(lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_ediv(lean_object*, lean_object*);
extern lean_object* lp_c3formal_Eis_commRing;
LEAN_EXPORT lean_object* lp_c3formal_Eis_norm(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_norm___boxed(lean_object*);
static lean_once_cell_t lp_c3formal_Eis_rdiv___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_rdiv___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Eis_rdiv(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_rdiv___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instDiv___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instDiv___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Eis_instDiv___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instDiv___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instDiv___closed__0 = (const lean_object*)&lp_c3formal_Eis_instDiv___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_instDiv = (const lean_object*)&lp_c3formal_Eis_instDiv___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMod___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMod___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Eis_instMod___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instMod___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instMod___closed__0 = (const lean_object*)&lp_c3formal_Eis_instMod___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_instMod = (const lean_object*)&lp_c3formal_Eis_instMod___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__1___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Eis_instEuclideanDomain___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instEuclideanDomain___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instEuclideanDomain___closed__0 = (const lean_object*)&lp_c3formal_Eis_instEuclideanDomain___closed__0_value;
static const lean_closure_object lp_c3formal_Eis_instEuclideanDomain___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instEuclideanDomain___lam__1___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instEuclideanDomain___closed__1 = (const lean_object*)&lp_c3formal_Eis_instEuclideanDomain___closed__1_value;
static lean_once_cell_t lp_c3formal_Eis_instEuclideanDomain___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_instEuclideanDomain___closed__2;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain;
LEAN_EXPORT lean_object* lp_c3formal_Eis_norm(lean_object* v_z_1_){
_start:
{
lean_object* v_re_2_; lean_object* v_im_3_; lean_object* v___x_4_; lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v___x_7_; lean_object* v___x_8_; 
v_re_2_ = lean_ctor_get(v_z_1_, 0);
v_im_3_ = lean_ctor_get(v_z_1_, 1);
v___x_4_ = lean_int_mul(v_re_2_, v_re_2_);
v___x_5_ = lean_int_mul(v_re_2_, v_im_3_);
v___x_6_ = lean_int_sub(v___x_4_, v___x_5_);
lean_dec(v___x_5_);
lean_dec(v___x_4_);
v___x_7_ = lean_int_mul(v_im_3_, v_im_3_);
v___x_8_ = lean_int_add(v___x_6_, v___x_7_);
lean_dec(v___x_7_);
lean_dec(v___x_6_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_norm___boxed(lean_object* v_z_9_){
_start:
{
lean_object* v_res_10_; 
v_res_10_ = lp_c3formal_Eis_norm(v_z_9_);
lean_dec_ref(v_z_9_);
return v_res_10_;
}
}
static lean_object* _init_lp_c3formal_Eis_rdiv___closed__0(void){
_start:
{
lean_object* v___x_11_; lean_object* v___x_12_; 
v___x_11_ = lean_unsigned_to_nat(2u);
v___x_12_ = lean_nat_to_int(v___x_11_);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_rdiv(lean_object* v_a_13_, lean_object* v_n_14_){
_start:
{
lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; 
v___x_15_ = lean_obj_once(&lp_c3formal_Eis_rdiv___closed__0, &lp_c3formal_Eis_rdiv___closed__0_once, _init_lp_c3formal_Eis_rdiv___closed__0);
v___x_16_ = lean_int_mul(v___x_15_, v_a_13_);
v___x_17_ = lean_int_add(v___x_16_, v_n_14_);
lean_dec(v___x_16_);
v___x_18_ = lean_int_mul(v___x_15_, v_n_14_);
v___x_19_ = lean_int_ediv(v___x_17_, v___x_18_);
lean_dec(v___x_18_);
lean_dec(v___x_17_);
return v___x_19_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_rdiv___boxed(lean_object* v_a_20_, lean_object* v_n_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = lp_c3formal_Eis_rdiv(v_a_20_, v_n_21_);
lean_dec(v_n_21_);
lean_dec(v_a_20_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instDiv___lam__0(lean_object* v_x_23_, lean_object* v_y_24_){
_start:
{
lean_object* v_re_25_; lean_object* v_im_26_; lean_object* v_re_27_; lean_object* v_im_28_; lean_object* v___x_30_; uint8_t v_isShared_31_; uint8_t v_isSharedCheck_47_; 
v_re_25_ = lean_ctor_get(v_y_24_, 0);
v_im_26_ = lean_ctor_get(v_y_24_, 1);
v_re_27_ = lean_ctor_get(v_x_23_, 0);
v_im_28_ = lean_ctor_get(v_x_23_, 1);
v_isSharedCheck_47_ = !lean_is_exclusive(v_x_23_);
if (v_isSharedCheck_47_ == 0)
{
v___x_30_ = v_x_23_;
v_isShared_31_ = v_isSharedCheck_47_;
goto v_resetjp_29_;
}
else
{
lean_inc(v_im_28_);
lean_inc(v_re_27_);
lean_dec(v_x_23_);
v___x_30_ = lean_box(0);
v_isShared_31_ = v_isSharedCheck_47_;
goto v_resetjp_29_;
}
v_resetjp_29_:
{
lean_object* v___x_32_; lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_45_; 
v___x_32_ = lean_int_sub(v_re_25_, v_im_26_);
v___x_33_ = lean_int_neg(v_im_26_);
v___x_34_ = lean_int_mul(v_re_27_, v___x_32_);
v___x_35_ = lean_int_mul(v_im_28_, v___x_33_);
v___x_36_ = lean_int_sub(v___x_34_, v___x_35_);
lean_dec(v___x_34_);
v___x_37_ = lean_int_mul(v_re_27_, v___x_33_);
lean_dec(v___x_33_);
lean_dec(v_re_27_);
v___x_38_ = lean_int_mul(v_im_28_, v___x_32_);
lean_dec(v___x_32_);
lean_dec(v_im_28_);
v___x_39_ = lean_int_add(v___x_37_, v___x_38_);
lean_dec(v___x_38_);
lean_dec(v___x_37_);
v___x_40_ = lean_int_sub(v___x_39_, v___x_35_);
lean_dec(v___x_35_);
lean_dec(v___x_39_);
v___x_41_ = lp_c3formal_Eis_norm(v_y_24_);
v___x_42_ = lp_c3formal_Eis_rdiv(v___x_36_, v___x_41_);
lean_dec(v___x_36_);
v___x_43_ = lp_c3formal_Eis_rdiv(v___x_40_, v___x_41_);
lean_dec(v___x_41_);
lean_dec(v___x_40_);
if (v_isShared_31_ == 0)
{
lean_ctor_set(v___x_30_, 1, v___x_43_);
lean_ctor_set(v___x_30_, 0, v___x_42_);
v___x_45_ = v___x_30_;
goto v_reusejp_44_;
}
else
{
lean_object* v_reuseFailAlloc_46_; 
v_reuseFailAlloc_46_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_46_, 0, v___x_42_);
lean_ctor_set(v_reuseFailAlloc_46_, 1, v___x_43_);
v___x_45_ = v_reuseFailAlloc_46_;
goto v_reusejp_44_;
}
v_reusejp_44_:
{
return v___x_45_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instDiv___lam__0___boxed(lean_object* v_x_48_, lean_object* v_y_49_){
_start:
{
lean_object* v_res_50_; 
v_res_50_ = lp_c3formal_Eis_instDiv___lam__0(v_x_48_, v_y_49_);
lean_dec_ref(v_y_49_);
return v_res_50_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMod___lam__0(lean_object* v_x_53_, lean_object* v_y_54_){
_start:
{
lean_object* v_re_55_; lean_object* v_im_56_; lean_object* v_re_57_; lean_object* v_im_58_; lean_object* v___x_60_; uint8_t v_isShared_61_; uint8_t v_isSharedCheck_88_; 
v_re_55_ = lean_ctor_get(v_y_54_, 0);
v_im_56_ = lean_ctor_get(v_y_54_, 1);
v_re_57_ = lean_ctor_get(v_x_53_, 0);
v_im_58_ = lean_ctor_get(v_x_53_, 1);
v_isSharedCheck_88_ = !lean_is_exclusive(v_x_53_);
if (v_isSharedCheck_88_ == 0)
{
v___x_60_ = v_x_53_;
v_isShared_61_ = v_isSharedCheck_88_;
goto v_resetjp_59_;
}
else
{
lean_inc(v_im_58_);
lean_inc(v_re_57_);
lean_dec(v_x_53_);
v___x_60_ = lean_box(0);
v_isShared_61_ = v_isSharedCheck_88_;
goto v_resetjp_59_;
}
v_resetjp_59_:
{
lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; lean_object* v___x_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_70_; lean_object* v___x_71_; lean_object* v___x_72_; lean_object* v___x_73_; lean_object* v___x_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v___x_79_; lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_86_; 
v___x_62_ = lean_int_sub(v_re_55_, v_im_56_);
v___x_63_ = lean_int_neg(v_im_56_);
v___x_64_ = lean_int_mul(v_re_57_, v___x_62_);
v___x_65_ = lean_int_mul(v_im_58_, v___x_63_);
v___x_66_ = lean_int_sub(v___x_64_, v___x_65_);
lean_dec(v___x_64_);
v___x_67_ = lean_int_mul(v_re_57_, v___x_63_);
lean_dec(v___x_63_);
v___x_68_ = lean_int_mul(v_im_58_, v___x_62_);
lean_dec(v___x_62_);
v___x_69_ = lean_int_add(v___x_67_, v___x_68_);
lean_dec(v___x_68_);
lean_dec(v___x_67_);
v___x_70_ = lean_int_sub(v___x_69_, v___x_65_);
lean_dec(v___x_65_);
lean_dec(v___x_69_);
v___x_71_ = lp_c3formal_Eis_norm(v_y_54_);
v___x_72_ = lp_c3formal_Eis_rdiv(v___x_66_, v___x_71_);
lean_dec(v___x_66_);
v___x_73_ = lp_c3formal_Eis_rdiv(v___x_70_, v___x_71_);
lean_dec(v___x_71_);
lean_dec(v___x_70_);
v___x_74_ = lean_int_mul(v_re_55_, v___x_72_);
v___x_75_ = lean_int_mul(v_im_56_, v___x_73_);
v___x_76_ = lean_int_sub(v___x_74_, v___x_75_);
lean_dec(v___x_74_);
v___x_77_ = lean_int_mul(v_re_55_, v___x_73_);
lean_dec(v___x_73_);
v___x_78_ = lean_int_mul(v_im_56_, v___x_72_);
lean_dec(v___x_72_);
v___x_79_ = lean_int_add(v___x_77_, v___x_78_);
lean_dec(v___x_78_);
lean_dec(v___x_77_);
v___x_80_ = lean_int_sub(v___x_79_, v___x_75_);
lean_dec(v___x_75_);
lean_dec(v___x_79_);
v___x_81_ = lean_int_neg(v___x_76_);
lean_dec(v___x_76_);
v___x_82_ = lean_int_neg(v___x_80_);
lean_dec(v___x_80_);
v___x_83_ = lean_int_add(v_re_57_, v___x_81_);
lean_dec(v___x_81_);
lean_dec(v_re_57_);
v___x_84_ = lean_int_add(v_im_58_, v___x_82_);
lean_dec(v___x_82_);
lean_dec(v_im_58_);
if (v_isShared_61_ == 0)
{
lean_ctor_set(v___x_60_, 1, v___x_84_);
lean_ctor_set(v___x_60_, 0, v___x_83_);
v___x_86_ = v___x_60_;
goto v_reusejp_85_;
}
else
{
lean_object* v_reuseFailAlloc_87_; 
v_reuseFailAlloc_87_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_87_, 0, v___x_83_);
lean_ctor_set(v_reuseFailAlloc_87_, 1, v___x_84_);
v___x_86_ = v_reuseFailAlloc_87_;
goto v_reusejp_85_;
}
v_reusejp_85_:
{
return v___x_86_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMod___lam__0___boxed(lean_object* v_x_89_, lean_object* v_y_90_){
_start:
{
lean_object* v_res_91_; 
v_res_91_ = lp_c3formal_Eis_instMod___lam__0(v_x_89_, v_y_90_);
lean_dec_ref(v_y_90_);
return v_res_91_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__0(lean_object* v_x1_94_, lean_object* v_x2_95_){
_start:
{
lean_object* v_re_96_; lean_object* v_im_97_; lean_object* v_re_98_; lean_object* v_im_99_; lean_object* v___x_101_; uint8_t v_isShared_102_; uint8_t v_isSharedCheck_118_; 
v_re_96_ = lean_ctor_get(v_x2_95_, 0);
v_im_97_ = lean_ctor_get(v_x2_95_, 1);
v_re_98_ = lean_ctor_get(v_x1_94_, 0);
v_im_99_ = lean_ctor_get(v_x1_94_, 1);
v_isSharedCheck_118_ = !lean_is_exclusive(v_x1_94_);
if (v_isSharedCheck_118_ == 0)
{
v___x_101_ = v_x1_94_;
v_isShared_102_ = v_isSharedCheck_118_;
goto v_resetjp_100_;
}
else
{
lean_inc(v_im_99_);
lean_inc(v_re_98_);
lean_dec(v_x1_94_);
v___x_101_ = lean_box(0);
v_isShared_102_ = v_isSharedCheck_118_;
goto v_resetjp_100_;
}
v_resetjp_100_:
{
lean_object* v___x_103_; lean_object* v___x_104_; lean_object* v___x_105_; lean_object* v___x_106_; lean_object* v___x_107_; lean_object* v___x_108_; lean_object* v___x_109_; lean_object* v___x_110_; lean_object* v___x_111_; lean_object* v___x_112_; lean_object* v___x_113_; lean_object* v___x_114_; lean_object* v___x_116_; 
v___x_103_ = lean_int_sub(v_re_96_, v_im_97_);
v___x_104_ = lean_int_neg(v_im_97_);
v___x_105_ = lean_int_mul(v_re_98_, v___x_103_);
v___x_106_ = lean_int_mul(v_im_99_, v___x_104_);
v___x_107_ = lean_int_sub(v___x_105_, v___x_106_);
lean_dec(v___x_105_);
v___x_108_ = lean_int_mul(v_re_98_, v___x_104_);
lean_dec(v___x_104_);
lean_dec(v_re_98_);
v___x_109_ = lean_int_mul(v_im_99_, v___x_103_);
lean_dec(v___x_103_);
lean_dec(v_im_99_);
v___x_110_ = lean_int_add(v___x_108_, v___x_109_);
lean_dec(v___x_109_);
lean_dec(v___x_108_);
v___x_111_ = lean_int_sub(v___x_110_, v___x_106_);
lean_dec(v___x_106_);
lean_dec(v___x_110_);
v___x_112_ = lp_c3formal_Eis_norm(v_x2_95_);
v___x_113_ = lp_c3formal_Eis_rdiv(v___x_107_, v___x_112_);
lean_dec(v___x_107_);
v___x_114_ = lp_c3formal_Eis_rdiv(v___x_111_, v___x_112_);
lean_dec(v___x_112_);
lean_dec(v___x_111_);
if (v_isShared_102_ == 0)
{
lean_ctor_set(v___x_101_, 1, v___x_114_);
lean_ctor_set(v___x_101_, 0, v___x_113_);
v___x_116_ = v___x_101_;
goto v_reusejp_115_;
}
else
{
lean_object* v_reuseFailAlloc_117_; 
v_reuseFailAlloc_117_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_117_, 0, v___x_113_);
lean_ctor_set(v_reuseFailAlloc_117_, 1, v___x_114_);
v___x_116_ = v_reuseFailAlloc_117_;
goto v_reusejp_115_;
}
v_reusejp_115_:
{
return v___x_116_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__0___boxed(lean_object* v_x1_119_, lean_object* v_x2_120_){
_start:
{
lean_object* v_res_121_; 
v_res_121_ = lp_c3formal_Eis_instEuclideanDomain___lam__0(v_x1_119_, v_x2_120_);
lean_dec_ref(v_x2_120_);
return v_res_121_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__1(lean_object* v_x1_122_, lean_object* v_x2_123_){
_start:
{
lean_object* v_re_124_; lean_object* v_im_125_; lean_object* v_re_126_; lean_object* v_im_127_; lean_object* v___x_129_; uint8_t v_isShared_130_; uint8_t v_isSharedCheck_157_; 
v_re_124_ = lean_ctor_get(v_x2_123_, 0);
v_im_125_ = lean_ctor_get(v_x2_123_, 1);
v_re_126_ = lean_ctor_get(v_x1_122_, 0);
v_im_127_ = lean_ctor_get(v_x1_122_, 1);
v_isSharedCheck_157_ = !lean_is_exclusive(v_x1_122_);
if (v_isSharedCheck_157_ == 0)
{
v___x_129_ = v_x1_122_;
v_isShared_130_ = v_isSharedCheck_157_;
goto v_resetjp_128_;
}
else
{
lean_inc(v_im_127_);
lean_inc(v_re_126_);
lean_dec(v_x1_122_);
v___x_129_ = lean_box(0);
v_isShared_130_ = v_isSharedCheck_157_;
goto v_resetjp_128_;
}
v_resetjp_128_:
{
lean_object* v___x_131_; lean_object* v___x_132_; lean_object* v___x_133_; lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; lean_object* v___x_149_; lean_object* v___x_150_; lean_object* v___x_151_; lean_object* v___x_152_; lean_object* v___x_153_; lean_object* v___x_155_; 
v___x_131_ = lean_int_sub(v_re_124_, v_im_125_);
v___x_132_ = lean_int_neg(v_im_125_);
v___x_133_ = lean_int_mul(v_re_126_, v___x_131_);
v___x_134_ = lean_int_mul(v_im_127_, v___x_132_);
v___x_135_ = lean_int_sub(v___x_133_, v___x_134_);
lean_dec(v___x_133_);
v___x_136_ = lean_int_mul(v_re_126_, v___x_132_);
lean_dec(v___x_132_);
v___x_137_ = lean_int_mul(v_im_127_, v___x_131_);
lean_dec(v___x_131_);
v___x_138_ = lean_int_add(v___x_136_, v___x_137_);
lean_dec(v___x_137_);
lean_dec(v___x_136_);
v___x_139_ = lean_int_sub(v___x_138_, v___x_134_);
lean_dec(v___x_134_);
lean_dec(v___x_138_);
v___x_140_ = lp_c3formal_Eis_norm(v_x2_123_);
v___x_141_ = lp_c3formal_Eis_rdiv(v___x_135_, v___x_140_);
lean_dec(v___x_135_);
v___x_142_ = lp_c3formal_Eis_rdiv(v___x_139_, v___x_140_);
lean_dec(v___x_140_);
lean_dec(v___x_139_);
v___x_143_ = lean_int_mul(v_re_124_, v___x_141_);
v___x_144_ = lean_int_mul(v_im_125_, v___x_142_);
v___x_145_ = lean_int_sub(v___x_143_, v___x_144_);
lean_dec(v___x_143_);
v___x_146_ = lean_int_mul(v_re_124_, v___x_142_);
lean_dec(v___x_142_);
v___x_147_ = lean_int_mul(v_im_125_, v___x_141_);
lean_dec(v___x_141_);
v___x_148_ = lean_int_add(v___x_146_, v___x_147_);
lean_dec(v___x_147_);
lean_dec(v___x_146_);
v___x_149_ = lean_int_sub(v___x_148_, v___x_144_);
lean_dec(v___x_144_);
lean_dec(v___x_148_);
v___x_150_ = lean_int_neg(v___x_145_);
lean_dec(v___x_145_);
v___x_151_ = lean_int_neg(v___x_149_);
lean_dec(v___x_149_);
v___x_152_ = lean_int_add(v_re_126_, v___x_150_);
lean_dec(v___x_150_);
lean_dec(v_re_126_);
v___x_153_ = lean_int_add(v_im_127_, v___x_151_);
lean_dec(v___x_151_);
lean_dec(v_im_127_);
if (v_isShared_130_ == 0)
{
lean_ctor_set(v___x_129_, 1, v___x_153_);
lean_ctor_set(v___x_129_, 0, v___x_152_);
v___x_155_ = v___x_129_;
goto v_reusejp_154_;
}
else
{
lean_object* v_reuseFailAlloc_156_; 
v_reuseFailAlloc_156_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_156_, 0, v___x_152_);
lean_ctor_set(v_reuseFailAlloc_156_, 1, v___x_153_);
v___x_155_ = v_reuseFailAlloc_156_;
goto v_reusejp_154_;
}
v_reusejp_154_:
{
return v___x_155_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instEuclideanDomain___lam__1___boxed(lean_object* v_x1_158_, lean_object* v_x2_159_){
_start:
{
lean_object* v_res_160_; 
v_res_160_ = lp_c3formal_Eis_instEuclideanDomain___lam__1(v_x1_158_, v_x2_159_);
lean_dec_ref(v_x2_159_);
return v_res_160_;
}
}
static lean_object* _init_lp_c3formal_Eis_instEuclideanDomain___closed__2(void){
_start:
{
lean_object* v___f_163_; lean_object* v___f_164_; lean_object* v___x_165_; lean_object* v___x_166_; 
v___f_163_ = ((lean_object*)(lp_c3formal_Eis_instEuclideanDomain___closed__1));
v___f_164_ = ((lean_object*)(lp_c3formal_Eis_instEuclideanDomain___closed__0));
v___x_165_ = lp_c3formal_Eis_commRing;
v___x_166_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_166_, 0, v___x_165_);
lean_ctor_set(v___x_166_, 1, v___f_164_);
lean_ctor_set(v___x_166_, 2, v___f_163_);
return v___x_166_;
}
}
static lean_object* _init_lp_c3formal_Eis_instEuclideanDomain(void){
_start:
{
lean_object* v___x_167_; 
v___x_167_ = lean_obj_once(&lp_c3formal_Eis_instEuclideanDomain___closed__2, &lp_c3formal_Eis_instEuclideanDomain___closed__2_once, _init_lp_c3formal_Eis_instEuclideanDomain___closed__2);
return v___x_167_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Eis(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Algebra_EuclideanDomain_Basic(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Algebra_EuclideanDomain_Int(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_RingTheory_PrincipalIdealDomain(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_Linarith(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_LinearCombination(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_EisEuclid(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Eis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Algebra_EuclideanDomain_Basic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Algebra_EuclideanDomain_Int(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_RingTheory_PrincipalIdealDomain(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_Linarith(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_LinearCombination(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_c3formal_Eis_instEuclideanDomain = _init_lp_c3formal_Eis_instEuclideanDomain();
lean_mark_persistent(lp_c3formal_Eis_instEuclideanDomain);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
