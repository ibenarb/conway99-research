// Lean compiler output
// Module: C3formal.Eis
// Imports: public import Init public meta import Init public import Mathlib.Algebra.Star.Basic public import Mathlib.Data.ZMod.Basic public import Mathlib.Tactic.Ring
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lean_int_neg(lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
lean_object* lp_mathlib_ZMod_commRing(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* l_nsmulRec___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_zsmulRec___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_npowRec___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_instDecidableEqEis_decEq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_instDecidableEqEis_decEq___boxed(lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_c3formal_instDecidableEqEis(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_instDecidableEqEis___boxed(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_Eis_ofInt___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_ofInt___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Eis_ofInt(lean_object*);
static lean_once_cell_t lp_c3formal_Eis_instZero___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_instZero___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instZero;
static lean_once_cell_t lp_c3formal_Eis_instOne___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_instOne___closed__0;
static lean_once_cell_t lp_c3formal_Eis_instOne___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_instOne___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instOne;
static lean_once_cell_t lp_c3formal_Eis_w___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_w___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Eis_w;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instAdd___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instAdd___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Eis_instAdd___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instAdd___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instAdd___closed__0 = (const lean_object*)&lp_c3formal_Eis_instAdd___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_instAdd = (const lean_object*)&lp_c3formal_Eis_instAdd___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instNeg___lam__0(lean_object*);
static const lean_closure_object lp_c3formal_Eis_instNeg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instNeg___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instNeg___closed__0 = (const lean_object*)&lp_c3formal_Eis_instNeg___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_instNeg = (const lean_object*)&lp_c3formal_Eis_instNeg___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMul___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMul___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Eis_instMul___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instMul___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instMul___closed__0 = (const lean_object*)&lp_c3formal_Eis_instMul___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_instMul = (const lean_object*)&lp_c3formal_Eis_instMul___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__1___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Eis_addCommGroup___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_addCommGroup___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_addCommGroup___closed__0 = (const lean_object*)&lp_c3formal_Eis_addCommGroup___closed__0_value;
static const lean_closure_object lp_c3formal_Eis_addCommGroup___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_addCommGroup___lam__1___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_addCommGroup___closed__1 = (const lean_object*)&lp_c3formal_Eis_addCommGroup___closed__1_value;
static lean_once_cell_t lp_c3formal_Eis_addCommGroup___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_addCommGroup___closed__2;
static lean_once_cell_t lp_c3formal_Eis_addCommGroup___closed__3_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_addCommGroup___closed__3;
static lean_once_cell_t lp_c3formal_Eis_addCommGroup___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_addCommGroup___closed__4;
static lean_once_cell_t lp_c3formal_Eis_addCommGroup___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_addCommGroup___closed__5;
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup;
LEAN_EXPORT lean_object* lp_c3formal_Eis_addGroupWithOne___lam__0(lean_object*);
static const lean_closure_object lp_c3formal_Eis_addGroupWithOne___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_addGroupWithOne___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_addGroupWithOne___closed__0 = (const lean_object*)&lp_c3formal_Eis_addGroupWithOne___closed__0_value;
static const lean_closure_object lp_c3formal_Eis_addGroupWithOne___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_ofInt, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_addGroupWithOne___closed__1 = (const lean_object*)&lp_c3formal_Eis_addGroupWithOne___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_Eis_addGroupWithOne;
LEAN_EXPORT lean_object* lp_c3formal_Eis_commRing___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_commRing___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_Eis_commRing___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_commRing___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_commRing___closed__0 = (const lean_object*)&lp_c3formal_Eis_commRing___closed__0_value;
static lean_once_cell_t lp_c3formal_Eis_commRing___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Eis_commRing___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_Eis_commRing;
LEAN_EXPORT lean_object* lp_c3formal_Eis_instStar___lam__0(lean_object*);
static const lean_closure_object lp_c3formal_Eis_instStar___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_instStar___lam__0, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_instStar___closed__0 = (const lean_object*)&lp_c3formal_Eis_instStar___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_instStar = (const lean_object*)&lp_c3formal_Eis_instStar___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_instStarRing = (const lean_object*)&lp_c3formal_Eis_instStar___closed__0_value;
static lean_once_cell_t lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__0;
static lean_once_cell_t lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_Int_cast___at___00Eis_rho_spec__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_rho___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Eis_rho___lam__0___boxed(lean_object*);
static const lean_closure_object lp_c3formal_Eis_rho___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_Eis_rho___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_Eis_rho___closed__0 = (const lean_object*)&lp_c3formal_Eis_rho___closed__0_value;
LEAN_EXPORT const lean_object* lp_c3formal_Eis_rho = (const lean_object*)&lp_c3formal_Eis_rho___closed__0_value;
LEAN_EXPORT uint8_t lp_c3formal_instDecidableEqEis_decEq(lean_object* v_x_1_, lean_object* v_x_2_){
_start:
{
lean_object* v_re_3_; lean_object* v_im_4_; lean_object* v_re_5_; lean_object* v_im_6_; uint8_t v___x_7_; 
v_re_3_ = lean_ctor_get(v_x_1_, 0);
v_im_4_ = lean_ctor_get(v_x_1_, 1);
v_re_5_ = lean_ctor_get(v_x_2_, 0);
v_im_6_ = lean_ctor_get(v_x_2_, 1);
v___x_7_ = lean_int_dec_eq(v_re_3_, v_re_5_);
if (v___x_7_ == 0)
{
return v___x_7_;
}
else
{
uint8_t v___x_8_; 
v___x_8_ = lean_int_dec_eq(v_im_4_, v_im_6_);
return v___x_8_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_instDecidableEqEis_decEq___boxed(lean_object* v_x_9_, lean_object* v_x_10_){
_start:
{
uint8_t v_res_11_; lean_object* v_r_12_; 
v_res_11_ = lp_c3formal_instDecidableEqEis_decEq(v_x_9_, v_x_10_);
lean_dec_ref(v_x_10_);
lean_dec_ref(v_x_9_);
v_r_12_ = lean_box(v_res_11_);
return v_r_12_;
}
}
LEAN_EXPORT uint8_t lp_c3formal_instDecidableEqEis(lean_object* v_x_13_, lean_object* v_x_14_){
_start:
{
uint8_t v___x_15_; 
v___x_15_ = lp_c3formal_instDecidableEqEis_decEq(v_x_13_, v_x_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_instDecidableEqEis___boxed(lean_object* v_x_16_, lean_object* v_x_17_){
_start:
{
uint8_t v_res_18_; lean_object* v_r_19_; 
v_res_18_ = lp_c3formal_instDecidableEqEis(v_x_16_, v_x_17_);
lean_dec_ref(v_x_17_);
lean_dec_ref(v_x_16_);
v_r_19_ = lean_box(v_res_18_);
return v_r_19_;
}
}
static lean_object* _init_lp_c3formal_Eis_ofInt___closed__0(void){
_start:
{
lean_object* v___x_20_; lean_object* v___x_21_; 
v___x_20_ = lean_unsigned_to_nat(0u);
v___x_21_ = lean_nat_to_int(v___x_20_);
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_ofInt(lean_object* v_n_22_){
_start:
{
lean_object* v___x_23_; lean_object* v___x_24_; 
v___x_23_ = lean_obj_once(&lp_c3formal_Eis_ofInt___closed__0, &lp_c3formal_Eis_ofInt___closed__0_once, _init_lp_c3formal_Eis_ofInt___closed__0);
v___x_24_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_24_, 0, v_n_22_);
lean_ctor_set(v___x_24_, 1, v___x_23_);
return v___x_24_;
}
}
static lean_object* _init_lp_c3formal_Eis_instZero___closed__0(void){
_start:
{
lean_object* v___x_25_; lean_object* v___x_26_; 
v___x_25_ = lean_obj_once(&lp_c3formal_Eis_ofInt___closed__0, &lp_c3formal_Eis_ofInt___closed__0_once, _init_lp_c3formal_Eis_ofInt___closed__0);
v___x_26_ = lp_c3formal_Eis_ofInt(v___x_25_);
return v___x_26_;
}
}
static lean_object* _init_lp_c3formal_Eis_instZero(void){
_start:
{
lean_object* v___x_27_; 
v___x_27_ = lean_obj_once(&lp_c3formal_Eis_instZero___closed__0, &lp_c3formal_Eis_instZero___closed__0_once, _init_lp_c3formal_Eis_instZero___closed__0);
return v___x_27_;
}
}
static lean_object* _init_lp_c3formal_Eis_instOne___closed__0(void){
_start:
{
lean_object* v___x_28_; lean_object* v___x_29_; 
v___x_28_ = lean_unsigned_to_nat(1u);
v___x_29_ = lean_nat_to_int(v___x_28_);
return v___x_29_;
}
}
static lean_object* _init_lp_c3formal_Eis_instOne___closed__1(void){
_start:
{
lean_object* v___x_30_; lean_object* v___x_31_; 
v___x_30_ = lean_obj_once(&lp_c3formal_Eis_instOne___closed__0, &lp_c3formal_Eis_instOne___closed__0_once, _init_lp_c3formal_Eis_instOne___closed__0);
v___x_31_ = lp_c3formal_Eis_ofInt(v___x_30_);
return v___x_31_;
}
}
static lean_object* _init_lp_c3formal_Eis_instOne(void){
_start:
{
lean_object* v___x_32_; 
v___x_32_ = lean_obj_once(&lp_c3formal_Eis_instOne___closed__1, &lp_c3formal_Eis_instOne___closed__1_once, _init_lp_c3formal_Eis_instOne___closed__1);
return v___x_32_;
}
}
static lean_object* _init_lp_c3formal_Eis_w___closed__0(void){
_start:
{
lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; 
v___x_33_ = lean_obj_once(&lp_c3formal_Eis_instOne___closed__0, &lp_c3formal_Eis_instOne___closed__0_once, _init_lp_c3formal_Eis_instOne___closed__0);
v___x_34_ = lean_obj_once(&lp_c3formal_Eis_ofInt___closed__0, &lp_c3formal_Eis_ofInt___closed__0_once, _init_lp_c3formal_Eis_ofInt___closed__0);
v___x_35_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_35_, 0, v___x_34_);
lean_ctor_set(v___x_35_, 1, v___x_33_);
return v___x_35_;
}
}
static lean_object* _init_lp_c3formal_Eis_w(void){
_start:
{
lean_object* v___x_36_; 
v___x_36_ = lean_obj_once(&lp_c3formal_Eis_w___closed__0, &lp_c3formal_Eis_w___closed__0_once, _init_lp_c3formal_Eis_w___closed__0);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instAdd___lam__0(lean_object* v_z_37_, lean_object* v_v_38_){
_start:
{
lean_object* v_re_39_; lean_object* v_im_40_; lean_object* v_re_41_; lean_object* v_im_42_; lean_object* v___x_44_; uint8_t v_isShared_45_; uint8_t v_isSharedCheck_51_; 
v_re_39_ = lean_ctor_get(v_z_37_, 0);
v_im_40_ = lean_ctor_get(v_z_37_, 1);
v_re_41_ = lean_ctor_get(v_v_38_, 0);
v_im_42_ = lean_ctor_get(v_v_38_, 1);
v_isSharedCheck_51_ = !lean_is_exclusive(v_v_38_);
if (v_isSharedCheck_51_ == 0)
{
v___x_44_ = v_v_38_;
v_isShared_45_ = v_isSharedCheck_51_;
goto v_resetjp_43_;
}
else
{
lean_inc(v_im_42_);
lean_inc(v_re_41_);
lean_dec(v_v_38_);
v___x_44_ = lean_box(0);
v_isShared_45_ = v_isSharedCheck_51_;
goto v_resetjp_43_;
}
v_resetjp_43_:
{
lean_object* v___x_46_; lean_object* v___x_47_; lean_object* v___x_49_; 
v___x_46_ = lean_int_add(v_re_39_, v_re_41_);
lean_dec(v_re_41_);
v___x_47_ = lean_int_add(v_im_40_, v_im_42_);
lean_dec(v_im_42_);
if (v_isShared_45_ == 0)
{
lean_ctor_set(v___x_44_, 1, v___x_47_);
lean_ctor_set(v___x_44_, 0, v___x_46_);
v___x_49_ = v___x_44_;
goto v_reusejp_48_;
}
else
{
lean_object* v_reuseFailAlloc_50_; 
v_reuseFailAlloc_50_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_50_, 0, v___x_46_);
lean_ctor_set(v_reuseFailAlloc_50_, 1, v___x_47_);
v___x_49_ = v_reuseFailAlloc_50_;
goto v_reusejp_48_;
}
v_reusejp_48_:
{
return v___x_49_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instAdd___lam__0___boxed(lean_object* v_z_52_, lean_object* v_v_53_){
_start:
{
lean_object* v_res_54_; 
v_res_54_ = lp_c3formal_Eis_instAdd___lam__0(v_z_52_, v_v_53_);
lean_dec_ref(v_z_52_);
return v_res_54_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instNeg___lam__0(lean_object* v_z_57_){
_start:
{
lean_object* v_re_58_; lean_object* v_im_59_; lean_object* v___x_61_; uint8_t v_isShared_62_; uint8_t v_isSharedCheck_68_; 
v_re_58_ = lean_ctor_get(v_z_57_, 0);
v_im_59_ = lean_ctor_get(v_z_57_, 1);
v_isSharedCheck_68_ = !lean_is_exclusive(v_z_57_);
if (v_isSharedCheck_68_ == 0)
{
v___x_61_ = v_z_57_;
v_isShared_62_ = v_isSharedCheck_68_;
goto v_resetjp_60_;
}
else
{
lean_inc(v_im_59_);
lean_inc(v_re_58_);
lean_dec(v_z_57_);
v___x_61_ = lean_box(0);
v_isShared_62_ = v_isSharedCheck_68_;
goto v_resetjp_60_;
}
v_resetjp_60_:
{
lean_object* v___x_63_; lean_object* v___x_64_; lean_object* v___x_66_; 
v___x_63_ = lean_int_neg(v_re_58_);
lean_dec(v_re_58_);
v___x_64_ = lean_int_neg(v_im_59_);
lean_dec(v_im_59_);
if (v_isShared_62_ == 0)
{
lean_ctor_set(v___x_61_, 1, v___x_64_);
lean_ctor_set(v___x_61_, 0, v___x_63_);
v___x_66_ = v___x_61_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v___x_63_);
lean_ctor_set(v_reuseFailAlloc_67_, 1, v___x_64_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMul___lam__0(lean_object* v_z_71_, lean_object* v_v_72_){
_start:
{
lean_object* v_re_73_; lean_object* v_im_74_; lean_object* v_re_75_; lean_object* v_im_76_; lean_object* v___x_78_; uint8_t v_isShared_79_; uint8_t v_isSharedCheck_90_; 
v_re_73_ = lean_ctor_get(v_z_71_, 0);
v_im_74_ = lean_ctor_get(v_z_71_, 1);
v_re_75_ = lean_ctor_get(v_v_72_, 0);
v_im_76_ = lean_ctor_get(v_v_72_, 1);
v_isSharedCheck_90_ = !lean_is_exclusive(v_v_72_);
if (v_isSharedCheck_90_ == 0)
{
v___x_78_ = v_v_72_;
v_isShared_79_ = v_isSharedCheck_90_;
goto v_resetjp_77_;
}
else
{
lean_inc(v_im_76_);
lean_inc(v_re_75_);
lean_dec(v_v_72_);
v___x_78_ = lean_box(0);
v_isShared_79_ = v_isSharedCheck_90_;
goto v_resetjp_77_;
}
v_resetjp_77_:
{
lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v___x_83_; lean_object* v___x_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_88_; 
v___x_80_ = lean_int_mul(v_re_73_, v_re_75_);
v___x_81_ = lean_int_mul(v_im_74_, v_im_76_);
v___x_82_ = lean_int_sub(v___x_80_, v___x_81_);
lean_dec(v___x_80_);
v___x_83_ = lean_int_mul(v_re_73_, v_im_76_);
lean_dec(v_im_76_);
v___x_84_ = lean_int_mul(v_im_74_, v_re_75_);
lean_dec(v_re_75_);
v___x_85_ = lean_int_add(v___x_83_, v___x_84_);
lean_dec(v___x_84_);
lean_dec(v___x_83_);
v___x_86_ = lean_int_sub(v___x_85_, v___x_81_);
lean_dec(v___x_81_);
lean_dec(v___x_85_);
if (v_isShared_79_ == 0)
{
lean_ctor_set(v___x_78_, 1, v___x_86_);
lean_ctor_set(v___x_78_, 0, v___x_82_);
v___x_88_ = v___x_78_;
goto v_reusejp_87_;
}
else
{
lean_object* v_reuseFailAlloc_89_; 
v_reuseFailAlloc_89_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_89_, 0, v___x_82_);
lean_ctor_set(v_reuseFailAlloc_89_, 1, v___x_86_);
v___x_88_ = v_reuseFailAlloc_89_;
goto v_reusejp_87_;
}
v_reusejp_87_:
{
return v___x_88_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instMul___lam__0___boxed(lean_object* v_z_91_, lean_object* v_v_92_){
_start:
{
lean_object* v_res_93_; 
v_res_93_ = lp_c3formal_Eis_instMul___lam__0(v_z_91_, v_v_92_);
lean_dec_ref(v_z_91_);
return v_res_93_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__0(lean_object* v_x1_96_, lean_object* v_x2_97_){
_start:
{
lean_object* v_re_98_; lean_object* v_im_99_; lean_object* v_re_100_; lean_object* v_im_101_; lean_object* v___x_103_; uint8_t v_isShared_104_; uint8_t v_isSharedCheck_110_; 
v_re_98_ = lean_ctor_get(v_x1_96_, 0);
v_im_99_ = lean_ctor_get(v_x1_96_, 1);
v_re_100_ = lean_ctor_get(v_x2_97_, 0);
v_im_101_ = lean_ctor_get(v_x2_97_, 1);
v_isSharedCheck_110_ = !lean_is_exclusive(v_x2_97_);
if (v_isSharedCheck_110_ == 0)
{
v___x_103_ = v_x2_97_;
v_isShared_104_ = v_isSharedCheck_110_;
goto v_resetjp_102_;
}
else
{
lean_inc(v_im_101_);
lean_inc(v_re_100_);
lean_dec(v_x2_97_);
v___x_103_ = lean_box(0);
v_isShared_104_ = v_isSharedCheck_110_;
goto v_resetjp_102_;
}
v_resetjp_102_:
{
lean_object* v___x_105_; lean_object* v___x_106_; lean_object* v___x_108_; 
v___x_105_ = lean_int_add(v_re_98_, v_re_100_);
lean_dec(v_re_100_);
v___x_106_ = lean_int_add(v_im_99_, v_im_101_);
lean_dec(v_im_101_);
if (v_isShared_104_ == 0)
{
lean_ctor_set(v___x_103_, 1, v___x_106_);
lean_ctor_set(v___x_103_, 0, v___x_105_);
v___x_108_ = v___x_103_;
goto v_reusejp_107_;
}
else
{
lean_object* v_reuseFailAlloc_109_; 
v_reuseFailAlloc_109_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_109_, 0, v___x_105_);
lean_ctor_set(v_reuseFailAlloc_109_, 1, v___x_106_);
v___x_108_ = v_reuseFailAlloc_109_;
goto v_reusejp_107_;
}
v_reusejp_107_:
{
return v___x_108_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__0___boxed(lean_object* v_x1_111_, lean_object* v_x2_112_){
_start:
{
lean_object* v_res_113_; 
v_res_113_ = lp_c3formal_Eis_addCommGroup___lam__0(v_x1_111_, v_x2_112_);
lean_dec_ref(v_x1_111_);
return v_res_113_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__1(lean_object* v_a_114_, lean_object* v_b_115_){
_start:
{
lean_object* v_re_116_; lean_object* v_im_117_; lean_object* v_re_118_; lean_object* v_im_119_; lean_object* v___x_121_; uint8_t v_isShared_122_; uint8_t v_isSharedCheck_130_; 
v_re_116_ = lean_ctor_get(v_b_115_, 0);
v_im_117_ = lean_ctor_get(v_b_115_, 1);
v_re_118_ = lean_ctor_get(v_a_114_, 0);
v_im_119_ = lean_ctor_get(v_a_114_, 1);
v_isSharedCheck_130_ = !lean_is_exclusive(v_a_114_);
if (v_isSharedCheck_130_ == 0)
{
v___x_121_ = v_a_114_;
v_isShared_122_ = v_isSharedCheck_130_;
goto v_resetjp_120_;
}
else
{
lean_inc(v_im_119_);
lean_inc(v_re_118_);
lean_dec(v_a_114_);
v___x_121_ = lean_box(0);
v_isShared_122_ = v_isSharedCheck_130_;
goto v_resetjp_120_;
}
v_resetjp_120_:
{
lean_object* v___x_123_; lean_object* v___x_124_; lean_object* v___x_125_; lean_object* v___x_126_; lean_object* v___x_128_; 
v___x_123_ = lean_int_neg(v_re_116_);
v___x_124_ = lean_int_neg(v_im_117_);
v___x_125_ = lean_int_add(v_re_118_, v___x_123_);
lean_dec(v___x_123_);
lean_dec(v_re_118_);
v___x_126_ = lean_int_add(v_im_119_, v___x_124_);
lean_dec(v___x_124_);
lean_dec(v_im_119_);
if (v_isShared_122_ == 0)
{
lean_ctor_set(v___x_121_, 1, v___x_126_);
lean_ctor_set(v___x_121_, 0, v___x_125_);
v___x_128_ = v___x_121_;
goto v_reusejp_127_;
}
else
{
lean_object* v_reuseFailAlloc_129_; 
v_reuseFailAlloc_129_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_129_, 0, v___x_125_);
lean_ctor_set(v_reuseFailAlloc_129_, 1, v___x_126_);
v___x_128_ = v_reuseFailAlloc_129_;
goto v_reusejp_127_;
}
v_reusejp_127_:
{
return v___x_128_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_addCommGroup___lam__1___boxed(lean_object* v_a_131_, lean_object* v_b_132_){
_start:
{
lean_object* v_res_133_; 
v_res_133_ = lp_c3formal_Eis_addCommGroup___lam__1(v_a_131_, v_b_132_);
lean_dec_ref(v_b_132_);
return v_res_133_;
}
}
static lean_object* _init_lp_c3formal_Eis_addCommGroup___closed__2(void){
_start:
{
lean_object* v___f_136_; lean_object* v___x_137_; lean_object* v___x_138_; 
v___f_136_ = ((lean_object*)(lp_c3formal_Eis_addCommGroup___closed__0));
v___x_137_ = lean_obj_once(&lp_c3formal_Eis_instZero___closed__0, &lp_c3formal_Eis_instZero___closed__0_once, _init_lp_c3formal_Eis_instZero___closed__0);
v___x_138_ = lean_alloc_closure((void*)(l_nsmulRec___boxed), 5, 3);
lean_closure_set(v___x_138_, 0, lean_box(0));
lean_closure_set(v___x_138_, 1, v___x_137_);
lean_closure_set(v___x_138_, 2, v___f_136_);
return v___x_138_;
}
}
static lean_object* _init_lp_c3formal_Eis_addCommGroup___closed__3(void){
_start:
{
lean_object* v___x_139_; lean_object* v___f_140_; lean_object* v___x_141_; lean_object* v___x_142_; 
v___x_139_ = lean_obj_once(&lp_c3formal_Eis_addCommGroup___closed__2, &lp_c3formal_Eis_addCommGroup___closed__2_once, _init_lp_c3formal_Eis_addCommGroup___closed__2);
v___f_140_ = ((lean_object*)(lp_c3formal_Eis_instAdd___closed__0));
v___x_141_ = lp_c3formal_Eis_instZero;
v___x_142_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_142_, 0, v___x_141_);
lean_ctor_set(v___x_142_, 1, v___f_140_);
lean_ctor_set(v___x_142_, 2, v___x_139_);
return v___x_142_;
}
}
static lean_object* _init_lp_c3formal_Eis_addCommGroup___closed__4(void){
_start:
{
lean_object* v___x_143_; lean_object* v___f_144_; lean_object* v___f_145_; lean_object* v___x_146_; lean_object* v___x_147_; 
v___x_143_ = lean_obj_once(&lp_c3formal_Eis_addCommGroup___closed__2, &lp_c3formal_Eis_addCommGroup___closed__2_once, _init_lp_c3formal_Eis_addCommGroup___closed__2);
v___f_144_ = ((lean_object*)(lp_c3formal_Eis_instNeg___closed__0));
v___f_145_ = ((lean_object*)(lp_c3formal_Eis_addCommGroup___closed__0));
v___x_146_ = lean_obj_once(&lp_c3formal_Eis_instZero___closed__0, &lp_c3formal_Eis_instZero___closed__0_once, _init_lp_c3formal_Eis_instZero___closed__0);
v___x_147_ = lean_alloc_closure((void*)(lp_mathlib_zsmulRec___boxed), 7, 5);
lean_closure_set(v___x_147_, 0, lean_box(0));
lean_closure_set(v___x_147_, 1, v___x_146_);
lean_closure_set(v___x_147_, 2, v___f_145_);
lean_closure_set(v___x_147_, 3, v___f_144_);
lean_closure_set(v___x_147_, 4, v___x_143_);
return v___x_147_;
}
}
static lean_object* _init_lp_c3formal_Eis_addCommGroup___closed__5(void){
_start:
{
lean_object* v___x_148_; lean_object* v___f_149_; lean_object* v___f_150_; lean_object* v___x_151_; lean_object* v___x_152_; 
v___x_148_ = lean_obj_once(&lp_c3formal_Eis_addCommGroup___closed__4, &lp_c3formal_Eis_addCommGroup___closed__4_once, _init_lp_c3formal_Eis_addCommGroup___closed__4);
v___f_149_ = ((lean_object*)(lp_c3formal_Eis_addCommGroup___closed__1));
v___f_150_ = ((lean_object*)(lp_c3formal_Eis_instNeg___closed__0));
v___x_151_ = lean_obj_once(&lp_c3formal_Eis_addCommGroup___closed__3, &lp_c3formal_Eis_addCommGroup___closed__3_once, _init_lp_c3formal_Eis_addCommGroup___closed__3);
v___x_152_ = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(v___x_152_, 0, v___x_151_);
lean_ctor_set(v___x_152_, 1, v___f_150_);
lean_ctor_set(v___x_152_, 2, v___f_149_);
lean_ctor_set(v___x_152_, 3, v___x_148_);
return v___x_152_;
}
}
static lean_object* _init_lp_c3formal_Eis_addCommGroup(void){
_start:
{
lean_object* v___x_153_; 
v___x_153_ = lean_obj_once(&lp_c3formal_Eis_addCommGroup___closed__5, &lp_c3formal_Eis_addCommGroup___closed__5_once, _init_lp_c3formal_Eis_addCommGroup___closed__5);
return v___x_153_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_addGroupWithOne___lam__0(lean_object* v_n_154_){
_start:
{
lean_object* v___x_155_; lean_object* v___x_156_; 
v___x_155_ = lean_nat_to_int(v_n_154_);
v___x_156_ = lp_c3formal_Eis_ofInt(v___x_155_);
return v___x_156_;
}
}
static lean_object* _init_lp_c3formal_Eis_addGroupWithOne(void){
_start:
{
lean_object* v___x_159_; lean_object* v_toAddMonoid_160_; lean_object* v___f_161_; lean_object* v___x_162_; lean_object* v___f_163_; lean_object* v___f_164_; lean_object* v___x_165_; lean_object* v___x_166_; lean_object* v___x_167_; lean_object* v___x_168_; 
v___x_159_ = lp_c3formal_Eis_addCommGroup;
v_toAddMonoid_160_ = lean_ctor_get(v___x_159_, 0);
v___f_161_ = ((lean_object*)(lp_c3formal_Eis_addGroupWithOne___closed__0));
v___x_162_ = lp_c3formal_Eis_instOne;
v___f_163_ = ((lean_object*)(lp_c3formal_Eis_instNeg___closed__0));
v___f_164_ = ((lean_object*)(lp_c3formal_Eis_addCommGroup___closed__1));
v___x_165_ = lean_obj_once(&lp_c3formal_Eis_addCommGroup___closed__4, &lp_c3formal_Eis_addCommGroup___closed__4_once, _init_lp_c3formal_Eis_addCommGroup___closed__4);
v___x_166_ = ((lean_object*)(lp_c3formal_Eis_addGroupWithOne___closed__1));
lean_inc_ref(v_toAddMonoid_160_);
v___x_167_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_167_, 0, v___f_161_);
lean_ctor_set(v___x_167_, 1, v_toAddMonoid_160_);
lean_ctor_set(v___x_167_, 2, v___x_162_);
v___x_168_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_168_, 0, v___x_166_);
lean_ctor_set(v___x_168_, 1, v___x_167_);
lean_ctor_set(v___x_168_, 2, v___f_163_);
lean_ctor_set(v___x_168_, 3, v___f_164_);
lean_ctor_set(v___x_168_, 4, v___x_165_);
return v___x_168_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_commRing___lam__0(lean_object* v_x1_169_, lean_object* v_x2_170_){
_start:
{
lean_object* v_re_171_; lean_object* v_im_172_; lean_object* v_re_173_; lean_object* v_im_174_; lean_object* v___x_176_; uint8_t v_isShared_177_; uint8_t v_isSharedCheck_188_; 
v_re_171_ = lean_ctor_get(v_x1_169_, 0);
v_im_172_ = lean_ctor_get(v_x1_169_, 1);
v_re_173_ = lean_ctor_get(v_x2_170_, 0);
v_im_174_ = lean_ctor_get(v_x2_170_, 1);
v_isSharedCheck_188_ = !lean_is_exclusive(v_x2_170_);
if (v_isSharedCheck_188_ == 0)
{
v___x_176_ = v_x2_170_;
v_isShared_177_ = v_isSharedCheck_188_;
goto v_resetjp_175_;
}
else
{
lean_inc(v_im_174_);
lean_inc(v_re_173_);
lean_dec(v_x2_170_);
v___x_176_ = lean_box(0);
v_isShared_177_ = v_isSharedCheck_188_;
goto v_resetjp_175_;
}
v_resetjp_175_:
{
lean_object* v___x_178_; lean_object* v___x_179_; lean_object* v___x_180_; lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; lean_object* v___x_186_; 
v___x_178_ = lean_int_mul(v_re_171_, v_re_173_);
v___x_179_ = lean_int_mul(v_im_172_, v_im_174_);
v___x_180_ = lean_int_sub(v___x_178_, v___x_179_);
lean_dec(v___x_178_);
v___x_181_ = lean_int_mul(v_re_171_, v_im_174_);
lean_dec(v_im_174_);
v___x_182_ = lean_int_mul(v_im_172_, v_re_173_);
lean_dec(v_re_173_);
v___x_183_ = lean_int_add(v___x_181_, v___x_182_);
lean_dec(v___x_182_);
lean_dec(v___x_181_);
v___x_184_ = lean_int_sub(v___x_183_, v___x_179_);
lean_dec(v___x_179_);
lean_dec(v___x_183_);
if (v_isShared_177_ == 0)
{
lean_ctor_set(v___x_176_, 1, v___x_184_);
lean_ctor_set(v___x_176_, 0, v___x_180_);
v___x_186_ = v___x_176_;
goto v_reusejp_185_;
}
else
{
lean_object* v_reuseFailAlloc_187_; 
v_reuseFailAlloc_187_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_187_, 0, v___x_180_);
lean_ctor_set(v_reuseFailAlloc_187_, 1, v___x_184_);
v___x_186_ = v_reuseFailAlloc_187_;
goto v_reusejp_185_;
}
v_reusejp_185_:
{
return v___x_186_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_commRing___lam__0___boxed(lean_object* v_x1_189_, lean_object* v_x2_190_){
_start:
{
lean_object* v_res_191_; 
v_res_191_ = lp_c3formal_Eis_commRing___lam__0(v_x1_189_, v_x2_190_);
lean_dec_ref(v_x1_189_);
return v_res_191_;
}
}
static lean_object* _init_lp_c3formal_Eis_commRing___closed__1(void){
_start:
{
lean_object* v___f_193_; lean_object* v___x_194_; lean_object* v___x_195_; 
v___f_193_ = ((lean_object*)(lp_c3formal_Eis_commRing___closed__0));
v___x_194_ = lean_obj_once(&lp_c3formal_Eis_instOne___closed__1, &lp_c3formal_Eis_instOne___closed__1_once, _init_lp_c3formal_Eis_instOne___closed__1);
v___x_195_ = lean_alloc_closure((void*)(l_npowRec___boxed), 5, 3);
lean_closure_set(v___x_195_, 0, lean_box(0));
lean_closure_set(v___x_195_, 1, v___x_194_);
lean_closure_set(v___x_195_, 2, v___f_193_);
return v___x_195_;
}
}
static lean_object* _init_lp_c3formal_Eis_commRing(void){
_start:
{
lean_object* v___x_196_; lean_object* v_toAddMonoidWithOne_197_; lean_object* v_toIntCast_198_; lean_object* v_toNeg_199_; lean_object* v_toSub_200_; lean_object* v_toZSMul_201_; lean_object* v_toNatCast_202_; lean_object* v_toAddMonoid_203_; lean_object* v_toOne_204_; lean_object* v___f_205_; lean_object* v___x_206_; lean_object* v___x_207_; lean_object* v___x_208_; lean_object* v___x_209_; 
v___x_196_ = lp_c3formal_Eis_addGroupWithOne;
v_toAddMonoidWithOne_197_ = lean_ctor_get(v___x_196_, 1);
v_toIntCast_198_ = lean_ctor_get(v___x_196_, 0);
v_toNeg_199_ = lean_ctor_get(v___x_196_, 2);
v_toSub_200_ = lean_ctor_get(v___x_196_, 3);
v_toZSMul_201_ = lean_ctor_get(v___x_196_, 4);
v_toNatCast_202_ = lean_ctor_get(v_toAddMonoidWithOne_197_, 0);
v_toAddMonoid_203_ = lean_ctor_get(v_toAddMonoidWithOne_197_, 1);
v_toOne_204_ = lean_ctor_get(v_toAddMonoidWithOne_197_, 2);
v___f_205_ = ((lean_object*)(lp_c3formal_Eis_instMul___closed__0));
v___x_206_ = lean_obj_once(&lp_c3formal_Eis_commRing___closed__1, &lp_c3formal_Eis_commRing___closed__1_once, _init_lp_c3formal_Eis_commRing___closed__1);
lean_inc(v_toOne_204_);
v___x_207_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_207_, 0, v_toOne_204_);
lean_ctor_set(v___x_207_, 1, v___f_205_);
lean_ctor_set(v___x_207_, 2, v___x_206_);
lean_inc(v_toNatCast_202_);
lean_inc_ref(v_toAddMonoid_203_);
v___x_208_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_208_, 0, v_toAddMonoid_203_);
lean_ctor_set(v___x_208_, 1, v___x_207_);
lean_ctor_set(v___x_208_, 2, v_toNatCast_202_);
lean_inc(v_toIntCast_198_);
lean_inc(v_toZSMul_201_);
lean_inc(v_toSub_200_);
lean_inc(v_toNeg_199_);
v___x_209_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v___x_209_, 0, v___x_208_);
lean_ctor_set(v___x_209_, 1, v_toNeg_199_);
lean_ctor_set(v___x_209_, 2, v_toSub_200_);
lean_ctor_set(v___x_209_, 3, v_toZSMul_201_);
lean_ctor_set(v___x_209_, 4, v_toIntCast_198_);
return v___x_209_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_instStar___lam__0(lean_object* v_z_210_){
_start:
{
lean_object* v_re_211_; lean_object* v_im_212_; lean_object* v___x_214_; uint8_t v_isShared_215_; uint8_t v_isSharedCheck_221_; 
v_re_211_ = lean_ctor_get(v_z_210_, 0);
v_im_212_ = lean_ctor_get(v_z_210_, 1);
v_isSharedCheck_221_ = !lean_is_exclusive(v_z_210_);
if (v_isSharedCheck_221_ == 0)
{
v___x_214_ = v_z_210_;
v_isShared_215_ = v_isSharedCheck_221_;
goto v_resetjp_213_;
}
else
{
lean_inc(v_im_212_);
lean_inc(v_re_211_);
lean_dec(v_z_210_);
v___x_214_ = lean_box(0);
v_isShared_215_ = v_isSharedCheck_221_;
goto v_resetjp_213_;
}
v_resetjp_213_:
{
lean_object* v___x_216_; lean_object* v___x_217_; lean_object* v___x_219_; 
v___x_216_ = lean_int_sub(v_re_211_, v_im_212_);
lean_dec(v_re_211_);
v___x_217_ = lean_int_neg(v_im_212_);
lean_dec(v_im_212_);
if (v_isShared_215_ == 0)
{
lean_ctor_set(v___x_214_, 1, v___x_217_);
lean_ctor_set(v___x_214_, 0, v___x_216_);
v___x_219_ = v___x_214_;
goto v_reusejp_218_;
}
else
{
lean_object* v_reuseFailAlloc_220_; 
v_reuseFailAlloc_220_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_220_, 0, v___x_216_);
lean_ctor_set(v_reuseFailAlloc_220_, 1, v___x_217_);
v___x_219_ = v_reuseFailAlloc_220_;
goto v_reusejp_218_;
}
v_reusejp_218_:
{
return v___x_219_;
}
}
}
}
static lean_object* _init_lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__0(void){
_start:
{
lean_object* v___x_225_; lean_object* v___x_226_; 
v___x_225_ = lean_unsigned_to_nat(3u);
v___x_226_ = lp_mathlib_ZMod_commRing(v___x_225_);
return v___x_226_;
}
}
static lean_object* _init_lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__1(void){
_start:
{
lean_object* v___x_227_; lean_object* v___x_228_; 
v___x_227_ = lean_obj_once(&lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__0, &lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__0_once, _init_lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__0);
v___x_228_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v___x_227_);
return v___x_228_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Int_cast___at___00Eis_rho_spec__0(lean_object* v_a_229_){
_start:
{
lean_object* v___x_230_; lean_object* v_toIntCast_231_; lean_object* v___x_232_; 
v___x_230_ = lean_obj_once(&lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__1, &lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__1_once, _init_lp_c3formal_Int_cast___at___00Eis_rho_spec__0___closed__1);
v_toIntCast_231_ = lean_ctor_get(v___x_230_, 0);
lean_inc(v_toIntCast_231_);
v___x_232_ = lean_apply_1(v_toIntCast_231_, v_a_229_);
return v___x_232_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_rho___lam__0(lean_object* v_z_233_){
_start:
{
lean_object* v_re_234_; lean_object* v_im_235_; lean_object* v___x_236_; lean_object* v___x_237_; 
v_re_234_ = lean_ctor_get(v_z_233_, 0);
v_im_235_ = lean_ctor_get(v_z_233_, 1);
v___x_236_ = lean_int_add(v_re_234_, v_im_235_);
v___x_237_ = lp_c3formal_Int_cast___at___00Eis_rho_spec__0(v___x_236_);
return v___x_237_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Eis_rho___lam__0___boxed(lean_object* v_z_238_){
_start:
{
lean_object* v_res_239_; 
v_res_239_ = lp_c3formal_Eis_rho___lam__0(v_z_238_);
lean_dec_ref(v_z_238_);
return v_res_239_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Algebra_Star_Basic(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Data_ZMod_Basic(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_Ring(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_Eis(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Algebra_Star_Basic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Data_ZMod_Basic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_Ring(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_c3formal_Eis_instZero = _init_lp_c3formal_Eis_instZero();
lean_mark_persistent(lp_c3formal_Eis_instZero);
lp_c3formal_Eis_instOne = _init_lp_c3formal_Eis_instOne();
lean_mark_persistent(lp_c3formal_Eis_instOne);
lp_c3formal_Eis_w = _init_lp_c3formal_Eis_w();
lean_mark_persistent(lp_c3formal_Eis_w);
lp_c3formal_Eis_addCommGroup = _init_lp_c3formal_Eis_addCommGroup();
lean_mark_persistent(lp_c3formal_Eis_addCommGroup);
lp_c3formal_Eis_addGroupWithOne = _init_lp_c3formal_Eis_addGroupWithOne();
lean_mark_persistent(lp_c3formal_Eis_addGroupWithOne);
lp_c3formal_Eis_commRing = _init_lp_c3formal_Eis_commRing();
lean_mark_persistent(lp_c3formal_Eis_commRing);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
