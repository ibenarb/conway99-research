// Lean compiler output
// Module: C3formal.TriangleGraph
// Imports: public import Init public meta import Init public import C3formal.TriangleBridge public import C3formal.Graph
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_subtypeEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_00_u03c3free___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_00_u03c3free(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_00_u03c3free___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_00_u03c3free___redArg(lean_object* v_00_u03c3_1_){
_start:
{
lean_object* v___x_2_; 
v___x_2_ = lp_mathlib_Equiv_subtypeEquiv___redArg(v_00_u03c3_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_00_u03c3free(lean_object* v_V_3_, lean_object* v_inst_4_, lean_object* v_inst_5_, lean_object* v_00_u03c3_6_){
_start:
{
lean_object* v___x_7_; 
v___x_7_ = lp_mathlib_Equiv_subtypeEquiv___redArg(v_00_u03c3_6_);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_00_u03c3free___boxed(lean_object* v_V_8_, lean_object* v_inst_9_, lean_object* v_inst_10_, lean_object* v_00_u03c3_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_c3formal_C3_00_u03c3free(v_V_8_, v_inst_9_, v_inst_10_, v_00_u03c3_11_);
lean_dec_ref(v_inst_10_);
lean_dec(v_inst_9_);
return v_res_12_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_TriangleBridge(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Graph(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_TriangleGraph(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_TriangleBridge(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Graph(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
