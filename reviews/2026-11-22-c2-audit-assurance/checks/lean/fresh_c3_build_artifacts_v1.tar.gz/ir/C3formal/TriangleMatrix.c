// Lean compiler output
// Module: C3formal.TriangleMatrix
// Imports: public import Init public meta import Init public import C3formal.GenLemmas public import C3formal.SaturatedGen public import Mathlib.Data.Matrix.Block public import Mathlib.Tactic.Module public import Mathlib.Tactic.FinCases
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_mathlib_Matrix_transpose___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* l_Sum_elim___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Equiv_refl___redArg();
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_fromBlocks___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_wt___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_wt___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__0___boxed(lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_wt___lam__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_wt___lam__1___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__1___boxed(lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_wt___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_wt___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_wt___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_wt___closed__0_value;
static const lean_closure_object lp_c3formal_C3_Tri_wt___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_wt___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_wt___closed__1 = (const lean_object*)&lp_c3formal_C3_Tri_wt___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt_x27(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Jw___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Jw___lam__0___boxed(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_Tri_Jw___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_Tri_Jw___closed__0;
static const lean_closure_object lp_c3formal_C3_Tri_Jw___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_Jw___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_Jw___closed__1 = (const lean_object*)&lp_c3formal_C3_Tri_Jw___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Jw(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_J3___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_J3___lam__0___boxed(lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_J3___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_J3___lam__0___boxed, .m_arity = 2, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_Tri_J3___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_J3___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_J3(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At___lam__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_c3formal_C3_Tri_At___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*1, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_Tri_At___lam__1, .m_arity = 3, .m_num_fixed = 1, .m_objs = {((lean_object*)&lp_c3formal_C3_Tri_wt___closed__1_value)} };
static const lean_object* lp_c3formal_C3_Tri_At___closed__0 = (const lean_object*)&lp_c3formal_C3_Tri_At___closed__0_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_c3formal_C3_Tri_wt___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(3u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__0(lean_object* v_x_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_obj_once(&lp_c3formal_C3_Tri_wt___lam__0___closed__0, &lp_c3formal_C3_Tri_wt___lam__0___closed__0_once, _init_lp_c3formal_C3_Tri_wt___lam__0___closed__0);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__0___boxed(lean_object* v_x_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = lp_c3formal_C3_Tri_wt___lam__0(v_x_5_);
lean_dec(v_x_5_);
return v_res_6_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_wt___lam__1___closed__0(void){
_start:
{
lean_object* v___x_7_; lean_object* v___x_8_; 
v___x_7_ = lean_unsigned_to_nat(1u);
v___x_8_ = lean_nat_to_int(v___x_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__1(lean_object* v_x_9_){
_start:
{
lean_object* v___x_10_; 
v___x_10_ = lean_obj_once(&lp_c3formal_C3_Tri_wt___lam__1___closed__0, &lp_c3formal_C3_Tri_wt___lam__1___closed__0_once, _init_lp_c3formal_C3_Tri_wt___lam__1___closed__0);
return v___x_10_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt___lam__1___boxed(lean_object* v_x_11_){
_start:
{
lean_object* v_res_12_; 
v_res_12_ = lp_c3formal_C3_Tri_wt___lam__1(v_x_11_);
lean_dec(v_x_11_);
return v_res_12_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt(lean_object* v_a_15_){
_start:
{
lean_object* v___f_16_; lean_object* v___f_17_; lean_object* v___x_18_; 
v___f_16_ = ((lean_object*)(lp_c3formal_C3_Tri_wt___closed__0));
v___f_17_ = ((lean_object*)(lp_c3formal_C3_Tri_wt___closed__1));
v___x_18_ = l_Sum_elim___redArg(v___f_16_, v___f_17_, v_a_15_);
return v___x_18_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_wt_x27(lean_object* v_a_19_){
_start:
{
lean_object* v___f_20_; lean_object* v___f_21_; lean_object* v___x_22_; 
v___f_20_ = ((lean_object*)(lp_c3formal_C3_Tri_wt___closed__1));
v___f_21_ = ((lean_object*)(lp_c3formal_C3_Tri_wt___closed__0));
v___x_22_ = l_Sum_elim___redArg(v___f_20_, v___f_21_, v_a_19_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Jw___lam__0(lean_object* v_x_23_, lean_object* v_y_24_){
_start:
{
lean_object* v___x_25_; 
v___x_25_ = lp_c3formal_C3_Tri_wt(v_y_24_);
return v___x_25_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Jw___lam__0___boxed(lean_object* v_x_26_, lean_object* v_y_27_){
_start:
{
lean_object* v_res_28_; 
v_res_28_ = lp_c3formal_C3_Tri_Jw___lam__0(v_x_26_, v_y_27_);
lean_dec_ref(v_x_26_);
return v_res_28_;
}
}
static lean_object* _init_lp_c3formal_C3_Tri_Jw___closed__0(void){
_start:
{
lean_object* v___x_29_; 
v___x_29_ = lp_mathlib_Equiv_refl___redArg();
return v___x_29_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_Jw(lean_object* v_a_31_, lean_object* v_a_32_){
_start:
{
lean_object* v___x_33_; lean_object* v_toFun_34_; lean_object* v___f_35_; lean_object* v___x_36_; 
v___x_33_ = lean_obj_once(&lp_c3formal_C3_Tri_Jw___closed__0, &lp_c3formal_C3_Tri_Jw___closed__0_once, _init_lp_c3formal_C3_Tri_Jw___closed__0);
v_toFun_34_ = lean_ctor_get(v___x_33_, 0);
v___f_35_ = ((lean_object*)(lp_c3formal_C3_Tri_Jw___closed__1));
lean_inc(v_toFun_34_);
v___x_36_ = lean_apply_3(v_toFun_34_, v___f_35_, v_a_31_, v_a_32_);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_J3___lam__0(lean_object* v_x_37_, lean_object* v_x_38_){
_start:
{
lean_object* v___x_39_; 
v___x_39_ = lean_obj_once(&lp_c3formal_C3_Tri_wt___lam__1___closed__0, &lp_c3formal_C3_Tri_wt___lam__1___closed__0_once, _init_lp_c3formal_C3_Tri_wt___lam__1___closed__0);
return v___x_39_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_J3___lam__0___boxed(lean_object* v_x_40_, lean_object* v_x_41_){
_start:
{
lean_object* v_res_42_; 
v_res_42_ = lp_c3formal_C3_Tri_J3___lam__0(v_x_40_, v_x_41_);
lean_dec(v_x_41_);
lean_dec(v_x_40_);
return v_res_42_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_J3(lean_object* v_a_44_, lean_object* v_a_45_){
_start:
{
lean_object* v___x_46_; lean_object* v_toFun_47_; lean_object* v___f_48_; lean_object* v___x_49_; 
v___x_46_ = lean_obj_once(&lp_c3formal_C3_Tri_Jw___closed__0, &lp_c3formal_C3_Tri_Jw___closed__0_once, _init_lp_c3formal_C3_Tri_Jw___closed__0);
v_toFun_47_ = lean_ctor_get(v___x_46_, 0);
v___f_48_ = ((lean_object*)(lp_c3formal_C3_Tri_J3___closed__0));
lean_inc(v_toFun_47_);
v___x_49_ = lean_apply_3(v_toFun_47_, v___f_48_, v_a_44_, v_a_45_);
return v___x_49_;
}
}
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___closed__0(void){
_start:
{
lean_object* v___x_50_; lean_object* v___x_51_; 
v___x_50_ = lean_unsigned_to_nat(0u);
v___x_51_ = lean_nat_to_int(v___x_50_);
return v___x_51_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0(lean_object* v_d_52_, lean_object* v_i_53_, lean_object* v_j_54_){
_start:
{
uint8_t v___x_55_; 
v___x_55_ = lean_nat_dec_eq(v_i_53_, v_j_54_);
if (v___x_55_ == 0)
{
lean_object* v___x_56_; 
lean_dec(v_i_53_);
lean_dec_ref(v_d_52_);
v___x_56_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___closed__0, &lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___closed__0_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___closed__0);
return v___x_56_;
}
else
{
lean_object* v___x_57_; 
v___x_57_ = lean_apply_1(v_d_52_, v_i_53_);
return v___x_57_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___boxed(lean_object* v_d_58_, lean_object* v_i_59_, lean_object* v_j_60_){
_start:
{
lean_object* v_res_61_; 
v_res_61_ = lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0(v_d_58_, v_i_59_, v_j_60_);
lean_dec(v_j_60_);
return v_res_61_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0(lean_object* v_d_62_, lean_object* v_a_63_, lean_object* v_a_64_){
_start:
{
lean_object* v___x_65_; lean_object* v_toFun_66_; lean_object* v___f_67_; lean_object* v___x_68_; 
v___x_65_ = lean_obj_once(&lp_c3formal_C3_Tri_Jw___closed__0, &lp_c3formal_C3_Tri_Jw___closed__0_once, _init_lp_c3formal_C3_Tri_Jw___closed__0);
v_toFun_66_ = lean_ctor_get(v___x_65_, 0);
v___f_67_ = lean_alloc_closure((void*)(lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0___lam__0___boxed), 3, 1);
lean_closure_set(v___f_67_, 0, v_d_62_);
lean_inc(v_toFun_66_);
v___x_68_ = lean_apply_3(v_toFun_66_, v___f_67_, v_a_63_, v_a_64_);
return v___x_68_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At___lam__1(lean_object* v___f_69_, lean_object* v___y_70_, lean_object* v___y_71_){
_start:
{
lean_object* v___x_72_; lean_object* v___x_73_; lean_object* v___x_74_; 
lean_inc(v___y_71_);
lean_inc(v___y_70_);
v___x_72_ = lp_c3formal_C3_Tri_J3(v___y_70_, v___y_71_);
v___x_73_ = lp_c3formal_Matrix_diagonal___at___00C3_Tri_At_spec__0(v___f_69_, v___y_70_, v___y_71_);
v___x_74_ = lean_int_sub(v___x_72_, v___x_73_);
lean_dec(v___x_73_);
lean_dec(v___x_72_);
return v___x_74_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At___lam__0(lean_object* v_a_75_, lean_object* v___x_76_, lean_object* v___y_77_, lean_object* v___y_78_){
_start:
{
lean_object* v___x_79_; lean_object* v___x_80_; 
v___x_79_ = lp_mathlib_Matrix_transpose___redArg(v_a_75_, v___y_77_, v___y_78_);
v___x_80_ = lean_int_mul(v___x_76_, v___x_79_);
lean_dec(v___x_79_);
return v___x_80_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At___lam__0___boxed(lean_object* v_a_81_, lean_object* v___x_82_, lean_object* v___y_83_, lean_object* v___y_84_){
_start:
{
lean_object* v_res_85_; 
v_res_85_ = lp_c3formal_C3_Tri_At___lam__0(v_a_81_, v___x_82_, v___y_83_, v___y_84_);
lean_dec(v___x_82_);
return v_res_85_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_Tri_At(lean_object* v_Q_88_, lean_object* v_a_89_, lean_object* v_a_90_, lean_object* v_a_91_){
_start:
{
lean_object* v___f_92_; lean_object* v___x_93_; lean_object* v___f_94_; lean_object* v___x_95_; 
v___f_92_ = ((lean_object*)(lp_c3formal_C3_Tri_At___closed__0));
v___x_93_ = lean_obj_once(&lp_c3formal_C3_Tri_wt___lam__0___closed__0, &lp_c3formal_C3_Tri_wt___lam__0___closed__0_once, _init_lp_c3formal_C3_Tri_wt___lam__0___closed__0);
lean_inc_ref(v_a_89_);
v___f_94_ = lean_alloc_closure((void*)(lp_c3formal_C3_Tri_At___lam__0___boxed), 4, 2);
lean_closure_set(v___f_94_, 0, v_a_89_);
lean_closure_set(v___f_94_, 1, v___x_93_);
v___x_95_ = lp_mathlib_Matrix_fromBlocks___redArg(v_Q_88_, v_a_89_, v___f_94_, v___f_92_, v_a_90_, v_a_91_);
return v___x_95_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_GenLemmas(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_SaturatedGen(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Data_Matrix_Block(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_Module(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_FinCases(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_TriangleMatrix(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_GenLemmas(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_SaturatedGen(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Data_Matrix_Block(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_Module(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_FinCases(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
