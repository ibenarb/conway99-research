// Lean compiler output
// Module: C3formal.GenLemmas
// Imports: public import Init public meta import Init public import C3formal.Main
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_c3formal_Eis_ofInt(lean_object*);
lean_object* lp_mathlib_Equiv_refl___redArg();
lean_object* lp_c3formal_Nat_cast___at___00C3_NM_spec__0(lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__0;
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___closed__0;
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_C3_NMn___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NMn___lam__0___closed__0;
static lean_once_cell_t lp_c3formal_C3_NMn___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NMn___lam__0___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn___lam__0___boxed(lean_object*);
static lean_once_cell_t lp_c3formal_C3_NMn___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_C3_NMn___closed__0;
static const lean_closure_object lp_c3formal_C3_NMn___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_c3formal_C3_NMn___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_c3formal_C3_NMn___closed__1 = (const lean_object*)&lp_c3formal_C3_NMn___closed__1_value;
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__0, &lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__0_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__0);
v___x_4_ = lp_c3formal_Eis_ofInt(v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0(lean_object* v_d_5_, lean_object* v_i_6_, lean_object* v_j_7_){
_start:
{
uint8_t v___x_8_; 
v___x_8_ = lean_nat_dec_eq(v_i_6_, v_j_7_);
if (v___x_8_ == 0)
{
lean_object* v___x_9_; 
lean_dec(v_i_6_);
lean_dec_ref(v_d_5_);
v___x_9_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__1, &lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__1_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___closed__1);
return v___x_9_;
}
else
{
lean_object* v___x_10_; 
v___x_10_ = lean_apply_1(v_d_5_, v_i_6_);
return v___x_10_;
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___boxed(lean_object* v_d_11_, lean_object* v_i_12_, lean_object* v_j_13_){
_start:
{
lean_object* v_res_14_; 
v_res_14_ = lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0(v_d_11_, v_i_12_, v_j_13_);
lean_dec(v_j_13_);
return v_res_14_;
}
}
static lean_object* _init_lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___closed__0(void){
_start:
{
lean_object* v___x_15_; 
v___x_15_ = lp_mathlib_Equiv_refl___redArg();
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg(lean_object* v_d_16_, lean_object* v_a_17_, lean_object* v_a_18_){
_start:
{
lean_object* v___x_19_; lean_object* v_toFun_20_; lean_object* v___f_21_; lean_object* v___x_22_; 
v___x_19_ = lean_obj_once(&lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___closed__0, &lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___closed__0_once, _init_lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___closed__0);
v_toFun_20_ = lean_ctor_get(v___x_19_, 0);
v___f_21_ = lean_alloc_closure((void*)(lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg___lam__0___boxed), 3, 1);
lean_closure_set(v___f_21_, 0, v_d_16_);
lean_inc(v_toFun_20_);
v___x_22_ = lean_apply_3(v_toFun_20_, v___f_21_, v_a_17_, v_a_18_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0(lean_object* v_n_23_, lean_object* v_d_24_, lean_object* v_a_25_, lean_object* v_a_26_){
_start:
{
lean_object* v___x_27_; 
v___x_27_ = lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg(v_d_24_, v_a_25_, v_a_26_);
return v___x_27_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___boxed(lean_object* v_n_28_, lean_object* v_d_29_, lean_object* v_a_30_, lean_object* v_a_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0(v_n_28_, v_d_29_, v_a_30_, v_a_31_);
lean_dec(v_n_28_);
return v_res_32_;
}
}
static lean_object* _init_lp_c3formal_C3_NMn___lam__0___closed__0(void){
_start:
{
lean_object* v___x_33_; lean_object* v___x_34_; 
v___x_33_ = lean_unsigned_to_nat(1u);
v___x_34_ = lean_nat_to_int(v___x_33_);
return v___x_34_;
}
}
static lean_object* _init_lp_c3formal_C3_NMn___lam__0___closed__1(void){
_start:
{
lean_object* v___x_35_; lean_object* v___x_36_; 
v___x_35_ = lean_obj_once(&lp_c3formal_C3_NMn___lam__0___closed__0, &lp_c3formal_C3_NMn___lam__0___closed__0_once, _init_lp_c3formal_C3_NMn___lam__0___closed__0);
v___x_36_ = lp_c3formal_Eis_ofInt(v___x_35_);
return v___x_36_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn___lam__0(lean_object* v_x_37_){
_start:
{
lean_object* v___x_38_; 
v___x_38_ = lean_obj_once(&lp_c3formal_C3_NMn___lam__0___closed__1, &lp_c3formal_C3_NMn___lam__0___closed__1_once, _init_lp_c3formal_C3_NMn___lam__0___closed__1);
return v___x_38_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn___lam__0___boxed(lean_object* v_x_39_){
_start:
{
lean_object* v_res_40_; 
v_res_40_ = lp_c3formal_C3_NMn___lam__0(v_x_39_);
lean_dec(v_x_39_);
return v_res_40_;
}
}
static lean_object* _init_lp_c3formal_C3_NMn___closed__0(void){
_start:
{
lean_object* v___x_41_; lean_object* v___x_42_; 
v___x_41_ = lean_unsigned_to_nat(4u);
v___x_42_ = lp_c3formal_Nat_cast___at___00C3_NM_spec__0(v___x_41_);
return v___x_42_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn(lean_object* v_n_44_, lean_object* v_M_45_, lean_object* v_a_46_, lean_object* v_a_47_){
_start:
{
lean_object* v___x_48_; lean_object* v_re_49_; lean_object* v_im_50_; lean_object* v___x_51_; lean_object* v___f_52_; lean_object* v___x_53_; lean_object* v_re_54_; lean_object* v_im_55_; lean_object* v_re_56_; lean_object* v_im_57_; lean_object* v___x_59_; uint8_t v_isShared_60_; uint8_t v_isSharedCheck_73_; 
v___x_48_ = lean_obj_once(&lp_c3formal_C3_NMn___closed__0, &lp_c3formal_C3_NMn___closed__0_once, _init_lp_c3formal_C3_NMn___closed__0);
v_re_49_ = lean_ctor_get(v___x_48_, 0);
v_im_50_ = lean_ctor_get(v___x_48_, 1);
lean_inc(v_a_47_);
lean_inc(v_a_46_);
v___x_51_ = lean_apply_2(v_M_45_, v_a_46_, v_a_47_);
v___f_52_ = ((lean_object*)(lp_c3formal_C3_NMn___closed__1));
v___x_53_ = lp_c3formal_Matrix_diagonal___at___00C3_NMn_spec__0___redArg(v___f_52_, v_a_46_, v_a_47_);
v_re_54_ = lean_ctor_get(v___x_53_, 0);
lean_inc(v_re_54_);
v_im_55_ = lean_ctor_get(v___x_53_, 1);
lean_inc(v_im_55_);
lean_dec_ref(v___x_53_);
v_re_56_ = lean_ctor_get(v___x_51_, 0);
v_im_57_ = lean_ctor_get(v___x_51_, 1);
v_isSharedCheck_73_ = !lean_is_exclusive(v___x_51_);
if (v_isSharedCheck_73_ == 0)
{
v___x_59_ = v___x_51_;
v_isShared_60_ = v_isSharedCheck_73_;
goto v_resetjp_58_;
}
else
{
lean_inc(v_im_57_);
lean_inc(v_re_56_);
lean_dec(v___x_51_);
v___x_59_ = lean_box(0);
v_isShared_60_ = v_isSharedCheck_73_;
goto v_resetjp_58_;
}
v_resetjp_58_:
{
lean_object* v___x_61_; lean_object* v___x_62_; lean_object* v___x_63_; lean_object* v___x_64_; lean_object* v___x_65_; lean_object* v___x_66_; lean_object* v___x_67_; lean_object* v___x_68_; lean_object* v___x_69_; lean_object* v___x_71_; 
v___x_61_ = lean_int_mul(v_re_49_, v_re_54_);
v___x_62_ = lean_int_mul(v_im_50_, v_im_55_);
v___x_63_ = lean_int_sub(v___x_61_, v___x_62_);
lean_dec(v___x_61_);
v___x_64_ = lean_int_mul(v_re_49_, v_im_55_);
lean_dec(v_im_55_);
v___x_65_ = lean_int_mul(v_im_50_, v_re_54_);
lean_dec(v_re_54_);
v___x_66_ = lean_int_add(v___x_64_, v___x_65_);
lean_dec(v___x_65_);
lean_dec(v___x_64_);
v___x_67_ = lean_int_sub(v___x_66_, v___x_62_);
lean_dec(v___x_62_);
lean_dec(v___x_66_);
v___x_68_ = lean_int_add(v_re_56_, v___x_63_);
lean_dec(v___x_63_);
lean_dec(v_re_56_);
v___x_69_ = lean_int_add(v_im_57_, v___x_67_);
lean_dec(v___x_67_);
lean_dec(v_im_57_);
if (v_isShared_60_ == 0)
{
lean_ctor_set(v___x_59_, 1, v___x_69_);
lean_ctor_set(v___x_59_, 0, v___x_68_);
v___x_71_ = v___x_59_;
goto v_reusejp_70_;
}
else
{
lean_object* v_reuseFailAlloc_72_; 
v_reuseFailAlloc_72_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_72_, 0, v___x_68_);
lean_ctor_set(v_reuseFailAlloc_72_, 1, v___x_69_);
v___x_71_ = v_reuseFailAlloc_72_;
goto v_reusejp_70_;
}
v_reusejp_70_:
{
return v___x_71_;
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_NMn___boxed(lean_object* v_n_74_, lean_object* v_M_75_, lean_object* v_a_76_, lean_object* v_a_77_){
_start:
{
lean_object* v_res_78_; 
v_res_78_ = lp_c3formal_C3_NMn(v_n_74_, v_M_75_, v_a_76_, v_a_77_);
lean_dec(v_n_74_);
return v_res_78_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Main(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_GenLemmas(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Main(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
