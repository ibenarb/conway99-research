// Lean compiler output
// Module: C3formal.Bridge
// Imports: public import Init public meta import Init public import C3formal.Main public import Mathlib.Tactic.FinCases
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_to_int(lean_object*);
lean_object* lp_c3formal_Eis_ofInt(lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_int_mul(lean_object*, lean_object*);
lean_object* lean_int_sub(lean_object*, lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
extern lean_object* lp_c3formal_Eis_w;
lean_object* lp_mathlib_ZMod_val(lean_object*, lean_object*);
static lean_once_cell_t lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__0;
static lean_once_cell_t lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__1;
LEAN_EXPORT lean_object* lp_c3formal_npowRec___at___00C3_wpow_spec__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_npowRec___at___00C3_wpow_spec__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_wpow(lean_object*);
LEAN_EXPORT lean_object* lp_c3formal_C3_wpow___boxed(lean_object*);
static lean_object* _init_lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(1u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__1(void){
_start:
{
lean_object* v___x_3_; lean_object* v___x_4_; 
v___x_3_ = lean_obj_once(&lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__0, &lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__0_once, _init_lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__0);
v___x_4_ = lp_c3formal_Eis_ofInt(v___x_3_);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_npowRec___at___00C3_wpow_spec__0(lean_object* v_x_5_, lean_object* v_x_6_){
_start:
{
lean_object* v_zero_7_; uint8_t v_isZero_8_; 
v_zero_7_ = lean_unsigned_to_nat(0u);
v_isZero_8_ = lean_nat_dec_eq(v_x_5_, v_zero_7_);
if (v_isZero_8_ == 1)
{
lean_object* v___x_9_; 
lean_dec_ref(v_x_6_);
v___x_9_ = lean_obj_once(&lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__1, &lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__1_once, _init_lp_c3formal_npowRec___at___00C3_wpow_spec__0___closed__1);
return v___x_9_;
}
else
{
lean_object* v_one_10_; lean_object* v_n_11_; lean_object* v___x_12_; lean_object* v_re_13_; lean_object* v_im_14_; lean_object* v_re_15_; lean_object* v_im_16_; lean_object* v___x_18_; uint8_t v_isShared_19_; uint8_t v_isSharedCheck_30_; 
v_one_10_ = lean_unsigned_to_nat(1u);
v_n_11_ = lean_nat_sub(v_x_5_, v_one_10_);
lean_inc_ref(v_x_6_);
v___x_12_ = lp_c3formal_npowRec___at___00C3_wpow_spec__0(v_n_11_, v_x_6_);
lean_dec(v_n_11_);
v_re_13_ = lean_ctor_get(v___x_12_, 0);
lean_inc(v_re_13_);
v_im_14_ = lean_ctor_get(v___x_12_, 1);
lean_inc(v_im_14_);
lean_dec_ref(v___x_12_);
v_re_15_ = lean_ctor_get(v_x_6_, 0);
v_im_16_ = lean_ctor_get(v_x_6_, 1);
v_isSharedCheck_30_ = !lean_is_exclusive(v_x_6_);
if (v_isSharedCheck_30_ == 0)
{
v___x_18_ = v_x_6_;
v_isShared_19_ = v_isSharedCheck_30_;
goto v_resetjp_17_;
}
else
{
lean_inc(v_im_16_);
lean_inc(v_re_15_);
lean_dec(v_x_6_);
v___x_18_ = lean_box(0);
v_isShared_19_ = v_isSharedCheck_30_;
goto v_resetjp_17_;
}
v_resetjp_17_:
{
lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v___x_28_; 
v___x_20_ = lean_int_mul(v_re_13_, v_re_15_);
v___x_21_ = lean_int_mul(v_im_14_, v_im_16_);
v___x_22_ = lean_int_sub(v___x_20_, v___x_21_);
lean_dec(v___x_20_);
v___x_23_ = lean_int_mul(v_re_13_, v_im_16_);
lean_dec(v_im_16_);
lean_dec(v_re_13_);
v___x_24_ = lean_int_mul(v_im_14_, v_re_15_);
lean_dec(v_re_15_);
lean_dec(v_im_14_);
v___x_25_ = lean_int_add(v___x_23_, v___x_24_);
lean_dec(v___x_24_);
lean_dec(v___x_23_);
v___x_26_ = lean_int_sub(v___x_25_, v___x_21_);
lean_dec(v___x_21_);
lean_dec(v___x_25_);
if (v_isShared_19_ == 0)
{
lean_ctor_set(v___x_18_, 1, v___x_26_);
lean_ctor_set(v___x_18_, 0, v___x_22_);
v___x_28_ = v___x_18_;
goto v_reusejp_27_;
}
else
{
lean_object* v_reuseFailAlloc_29_; 
v_reuseFailAlloc_29_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_29_, 0, v___x_22_);
lean_ctor_set(v_reuseFailAlloc_29_, 1, v___x_26_);
v___x_28_ = v_reuseFailAlloc_29_;
goto v_reusejp_27_;
}
v_reusejp_27_:
{
return v___x_28_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_c3formal_npowRec___at___00C3_wpow_spec__0___boxed(lean_object* v_x_31_, lean_object* v_x_32_){
_start:
{
lean_object* v_res_33_; 
v_res_33_ = lp_c3formal_npowRec___at___00C3_wpow_spec__0(v_x_31_, v_x_32_);
lean_dec(v_x_31_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_wpow(lean_object* v_b_34_){
_start:
{
lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; 
v___x_35_ = lp_c3formal_Eis_w;
v___x_36_ = lean_unsigned_to_nat(3u);
v___x_37_ = lp_mathlib_ZMod_val(v___x_36_, v_b_34_);
v___x_38_ = lp_c3formal_npowRec___at___00C3_wpow_spec__0(v___x_37_, v___x_35_);
lean_dec(v___x_37_);
return v___x_38_;
}
}
LEAN_EXPORT lean_object* lp_c3formal_C3_wpow___boxed(lean_object* v_b_39_){
_start:
{
lean_object* v_res_40_; 
v_res_40_ = lp_c3formal_C3_wpow(v_b_39_);
lean_dec(v_b_39_);
return v_res_40_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_c3formal_C3formal_Main(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib_Tactic_FinCases(uint8_t builtin);
void lean_initialize();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_c3formal_C3formal_Bridge(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_c3formal_C3formal_Main(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib_Tactic_FinCases(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
