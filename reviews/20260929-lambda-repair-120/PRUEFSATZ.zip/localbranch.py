"""Gegenprobe am Kampagnenmodell 2077_09_s60_defect: gleiche Modellierung, zusätzlich Hamming-Kugel
um den Gründer (local branching). Keine Kampagne, nur Mechanismustest."""
import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')

import json,sys,time
sys.path.insert(0,REPO+'/experiments/memetik/lambda_repair_1_2_0')
from ortools.sat.python import cp_model
import model as M0
exec(open('lines.py').read().split('F={f')[0])
Fd={f['id']:f for f in M['founders']}
task=sys.argv[1]; radius=int(sys.argv[2]); tl=float(sys.argv[3]); mode=sys.argv[4] if len(sys.argv)>4 else 'ball'
t=[t for t in M['tasks'] if t['id']==task][0]; rows=g6(Fd[t['founder']]['graph6'])
t0=time.process_time()
m,edges,obj,mult,h=M0.build(rows,t['vertices'])
var=[(k,v) for k,v in edges.items() if not isinstance(v,int)]
diff=[(x.Not() if (w in rows[u]) else x) for (u,w),x in var]
if mode.startswith('ball'): m.add(sum(diff)<=radius)
s=cp_model.CpSolver(); s.parameters.max_time_in_seconds=tl
if mode=='ball': s.parameters.num_workers=1
elif mode=='ballnolp': s.parameters.num_workers=1; s.parameters.linearization_level=0
elif mode=='nolp': s.parameters.num_workers=1; s.parameters.linearization_level=0
elif mode=='lns': s.parameters.num_workers=1; s.parameters.interleave_search=True
class CB(cp_model.CpSolverSolutionCallback):
    def __init__(self): super().__init__(); self.hist=[]
    def on_solution_callback(self): self.hist.append((round(self.wall_time,1),int(self.objective_value)//50000,int(self.objective_value)%50000))
cb=CB(); tb=time.process_time()-t0
st=s.solve(m,cb); dt=time.process_time()-t0
if st in (cp_model.OPTIMAL,cp_model.FEASIBLE):
    new=M0.extract(rows,edges,s.value)
    json.dump([sorted(r) for r in new],open(f'best_{task}_{mode}_r{radius}.json','w'))
print(json.dumps({'task':task,'mode':mode,'radius':radius,'status':s.status_name(st),'objective':s.objective_value,
  'W':int(s.objective_value)//50000,'L1':int(s.objective_value)%50000,'cpu_incl_build':round(dt,1),'wall':round(s.wall_time,1),'conflicts':s.num_conflicts,'build_cpu':round(tb,1),'solutions_wall_W_L1':cb.hist}))
