import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')
import json,itertools
exec(open('star_descent.py').read().split("pool=json.load")[0])
Fd={f['id']:f for f in M['founders']}
old=g6(Fd['2077_09']['graph6'])
moves={15:[(15,39,42),(15,64,65),(15,66,95)],26:[(26,40,88),(26,42,58)],6:[(6,52,92),(6,62,87)]}
def star_apply(rows,p,newlines):
    new=[set(r) for r in rows]
    for l in newlines:
        a,b=[x for x in l if x!=p]
        for x in (a,b):
            old_partner=next(iter(rows[x]&rows[p])); new[x].discard(old_partner); new[old_partner].discard(x)
    for l in newlines:
        a,b=[x for x in l if x!=p]; new[a].add(b); new[b].add(a)
    return new
for order in itertools.permutations([15,26,6]):
    r=old; path=[score_bits(tobits(r))]; ok=True
    for p in order:
        r=star_apply(r,p,moves[p])
        if not lam_ok(r): ok=False; break
        path.append(score_bits(tobits(r)))
    print(order,'all intermediate states lambda-valid' if ok else 'invalid intermediate at p=%d'%p,path)
