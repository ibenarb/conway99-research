import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')
import json
exec(open('star.py').read().split("if __name__")[0])
Fd={f['id']:f for f in M['founders']}
for fid,f in Fd.items():
    rows=g6(f['graph6']); B=tobits(rows)
    base=score_bits(B)
    # all improving star moves
    impr=[]
    for p in range(99):
        N=sorted(rows[p]); Np=B[p]|(1<<p); partner={x:next(iter(rows[x]&rows[p])) for x in N}
        comp={x:set() for x in N}
        for i,x in enumerate(N):
            for y in N[i+1:]:
                if y==partner[x] or (((B[x]&B[y])&~Np)==0 and not (B[x]>>y)&1): comp[x].add(y); comp[y].add(x)
        mats=[]
        def rec(left,cur):
            if not left: mats.append(list(cur)); return
            x=left[0]
            for y in comp[x]:
                if y in left: cur.append((x,y)); rec([z for z in left if z not in (x,y)],cur); cur.pop()
        rec(N,[])
        W0,L0=pair_contrib(B,N)
        for m in mats:
            ch=[x for x,y in m if partner[x]!=y]
            if not ch: continue
            B2=B[:]
            for x in N: B2[x]&=~(1<<partner[x])
            for x,y in m: B2[x]|=1<<y; B2[y]|=1<<x
            W1,L1=pair_contrib(B2,N); nw=(base[0]-W0+W1,base[1]-L0+L1)
            if nw<base:
                sup=set(x for x,y in m if partner[x]!=y)|set(y for x,y in m if partner[x]!=y)
                impr.append((nw,p,sorted(sup)))
    if not impr: continue
    for nw,p,sup in impr:
        cont={t['id'].split('_',2)[2]:set(sup)<=set(t['vertices']) for t in M['tasks'] if t['founder']==fid}
        print(fid,base,'->',nw,'p',p,'support',len(sup),'contained in:',[k for k,v in cont.items() if v])
