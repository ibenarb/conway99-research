import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')
import json,time
exec(open('star_descent.py').read().split("pool=json.load")[0])
def moves(rows):
    B=tobits(rows); out=[]
    for p in range(99):
        N=sorted(rows[p]); Np=B[p]|(1<<p); partner={x:next(iter(rows[x]&rows[p])) for x in N}
        comp={x:set() for x in N}
        for i,x in enumerate(N):
            for y in N[i+1:]:
                if y==partner[x] or (((B[x]&B[y])&~Np)==0 and not (B[x]>>y)&1): comp[x].add(y); comp[y].add(x)
        mats=[]
        def rec(left,cur):
            if not left: mats.append(list(cur)); return
            x=left[0]
            for y in comp[x]:
                if y in left: cur.append((x,y)); rec([z for z in left if z not in (x,y)],cur); cur.pop()
        rec(N,[])
        for m in mats:
            if any(partner[x]!=y for x,y in m): out.append((p,m))
    return out
pool=json.load(open(REPO+'/docs/memetik/lambda_repair_results_20260929/CANDIDATES_25.json'))
for c in pool:
    if c['scores']['W'] not in (2076,2077): continue
    rows=g6(c['graph6']); base=score_bits(tobits(rows)); t0=time.time()
    first=moves(rows); best=None; n2=0
    for p,m in first:
        r1=apply(rows,p,m)
        b,nv,ni,sw,bb,pp=census(r1); n2+=nv
        if bb and (best is None or bb[0]<best): best=bb[0]
    print(base,'depth1 moves',len(first),'depth2 sequences',n2,'best after 2 star moves',best,'improves' if best<base else 'no improvement',round(time.time()-t0,1),'s',flush=True)
