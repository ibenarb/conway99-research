import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')
import json,time,hashlib
exec(open('star.py').read().split("if __name__")[0])
def apply(rows,p,m):
    new=[set(r) for r in rows]
    N=sorted(rows[p]); partner={x:next(iter(rows[x]&rows[p])) for x in N}
    for x in N: new[x].discard(partner[x])
    for x,y in m: new[x].add(y); new[y].add(x)
    return new
def lam_ok(rows):
    return all(len(r)==14 for r in rows) and all(len(rows[u]&rows[v])==1 for u in range(99) for v in rows[u])
def enc_g6(rows):
    n=len(rows); bits=[1 if i in rows[j] else 0 for j in range(1,n) for i in range(j)]
    bits+= [0]*((-len(bits))%6)
    head=chr(126)+''.join(chr(63+((n>>s)&63)) for s in (12,6,0)) if n>62 else chr(63+n)
    return head+''.join(chr(63+int(''.join(map(str,bits[i:i+6])),2)) for i in range(0,len(bits),6))
ends=[]
pool=json.load(open(REPO+'/docs/memetik/lambda_repair_results_20260929/CANDIDATES_25.json'))
out=[]
for c in pool:
    rows=g6(c['graph6']); path=[tuple(c['scores'][k] for k in ('W','L1'))]
    while True:
        base,nv,ni,sw,best,pp=census(rows)
        if best is None or best[0]>=base: break
        rows=apply(rows,best[1],best[2]); assert lam_ok(rows)
        s=score_bits(tobits(rows)); assert s==best[0]; path.append(s)
    ends.append({'start':path[0],'end':path[-1],'steps':len(path)-1,'graph6':enc_g6(rows)}); assert score_bits(tobits(g6(ends[-1]['graph6'])))==path[-1]
    out.append(path); print(path[0],'->',path[-1],'steps',len(path)-1,flush=True)
json.dump(out,open('star_descent.json','w'))
json.dump(ends,open('star_descent_endpoints.json','w'),indent=1)
