"""Gibt es in einem festen Fenster überhaupt eine andere zulässige (Grad 14, lambda=1) Belegung?
Kein Zielwert; nur Existenz einer von der Gründerbelegung verschiedenen Füllung, plus deren W."""
import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')

import json,sys,time
sys.path.insert(0,REPO+'/experiments/memetik/lambda_repair_1_2_0')
from ortools.sat.python import cp_model
import model as M0
exec(open('lines.py').read().split('F={f')[0])  # g6 decoder + manifest
Fd={f['id']:f for f in M['founders']}
def score(rows):
    W=L1=0
    for v in range(99):
        for u in range(v):
            r=len(rows[u]&rows[v])+(v in rows[u])-2
            W+=r!=0; L1+=abs(r)
    return W,L1
sizes=[int(a) for a in sys.argv[1].split(',')]; tl=float(sys.argv[2])
res=[]
for t in M['tasks']:
    if t['size'] not in sizes: continue
    rows=g6(Fd[t['founder']]['graph6'])
    m,edges,obj,mult,h=M0.build(rows,t['vertices'])
    m.clear_objective() if hasattr(m,'clear_objective') else None
    m.proto.ClearField('objective')
    var=[(k,v) for k,v in edges.items() if not isinstance(v,int)]
    diff=[]
    for (u,w),x in var:
        diff.append(x.Not() if (w in rows[u]) else x)
    m.add_bool_or(diff)
    m.clear_hints()
    s=cp_model.CpSolver(); s.parameters.max_time_in_seconds=tl; s.parameters.num_workers=1
    t0=time.process_time(); st=s.solve(m); dt=time.process_time()-t0
    rec={'id':t['id'],'status':s.status_name(st),'cpu':round(dt,2)}
    if st in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        new=M0.extract(rows,edges,s.value)
        rec['W_L1']=score(new); rec['founder']=[Fd[t['founder']]['scores']['W'],Fd[t['founder']]['scores']['L1']]
        rec['changed_edges']=sum(1 for (u,w),x in var if s.value(x)!=(w in rows[u]))
    res.append(rec); print(json.dumps(rec),flush=True)
json.dump(res,open(f'alt_{sys.argv[1].replace(",","_")}.json','w'),indent=1)
