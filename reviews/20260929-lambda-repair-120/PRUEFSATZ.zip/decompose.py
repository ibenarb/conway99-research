"""Zerlegt die Differenz zwischen Gründer und Solverlösung in Linienaustausche und prüft,
ob sie aus Sternzügen (alle beteiligten Linien durch einen Punkt) besteht."""
import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')

import json,sys
exec(open('star_descent.py').read().split("pool=json.load")[0])
Fd={f['id']:f for f in M['founders']}
old=g6(Fd[sys.argv[1]]['graph6']); new=[set(r) for r in json.load(open(sys.argv[2]))]
assert lam_ok(new); print('W,L1 new',score_bits(tobits(new)))
def lines(rows):
    L=set()
    for u in range(99):
        for v in rows[u]:
            if v>u: w=next(iter(rows[u]&rows[v])); L.add(tuple(sorted((u,v,w))))
    return L
Lo,Ln=lines(old),lines(new); R=sorted(Lo-Ln); A=sorted(Ln-Lo)
d=[(u,v) for v in range(99) for u in range(v) if (v in old[u])!=(v in new[u])]
print('changed edges',len(d),'lines removed',len(R),'added',len(A))
# group by common point: connected components of the "shares a point" relation among removed+added lines
allL=R+A; parent=list(range(len(allL)))
def f(i):
    while parent[i]!=i: parent[i]=parent[parent[i]]; i=parent[i]
    return i
for i in range(len(allL)):
    for j in range(i):
        if set(allL[i])&set(allL[j]): parent[f(i)]=f(j)
comps={}
for i,l in enumerate(allL): comps.setdefault(f(i),[]).append(l)
for c in comps.values():
    rem=[l for l in c if l in R]; add=[l for l in c if l in A]
    common=set.intersection(*[set(l) for l in c])
    print(' component: removed',rem,'added',add,'common point(s):',sorted(common) or 'none -> not a single star move')
