"""Exakter Zensus der Stern-Neupaarungen: an Punkt p die 7 Linien durch p neu paaren.
Gültig genau dann, wenn jedes neue Paar (x,y) in N(p) keinen gemeinsamen Nachbarn außerhalb N[p] hat.
Umfasst Pivot (Transposition) und Dreierzyklus als Spezialfälle."""
import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')

import json,sys,time,collections
exec(open('lines.py').read().split('F={f')[0])
def tobits(rows): return [sum(1<<j for j in r) for r in rows]
def score_bits(B):
    W=L1=0
    for v in range(99):
        bv=B[v]
        for u in range(v):
            r=(B[u]&bv).bit_count()+((bv>>u)&1)-2
            if r: W+=1; L1+=abs(r)
    return W,L1
def pair_contrib(B,S):
    """W,L1 über alle Paare mit mindestens einem Endpunkt in S"""
    W=L1=0; Sset=set(S)
    for x in S:
        bx=B[x]
        for z in range(99):
            if z==x or (z in Sset and z<x): continue
            r=(bx&B[z]).bit_count()+((bx>>z)&1)-2
            if r: W+=1; L1+=abs(r)
    return W,L1
def census(rows, want_all=False):
    B=tobits(rows); base=score_bits(B)
    best=None; nvalid=0; nimpr=0; sideways=0; per_p=[]
    for p in range(99):
        N=sorted(rows[p]); Np=B[p]|(1<<p)
        partner={x:next(iter(rows[x]&rows[p])) for x in N}
        comp={x:set() for x in N}
        for i,x in enumerate(N):
            for y in N[i+1:]:
                if y==partner[x] or ((B[x]&B[y])&~Np)==0 and not (B[x]>>y)&1:
                    comp[x].add(y); comp[y].add(x)
        # enumerate perfect matchings of comp
        mats=[]
        def rec(left,cur):
            if not left: mats.append(list(cur)); return
            x=left[0]
            for y in comp[x]:
                if y in left:
                    cur.append((x,y)); rec([z for z in left if z!=x and z!=y],cur); cur.pop()
        rec(N,[])
        cnt=0
        W0,L0=pair_contrib(B,N)
        for m in mats:
            if all(partner[x]==y for x,y in m): continue
            cnt+=1
            B2=B[:]
            for x in N:
                B2[x]&=~(1<<partner[x])
            for x,y in m:
                B2[x]|=1<<y; B2[y]|=1<<x
            W1,L1=pair_contrib(B2,N)
            nw=(base[0]-W0+W1, base[1]-L0+L1)
            if nw<base: nimpr+=1
            if nw[0]==base[0]: sideways+=1
            if best is None or nw<best[0]: best=(nw,p,m)
        nvalid+=cnt; per_p.append(cnt)
    return base,nvalid,nimpr,sideways,best,per_p
if __name__=='__main__':
    import statistics as st
    pool=json.load(open(REPO+'/docs/memetik/lambda_repair_results_20260929/CANDIDATES_25.json'))
    items=pool if isinstance(pool,list) else pool.get('candidates',pool.get('classes'))
    out=[]
    for c in items:
        rows=g6(c['graph6']); t0=time.time()
        base,nv,ni,sw,best,pp=census(rows)
        rec={'state':c.get('state'),'id':c.get('id') or c.get('founder'),'base':base,'valid_moves':nv,'improving':ni,'same_W':sw,'best':best[0] if best else None,'best_p':best[1] if best else None,'moves_per_point_median':st.median(pp),'sec':round(time.time()-t0,1)}
        out.append(rec); print(json.dumps(rec),flush=True)
    json.dump(out,open('star_census.json','w'),indent=1)
