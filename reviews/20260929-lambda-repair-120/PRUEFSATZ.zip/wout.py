import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')
exec(open('lines.py').read().split('F={f')[0])
import statistics as st, collections
Fd={f['id']:f for f in M['founders']}
F={k:g6(f['graph6']) for k,f in Fd.items()}
def bad(rows,u,v): return len(rows[u]&rows[v])+(v in rows[u])-2!=0
out=collections.defaultdict(list)
for t in M['tasks']:
    rows=F[t['founder']]; S=set(t['vertices'])
    Wtot=Fd[t['founder']]['scores']['W']
    Wout=sum(1 for v in range(99) for u in range(v) if u not in S and v not in S and bad(rows,u,v))
    out[t['size']].append((Wout,Wtot-Wout,Wtot))
for s in sorted(out):
    L=out[s]; print(s,'W_out med',st.median(x[0] for x in L),'addressable bad pairs med',st.median(x[1] for x in L),'share %.2f'%st.median(x[1]/x[2] for x in L))
# the improvement
import json
r=json.load(open(RUN120+'/jobs/2077_08_s60_defect/result.json'))
new=g6(r['best']['graph6']); old=F['2077_08']
t=[t for t in M['tasks'] if t['id']=='2077_08_s60_defect'][0]; S=set(t['vertices'])
d=[(u,v) for v in range(99) for u in range(v) if (v in old[u])!=(v in new[u])]
V=sorted(set(x for e in d for x in e))
print('improvement: changed edges',len(d),'vertices touched',len(V),'all in window',set(V)<=S)
# lines changed
def lines(rows):
    L=set()
    for u in range(99):
        for v in rows[u]:
            if v>u: w=next(iter(rows[u]&rows[v])); L.add(tuple(sorted((u,v,w))))
    return L
Lo,Ln=lines(old),lines(new); print('lines removed',len(Lo-Ln),'added',len(Ln-Lo))
# is change-support connected in old graph?
import itertools
comp=[];seen=set()
for s0 in V:
    if s0 in seen: continue
    q=[s0];seen.add(s0);c=[s0]
    while q:
        x=q.pop()
        for y in (old[x]|new[x]):
            if y in V and y not in seen: seen.add(y);q.append(y);c.append(y)
    comp.append(len(c))
print('components of change support (old∪new adjacency):',comp)
# would the other windows of this founder contain the support?
for tt in M['tasks']:
    if tt['founder']=='2077_08': print(tt['id'], 'contains support:', set(V)<=set(tt['vertices']))
print('removed',sorted(Lo-Ln)); print('added',sorted(Ln-Lo)); print('edges', d, ['+' if (v in new[u]) else '-' for u,v in d])
