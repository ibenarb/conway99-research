import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')
import json,sys,itertools,collections,statistics as st
M=json.load(open(REPO+'/experiments/memetik/lambda_repair_1_2_0/MANIFEST.json'))
def g6(s):
    b=[ord(c)-63 for c in s]
    if b[0]==63: n=(b[1]<<12)|(b[2]<<6)|b[3]; body=b[4:]
    else: n=b[0]; body=b[1:]
    bits=[]
    for x in body:
        for i in range(5,-1,-1): bits.append((x>>i)&1)
    rows=[set() for _ in range(n)]; k=0
    for j in range(1,n):
        for i in range(j):
            if bits[k]: rows[i].add(j); rows[j].add(i)
            k+=1
    return rows
F={f['id']:g6(f['graph6']) for f in M['founders']}
def lines(rows):
    L=set()
    for u in range(99):
        for v in rows[u]:
            if v>u:
                c=rows[u]&rows[v]; assert len(c)==1
                w=next(iter(c)); L.add(tuple(sorted((u,v,w))))
    assert len(L)==231
    return L
LL={k:lines(r) for k,r in F.items()}
out=collections.defaultdict(list)
for t in M['tasks']:
    S=set(t['vertices']); rows=F[t['founder']]
    cnt=collections.Counter(len(S&set(l)) for l in LL[t['founder']])
    # per vertex: number of lines fully inside
    inner_per_v=[sum(1 for l in LL[t['founder']] if v in l and set(l)<=S) for v in S]
    out[(t['size'],t['rule'])].append((cnt[3],cnt[2],cnt[1],sum(1 for x in inner_per_v if x>=2),st.mean(inner_per_v)))
for k in sorted(out):
    v=out[k]
    print(k,'lines inside med',st.median(x[0] for x in v),'| 2-in-1-out med',st.median(x[1] for x in v),'| 1-in med',st.median(x[2] for x in v),'| vertices with >=2 inner lines med',st.median(x[3] for x in v),'| mean inner lines/vertex %.2f'%st.median(x[4] for x in v))
json.dump({k:[list(map(float,x)) for x in v] for k,v in [(f'{a}_{b}',v) for (a,b),v in out.items()]},open('lines_stats.json','w'))
