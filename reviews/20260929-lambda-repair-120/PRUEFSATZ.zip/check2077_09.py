import os
REPO=os.environ.get('REPO','/home/claude/repo')
RUN120=os.environ.get('RUN120','/home/claude/r120/ryzen_lambda_repair_120_20260928')
import json,sys
exec(open('star_descent.py').read().split("pool=json.load")[0])
sys.path.insert(0,REPO+'/experiments/memetik/lambda_repair_1_2_0')
import model as M0
Fd={f['id']:f for f in M['founders']}
rows=g6(Fd['2077_09']['graph6']); B=tobits(rows)
base,nv,ni,sw,best,pp=census(rows)
# the specific move at p=15
new=apply(rows,best[1],best[2]); assert lam_ok(new); print('move',best[0],'at p',best[1])
t=[t for t in M['tasks'] if t['id']=='2077_09_s60_defect'][0]; S=set(t['vertices'])
diff=[(u,v) for v in range(99) for u in range(v) if (v in rows[u])!=(v in new[u])]
print('changed edges',len(diff),'all inside window',all(u in S and v in S for u,v in diff))
# evaluate in the campaign model: fix hint to new graph and check feasibility+objective
m,edges,obj,mult,h=M0.build(rows,t['vertices'],hint_rows=new)
from ortools.sat.python import cp_model
for (u,v),x in edges.items():
    if not isinstance(x,int): m.add(x==int(v in new[u]))
s=cp_model.CpSolver(); s.parameters.num_workers=1; s.parameters.max_time_in_seconds=120
st=s.solve(m); print('campaign model with move fixed:',s.status_name(st),'objective',s.objective_value, '=> W',int(s.objective_value)//50000,'L1',int(s.objective_value)%50000)
r=json.load(open(RUN120+'/jobs/2077_09_s60_defect/result.json'))
print('campaign result:',r['status'],r['best']['scores'],'bound W>=%.1f'%(r['bound']/50000))
