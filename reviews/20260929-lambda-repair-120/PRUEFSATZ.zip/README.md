# Prüfsatz zum Review λ-Reparatur 1.2.0 (29.09.2026)

Gehört zu `REVIEW_LAMBDA_REPAIR_120_20260929.md`. Nur lesende Nachrechnungen und kleine Mechanismustests;
keine Kampagne, keine Änderung an Eingangsdaten.

## Voraussetzungen

    export REPO=<Checkout von conway99-research auf 68001f9f5aae97a3550d6039dfe731e0dd394e18 (Zweig memetik)>
    export RUN120=<entpacktes docs/memetik/lambda_repair_results_20260929/RESULTS_120.tar.gz>/ryzen_lambda_repair_120_20260928
    pip install ortools==9.14.6206        # dieselbe Version wie im Lauf; Python 3.12

Alle Skripte im Verzeichnis dieses Prüfsatzes starten; einige laden Hilfsteile per `exec` aus Nachbarskripten
(graph6-Decoder und Manifest aus `lines.py`, Zensus aus `star.py`, Abstieg aus `star_descent.py`).

## Aufrufe

    python3 lines.py                     # Linienstruktur je Fenster        -> lines_stats.json
    python3 alt.py 24 60                 # andere zulässige Füllung? (24)   -> alt_24.json
    python3 alt.py 40 120                # dasselbe für 40                   -> alt_40.json
    python3 wout.py                      # adressierbarer W-Anteil; Verbesserung 2139->2127
    python3 star.py                      # Sternzensus der 25 Poolklassen    -> star_census.json
    python3 star_descent.py              # steilster Sternabstieg            -> star_descent.json, star_descent_endpoints.json
    python3 star_d2.py                   # Tiefe 2 an den Rekordklassen
    python3 contain.py                   # verbessernde Sternzüge der Gründer, Lage in Kampagnenfenstern
    python3 check2077_09.py              # verfehlte Verbesserung 2170->2155 im Kampagnenmodell zulässig?
    python3 localbranch.py 2077_09_s60_defect 8 120 ballnolp    # Kugeltest; MODE: ball | ballnolp | nolp | lns
    python3 decompose.py 2077_09 best_2077_09_s60_defect_ballnolp_r16.json
    python3 seqcheck.py                  # 2140 als Folge gültiger Sternzüge

Die Protokolle `*.log` und die Ergebnisdateien `*.json` sind die Ausgaben der Sandboxläufe vom 29.09.2026.

## Hinweise zu einzelnen Dateien

- `lb_2077_09_r8_lp.json` und `lb_2077_09_full_nolp.json` stammen aus einer früheren Fassung von
  `localbranch.py` ohne Lösungsprotokoll; Status, Ziel und Konfliktzahl sind unverändert gültig.
- `best_*.json` sind Adjazenzlisten (0-basiert). `best_2077_09_s60_defect_ballnolp_r16.json` hat
  (W,L1)=(2140,2540); `best_2076_01_s60_defect_ballnolp_r16.json` ist der unveränderte Gründer.
- `star_descent_endpoints.json` enthält Start, Endpunkt und graph6 aller 25 Sternabstiege; der
  graph6-Rundlauf wird beim Schreiben per assert geprüft. Keiner der Endpunkte ist ein Rekord.

## Sternzug-Kriterium

Ersetzt man an Punkt p das perfekte Matching der 14 Nachbarn (die 7 Linien durch p) durch ein anderes
perfektes Matching, bleiben Grad 14 und λ=1 genau dann erhalten, wenn jedes neue Paar {x,y} bisher
nicht benachbart ist und x,y keinen gemeinsamen Nachbarn außerhalb von N[p] haben. `star_descent.py`
prüft jeden angewandten Zug zusätzlich mit einer vollständigen λ-Prüfung.

## Grenzen

- CP-SAT-Meldungen (OPTIMAL, INFEASIBLE, FEASIBLE) sind unzertifiziert; UNKNOWN bzw. Zeitgrenzen sind kein Ausschluss.
- Kugeltests: Einzelläufe mit Standardseed auf einem Sandbox-Kern (4 GB RAM); keine Rate, keine Ryzen-Laufzeit.
- Der Sternzensus ist eine deterministische exakte Aufzählung ohne unabhängige Zweitimplementierung.
- Neue Sandbox-Graphen sind nicht kanonisiert (kein pynauty); keine Klassenbehauptung.
- Nicht geprüft: RUN110-Rohdaten, FILE_INDEX.json, SOURCE_SHA256SUMS.txt, Ledger-/Receiptsummen.
