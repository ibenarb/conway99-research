import json,sys,time
from pathlib import Path
from common import *
task=read(sys.argv[1]);directory=Path(sys.argv[2]);target=float(sys.argv[-1])
if task['family']=='A':
    if 'invalid'=='invalid':
        atomic(directory/'best.json',{'graph6':'?', 'scores':{}, 'state':'broken'})
    raise SystemExit(7)
while cpu()<target:
    sum(i*i for i in range(10000))
atomic(directory/'result.json',{'status':'UNKNOWN_CPU_OR_PAUSE','process_cpu_seconds':cpu()})
