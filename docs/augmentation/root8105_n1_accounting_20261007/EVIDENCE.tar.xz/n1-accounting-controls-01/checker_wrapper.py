#!/workspace/scratch/50ce84c85079/venvs/memetik-audit/bin/python
import pathlib,subprocess,sys,time
p=subprocess.run(['/workspace/scratch/50ce84c85079/runtime-build/drat-trim']+sys.argv[1:])
pathlib.Path('READY_CHECK').touch()
while not (pathlib.Path.cwd().parents[1]/'RELEASE').exists():
    sum(i*i for i in range(10000))
sys.exit(p.returncode)
