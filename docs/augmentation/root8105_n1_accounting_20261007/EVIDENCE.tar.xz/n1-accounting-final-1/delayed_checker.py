#!/workspace/scratch/50ce84c85079/venvs/memetik-audit/bin/python
import pathlib,subprocess,sys,time
p=subprocess.run(['/workspace/scratch/50ce84c85079/runtime-build/drat-trim']+sys.argv[1:],stdout=subprocess.PIPE)
sys.stdout.buffer.write(p.stdout); sys.stdout.flush()
pathlib.Path('VERIFIED_BUT_RUNNING').touch()
while not (pathlib.Path.cwd().parents[1]/'RELEASE_CHECKER').exists():
    sum(i*i for i in range(5000))
sys.exit(p.returncode)
