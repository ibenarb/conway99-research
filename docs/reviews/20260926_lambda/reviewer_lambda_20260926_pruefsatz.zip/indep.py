"""Independent core: graph6 decode, residuals, scores, λ-check, 4-cycle identity, distance, nauty cert."""
import hashlib
def decode(g6):
    v=[ord(c)-63 for c in g6]; n=(v[1]<<12)|(v[2]<<6)|v[3] if v[0]==63 else v[0]
    off=4 if v[0]==63 else 1
    bits=[(x>>k)&1 for x in v[off:] for k in range(5,-1,-1)]
    rows=[0]*n; t=0
    for j in range(1,n):
        for i in range(j):
            if bits[t]: rows[i]|=1<<j; rows[j]|=1<<i
            t+=1
    return rows
def residuals(rows):
    n=len(rows); out={}
    for u in range(n):
        for v in range(u+1,n):
            e=(rows[u]>>v)&1; c=(rows[u]&rows[v]).bit_count()
            out[(u,v)]=c+e-2
    return out
def lam_ok(rows):
    n=len(rows)
    if n!=99 or any(r.bit_count()!=14 for r in rows): return False
    return all((rows[u]&rows[v]).bit_count()==1 for u in range(n) for v in range(u+1,n) if (rows[u]>>v)&1)
def scores(rows):
    r=residuals(rows).values(); m=max(abs(x) for x in r)
    return dict(W=sum(x!=0 for x in r),L1=sum(abs(x) for x in r),F=sum(x*x for x in r),Linf=m,Nmax=sum(abs(x)==m for x in r))
def four_cycles(rows):
    n=len(rows); s=0
    for u in range(n):
        for v in range(u+1,n):
            c=(rows[u]&rows[v]).bit_count(); s+=c*(c-1)//2
    return s//2
def hist(rows):
    h={}
    for (u,v),x in residuals(rows).items():
        if not (rows[u]>>v)&1: h[x]=h.get(x,0)+1
    return dict(sorted(h.items()))
def dist(a,b): return sum((x^y).bit_count() for x,y in zip(a,b))//2
def cert(rows):
    import pynauty
    n=len(rows); g=pynauty.Graph(n,adjacency_dict={u:[v for v in range(n) if (rows[u]>>v)&1] for u in range(n)})
    return hashlib.sha256(pynauty.certificate(g)).hexdigest()[:16]
