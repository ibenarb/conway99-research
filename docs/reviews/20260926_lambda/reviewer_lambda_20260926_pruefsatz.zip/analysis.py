"""Reviewer analysis of the flat λ review ZIP (26.09.2026). Usage: python3 analysis.py <dir-with-extracted-zip>
Independent of project code except pynauty for certificates."""
import sys, json, glob, statistics as st
from indep import decode, scores, lam_ok, four_cycles, hist, dist, cert
D=sys.argv[1]; out={}
R={}
for f in sorted(glob.glob(f'{D}/[DFO]__runs__comparison*result.json')):
    n=f.split('/')[-1]; R[n[0]+':'+n.split('__')[-2]]=json.load(open(f))
# 1 endpoints: scores, lambda, 4-cycle identity, histogram, certificate vs class field
ends={}
for j,r in R.items():
    b=r['best']; g=decode(b['graph6']); s=scores(g); Q=four_cycles(g); c=cert(g)
    ends[j]={'scores':s,'scores_match':s==b['scores'],'lambda':lam_ok(g),'Q':Q,'F_eq_4(Q-2079)':s['F']==4*(Q-2079),
             'residual_hist_nonedges':hist(g),'L1_minus_W':s['L1']-s['W'],'cert16':c,'class_match':b['class'].startswith(c)}
out['endpoints']=ends
# 2 labelled distances between distinct endpoint graphs
uniq={}
for j,r in R.items(): uniq.setdefault(r['best']['graph6'],(r['best']['scores']['W'],j))
lab=sorted(uniq.items(),key=lambda x:x[1][0]); G=[decode(g) for g,_ in lab]
out['distance_matrix']={'labels':[f"W{w}:{j}" for _,(w,j) in lab],'edges':[[dist(a,b) for b in G] for a in G]}
# 3 W-event bursts (W improvements >60 s apart) and dwell
def bursts(curve,lo=0,hi=1e9):
    t=[c['cpu'] for i,c in enumerate(curve) if i and c['scores']['W']<curve[i-1]['scores']['W']]
    b=[];last=None
    for x in t:
        if last is None or x-last>60: b.append(x)
        last=x
    return [x for x in b if lo<=x<hi]
rates={}
for stage,sel,lo,hi,h in (('D_V2','D:V2',0,1e9,2),('F','F:',0,1e9,4),('O_0-4h','O:',0,14400,4),('O_4-7h','O:',14400,1e9,3),('O','O:',0,1e9,7)):
    js=[j for j in R if j.startswith(sel)]; n=sum(len(bursts(R[j]['curves'],lo,hi)) for j in js)
    rates[stage]={'jobs':len(js),'bursts':n,'cpu_h':len(js)*h,'per_cpu_h':round(n/(len(js)*h),3)}
out['W_event_rates']=rates
out['last_W_event_h']={j:round(max([c['cpu'] for i,c in enumerate(r['curves']) if i and c['scores']['W']<r['curves'][i-1]['scores']['W']] or [0])/3600,2) for j,r in R.items()}
# 4 heuristic lineage: nearest founder by labelled distance
lin={}
for p,banks in (('F',{'2096':'F-W2096','2101':'F-W2101'}),('O',{'2081':'F-W2081','2092':'F-W2092'})):
    B=json.load(open(f'{D}/{p}__FRONTIER_BANKS.json'))
    for bk,pref in banks.items():
        fd=[(decode(x['graph6']),x['scores']['W']) for x in B[bk]['population']]
        lin[f'{p}:{bk}']={'founder_W':[w for _,w in fd],'founder_dist_to_best':[dist(fd[0][0],g) for g,_ in fd],'jobs':{}}
        for j,r in R.items():
            if not (j.startswith(p+':'+pref)): continue
            pts=[]
            for c in r['curves']:
                g=decode(c['graph6']); ds=[dist(g,x) for x,_ in fd]; i=min(range(len(ds)),key=ds.__getitem__)
                pts.append({'W':c['scores']['W'],'L1':c['scores']['L1'],'h':round(c['cpu']/3600,2),'nearest_founder':i,'founder_W':fd[i][1],'d':ds[i],'d_best':ds[0]})
            lin[f'{p}:{bk}']['jobs'][j]=pts
out['lineage_heuristic']=lin
# 5 final population diversity
out['final_population']={j:{'W_min':min(p['scores']['W'] for p in r['final_population']),
    'W_median':st.median(p['scores']['W'] for p in r['final_population']),
    'mean_pair_dist':round(st.mean(dist(decode(a['graph6']),decode(b['graph6'])) for k,a in enumerate(r['final_population']) for b in r['final_population'][k+1:]),1)}
    for j,r in R.items()}
json.dump(out,open('analysis_result.json','w'),indent=1)
print(json.dumps({'all_scores_match':all(e['scores_match'] for e in ends.values()),'all_lambda':all(e['lambda'] for e in ends.values()),
  'identity_all':all(e['F_eq_4(Q-2079)'] for e in ends.values()),'class_match_all':all(e['class_match'] for e in ends.values()),
  'endpoints':len(ends),'distinct':len(uniq),'rates':rates},indent=1))
