# Reviewer-Prüfsatz λ, 26.09.2026 (flaches ZIP)

Zu `REVIEW_LAMBDA_20260926.md`. Ausgeführt mit Python 3.12 und pynauty 2.8.8.1 auf einem Kern,
nicht auf dem Ryzen. Gesamtaufwand etwa 1 CPU-h. Kein Suchlauf.

## Unabhängiger Kern (kein Projektcode)
- `indep.py`     graph6-Decoder, Residuen, Scores, λ-Prüfung, 4-Kreise Q, Residuenhistogramm,
                 beschrifteter Kantenabstand, pynauty-Zertifikat.
- `analysis.py`  Endpunkte (Scores, λ, F = 4(Q−2079), Klassen), Abstandsmatrix, W-Ereignisraten,
                 heuristische Herkunft (nächster Gründer), Populationsvielfalt -> analysis_result.json

## Mit eingefrorenem Katalog (lambda_compare_0_2_0 aus a4d4396, Apex ∪ Pivot)
- `depth2.py`    Tiefe-2-Zensus (W,L1) an 7 Endgraphen                 -> depth2_result.json
- `depth3.py`    Tiefe-3-Zensus mit Checkpoint, Tiefe-2-Zustände dedupliziert
                                                                        -> d3_2076.json, d3_2077.json
- `mitm.py`      Zugabstand bis 4 (Meet-in-the-middle)                  -> mitm_result.json
- `spec.json`    Eingabe für depth2.py

## Aufruf
    LR=<Verzeichnis mit entpacktem Lambda_Review_20260926.zip>
    REPO=<conway99-research auf a4d43966b7c09fac3e0e4bc87228280244cfc555>
In `depth2.py`, `depth3.py` und `mitm.py` sind die Pfade `/home/claude/repo` und `/home/claude/lr`
fest eingetragen und entsprechend anzupassen.

    python3 analysis.py $LR
    python3 depth2.py spec.json depth2_result.json
    python3 depth3.py 2076 <cpu_s_je_Aufruf>   # so oft wiederholen, bis done == n_L2
    python3 depth3.py 2077 <cpu_s_je_Aufruf>
    python3 mitm.py 2079-2076 2081-2079 2096-2081

## Grenzen
- Isomorphie ist nur für die 22 Endpunkte (12 Graphen) unabhängig geprüft.
- Keine SQLite-, Ledger- oder vollständige Receipt-Prüfung.
- Die Herkunftsanalyse ist heuristisch: nächster Gründer nach beschriftetem Abstand, keine Elternkette.
- Der Tiefe-3-Zensus deckt genau alle Folgen aus höchstens 3 Zügen ab (Tiefe 1 und 2 separat in depth2).
- Die W-Ereignisse sind Schübe mit mehr als 60 s Abstand aus den gespeicherten Bestwertkurven.
