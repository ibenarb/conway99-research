"""Meet-in-the-middle move distance (Apex∪Pivot, both involutive-closed) between two labelled graphs, up to 4."""
import sys, json, time, glob
sys.path.insert(0,'/home/claude/repo/experiments/memetik/lambda_compare_0_2_0')
import bootstrap  # noqa
from kernel import catalogue
from common import core
class G:
    def check(self): pass
def layers(g6):
    r0=tuple(core.decode_g6(g6)); L0={r0}; L1=set(); L2=set()
    for _,m in catalogue(r0,False,G()): L1.add(tuple(core.apply_move(r0,m)))
    for r1 in L1:
        for _,m in catalogue(r1,False,G()): L2.add(tuple(core.apply_move(r1,m)))
    return [L0,L1,L2-L1-L0]
def mdist(a,b):
    A=layers(a); B=layers(b)
    for d in range(5):
        for i in range(3):
            j=d-i
            if 0<=j<3 and A[i]&B[j]: return d
    return '>4'
if __name__=='__main__':
    E={}
    lr='/home/claude/lr'
    for f in glob.glob(lr+'/[DFO]__runs__comparison*result.json'):
        r=json.load(open(f)); E[r['best']['scores']['W']]=r['best']['graph6']
    res=[]
    for a,b in [tuple(map(int,x.split('-'))) for x in sys.argv[1:]]:
        t=time.process_time(); d=mdist(E[a],E[b]); res.append({'from':a,'to':b,'move_distance':d,'cpu_s':round(time.process_time()-t)})
        print(res[-1],flush=True)
    json.dump(res,open('mitm_result.json','w'),indent=1)
