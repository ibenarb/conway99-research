"""Depth-2 census under the frozen Apex∪Pivot catalogue (lambda_compare_0_2_0 at a4d4396).
Counts all 2-move sequences, (W,L1)-improving states, and whether given target graphs are hit."""
import sys, json, time
FROZEN='/home/claude/repo/experiments/memetik/lambda_compare_0_2_0'
sys.path.insert(0, FROZEN)
import bootstrap  # noqa
from kernel import catalogue, Scorer
from common import core
sys.path.insert(0,'/home/claude/rv'); from indep import decode, scores as iscores, lam_ok
class G:
    def check(self): pass
def key(s): return (s['W'], s['L1'])
def census(name, g6, targets, cycles=False):
    t=time.process_time(); rows=tuple(core.decode_g6(g6)); base=Scorer(rows).scores
    assert rows==tuple(decode(g6))
    sc=Scorer(rows); lvl1=[(n,m,*sc.evaluate(m)) for n,m in catalogue(rows,cycles,G())]
    tgt={tuple(decode(x)):lab for lab,x in targets.items()}
    hits={}; d1=0; d2=set(); n2=0; best=None
    for n1,m1,ch1,s1 in lvl1:
        if key(s1)<key(base): d1+=1
        if tuple(ch1) in tgt: hits[tgt[tuple(ch1)]]=1
        sc2=Scorer(ch1)
        for n2name,m2 in catalogue(ch1,cycles,G()):
            ch2,s2=sc2.evaluate(m2); n2+=1
            tc=tuple(ch2)
            if tc in tgt: hits.setdefault(tgt[tc],2)
            if tc!=rows and key(s2)<key(base):
                d2.add(tc)
                if best is None or key(s2)<key(best[0]): best=(s2,n1,n2name,tc)
    res={'graph':name,'base':base,'depth1_moves':len(lvl1),'depth1_by_type':{k:sum(1 for x in lvl1 if x[0]==k) for k in ('apex','pivot','cycle3')},
         'depth1_improving':d1,'depth2_sequences':n2,'depth2_distinct_improving':len(d2),'target_hits':hits,
         'cpu_s':round(time.process_time()-t,1)}
    if best:
        r=list(best[3]); res['best_depth2']=best[0]; res['best_via']=[best[1],best[2]]
        res['best_indep_valid']=lam_ok(r); res['best_indep_scores_match']=iscores(r)=={k:best[0][k] for k in iscores(r)}
        res['best_graph6']=core.encode_g6(best[3])
    return res
if __name__=='__main__':
    spec=json.load(open(sys.argv[1])); out=[]
    for c in spec:
        r=census(c['name'],c['g6'],c.get('targets',{}),c.get('cycles',False)); out.append(r)
        print(json.dumps({k:v for k,v in r.items() if k!='best_graph6'}),flush=True)
    json.dump(out,open(sys.argv[2],'w'),indent=1)
