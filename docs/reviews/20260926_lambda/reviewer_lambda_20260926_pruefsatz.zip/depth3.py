"""Exhaustive depth-3 (W,L1) census under frozen Apex∪Pivot, chunked with checkpoint.
Level-2 states are deduplicated; every child of every distinct level-1/2 state is evaluated exactly."""
import sys, json, time, os, glob
sys.path.insert(0,'/home/claude/repo/experiments/memetik/lambda_compare_0_2_0')
import bootstrap  # noqa
from kernel import catalogue, Scorer
from common import core
class G:
    def check(self): pass
key=lambda s:(s['W'],s['L1'])
W=int(sys.argv[1]); budget=float(sys.argv[2])
E={}
for f in glob.glob('/home/claude/lr/[DFO]__runs__comparison*result.json'):
    r=json.load(open(f)); E[r['best']['scores']['W']]=r['best']['graph6']
ck=f'/home/claude/rv/d3_{W}.json'
r0=tuple(core.decode_g6(E[W])); base=Scorer(r0).scores
if os.path.exists(ck): st=json.load(open(ck))
else:
    L1=sorted({tuple(core.apply_move(r0,m)) for _,m in catalogue(r0,False,G())})
    L2=set()
    for r1 in L1:
        for _,m in catalogue(r1,False,G()): L2.add(tuple(core.apply_move(r1,m)))
    L2=sorted(L2-set(L1)-{r0})
    st={'W':W,'base':base,'n_L1':len(L1),'n_L2':len(L2),'done':0,'children':0,'improving':[],'best':None}
    json.dump([list(x) for x in L2],open(f'/home/claude/rv/d3_{W}_L2.json','w'))
    json.dump(st,open(ck,'w'))
L2=[tuple(x) for x in json.load(open(f'/home/claude/rv/d3_{W}_L2.json'))]
t=time.process_time()
while st['done']<len(L2) and time.process_time()-t<budget:
    r2=L2[st['done']]; sc=Scorer(r2)
    for _,m in catalogue(r2,False,G()):
        ch,s=sc.evaluate(m); st['children']+=1
        if key(s)<key(base):
            g=core.encode_g6(ch)
            st['improving'].append([s,g])
            if st['best'] is None or key(s)<key(st['best'][0]): st['best']=[s,g]
    st['done']+=1
json.dump(st,open(ck,'w'))
print(json.dumps({k:(v if k!='improving' else len(v)) for k,v in st.items() if k!='best'}), 'best', st['best'][0] if st['best'] else None)
