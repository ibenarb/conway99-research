"""Startabhaengigkeit: strikter (W,L1)-Bestabstieg im TC-Katalog (Projekt-kernel, b659cb8) ab JEDEM der 16 Gruender.
Gleichstandsmengen werden protokolliert; bei Gleichstand erste Wahl (Generatorreihenfolge)."""
import sys, json, time
FROZEN, MAXSTEPS = sys.argv[1], int(sys.argv[2])
sys.path.insert(0, FROZEN)
import bootstrap  # noqa
from kernel import catalogue, Scorer
from common import core
from search import key
class G:
    def check(self): pass
out = []
for f in json.load(open(f'{FROZEN}/founders.json')):
    rows = tuple(core.decode_g6(f['graph6'])); cur = Scorer(rows).scores; steps = 0; maxtie = 0; t = time.process_time(); ops = {}
    while steps < MAXSTEPS:
        sc = Scorer(rows); best = None; ties = 0
        for n, m in catalogue(rows, True, G()):
            ch, s = sc.evaluate(m)
            if key(s, 'W') < key(cur, 'W'):
                if best is None or key(s, 'W') < key(best[2], 'W'): best, ties = (n, ch, s), 1
                elif key(s, 'W') == key(best[2], 'W'): ties += 1
        if best is None: break
        rows, cur = best[1], best[2]; steps += 1; maxtie = max(maxtie, ties); ops[best[0]] = ops.get(best[0], 0) + 1
    out.append({'line': f['line'], 'family': f['family'], 'start': (f['scores']['W'], f['scores']['L1']), 'end': (cur['W'], cur['L1']),
                'steps': steps, 'local_min_reached': steps < MAXSTEPS, 'max_tie_set': maxtie, 'operators': ops, 'cpu_s': round(time.process_time() - t, 1)})
    print(out[-1], flush=True)
json.dump(out, open('probe_founders_result.json', 'w'), indent=1)
