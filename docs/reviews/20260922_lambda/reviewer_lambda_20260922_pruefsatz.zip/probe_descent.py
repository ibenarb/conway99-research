"""Determinismus-Sonde fuer T/TC (nutzt eingefrorenen Projektcode b659cb8 kernel.catalogue/Scorer):
Bestabstieg im aktiven Ziel ab dem von begin_path() gewaehlten Gruender (min key),
Protokoll der Gleichstandsmenge beim besten zulaessigen Schluessel in jedem Schritt.
Bei Gleichstandsmenge 1 ist der Schritt von Seed und Tabu-Tenure unabhaengig
(solange keine Tabusperre wirkt: im reinen Abstieg wird nur Aspiration/Verbesserung genutzt).
Zusaetzlich: Katalog-/Verbesserungsbilanz inkl. cycle3 am W=2121-Zeugen."""
import sys, json, time
FROZEN = sys.argv[1]; DATA = sys.argv[2]
sys.path.insert(0, FROZEN)
import bootstrap  # noqa
from kernel import catalogue, Scorer
from common import core
from search import key

class G:
    def check(self): pass

def probe(rows, include_cycles, target, max_steps=100):
    rows = tuple(rows); cur = Scorer(rows).scores; log = []
    for step in range(max_steps):
        sc = Scorer(rows); items = []
        for name, move in catalogue(rows, include_cycles, G()):
            child, s = sc.evaluate(move); items.append((key(s, target), name, move, child, s))
        better = [i for i in items if i[0] < key(cur, target)]
        if not better:
            return log, cur, len(items)
        b = min(i[0] for i in better); ties = [i for i in better if i[0] == b]
        log.append({'step': step + 1, 'catalogue': len(items), 'improving': len(better), 'tie_set': len(ties),
                    'operator': ties[0][1], 'scores': ties[0][4]})
        rows, cur = ties[0][3], ties[0][4]
        if len(ties) > 1:
            log[-1]['note'] = 'seed-dependent branch point'
    return log, cur, None

founders = json.load(open(f'{FROZEN}/founders.json'))
out = {}
for target in ('W', 'L1'):
    f = min(founders, key=lambda p: key(p['scores'], target))
    for variant, cyc in (('T', False), ('TC', True)):
        t = time.process_time()
        log, end, cat = probe(core.decode_g6(f['graph6']), cyc, target)
        out[f'{variant}/{target}'] = {'founder_line': f['line'], 'founder_scores': f['scores'], 'steps': log,
                                      'local_min_scores': end, 'catalogue_at_min': cat,
                                      'max_tie_set': max([s['tie_set'] for s in log], default=0), 'cpu_s': time.process_time() - t}
        print(variant, target, f['line'], f['scores'], '->', end, 'steps', len(log), 'max tie', out[f'{variant}/{target}']['max_tie_set'],
              'cpu', round(time.process_time() - t, 1), flush=True)
C = json.load(open(f'{DATA}/RECORD_CENSUS.json'))
w = C['observed_W']['improving_witnesses']['W']['graph6']
rows = core.decode_g6(w); sc = Scorer(rows); base = sc.scores; cnt = {}; imp = {}
for name, move in catalogue(rows, True, G()):
    _, s = sc.evaluate(move); cnt[name] = cnt.get(name, 0) + 1
    if key(s, 'W') < key(base, 'W'): imp[name] = imp.get(name, 0) + 1
out['witness_2121_full_catalogue'] = {'scores': base, 'moves': cnt, 'W_L1_improving': imp}
print('2121 witness', base, cnt, imp)
json.dump(out, open('probe_descent_result.json', 'w'), indent=1)
