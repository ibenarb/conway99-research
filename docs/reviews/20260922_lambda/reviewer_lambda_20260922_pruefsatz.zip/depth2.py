"""Tiefe-2-Zensus (Projekt-kernel b659cb8, vollstaendiger Apex∪Pivot∪Dreierzyklus):
zaehlt Zwei-Zug-Folgen, die den Zielschluessel strikt verbessern, obwohl Tiefe 1 keine Verbesserung hat.
Nur Diagnose; Zweitzug-Kandidaten werden mit dem unabhaengigen Verifier (indep.py) geprueft."""
import sys, json, time
FROZEN, DATA = sys.argv[1], sys.argv[2]
sys.path.insert(0, FROZEN)
import bootstrap  # noqa
from kernel import catalogue, Scorer
from common import core
from search import key
from indep import decode_g6, scores as iscores, lambda_valid
class G:
    def check(self): pass
C = json.load(open(f'{DATA}/RECORD_CENSUS.json'))
cases = [('HoG_F2836', C['observed_F']['graph6'], 'F'), ('W2121_witness', C['observed_W']['improving_witnesses']['W']['graph6'], 'W'),
         ('W2130_activeP', C['active_W']['graph6'], 'W'), ('W2141_TC', C['TC_W']['graph6'], 'W')]
res = {}
for name, g6, tgt in cases:
    t = time.process_time(); rows = tuple(core.decode_g6(g6)); base = Scorer(rows).scores
    sc = Scorer(rows); lvl1 = [(n, m, *sc.evaluate(m)) for n, m in catalogue(rows, True, G())]
    d1 = sum(key(s, tgt) < key(base, tgt) for *_, s in lvl1)
    d2 = 0; best = None; seen = set(); n2 = 0; bestpair = None
    for n1, m1, ch1, s1 in lvl1:
        sc2 = Scorer(ch1)
        for n2name, m2 in catalogue(ch1, True, G()):
            ch2, s2 = sc2.evaluate(m2); n2 += 1
            if ch2 == rows: continue
            if key(s2, tgt) < key(base, tgt):
                h = core.encode_g6(ch2)
                if h in seen: continue
                seen.add(h); d2 += 1
                if best is None or key(s2, tgt) < key(best, tgt): best, bestpair, bestg6 = s2, (n1, n2name, s1), h
    entry = {'target': tgt, 'base': base, 'depth1_moves': len(lvl1), 'depth1_improving': d1, 'depth2_sequences': n2,
             'depth2_distinct_improving_states': d2, 'best_depth2': best, 'best_depth2_via': bestpair, 'cpu_s': round(time.process_time() - t, 1)}
    if best is not None:
        adj = decode_g6(bestg6); ok, why = lambda_valid(adj); entry['best_depth2_independent_valid'] = ok
        entry['best_depth2_independent_scores_match'] = iscores(adj) == {k: best[k] for k in iscores(adj)}; entry['best_depth2_graph6'] = bestg6
    res[name] = entry; print(name, {k: v for k, v in entry.items() if k != 'best_depth2_graph6'}, flush=True)
json.dump(res, open('depth2_result.json', 'w'), indent=1)
