import json, sys, time
from indep import decode_g6
from neigh import census
C = json.load(open(sys.argv[1]))
res = {}
for name, v in C.items():
    t = time.process_time()
    base, out = census(decode_g6(v['graph6']))
    agree = {op: (out[op]['moves'] == v['catalogue'][op]['moves'] and out[op]['improving'] == v['catalogue'][op]['improving']) for op in ('apex', 'pivot')}
    res[name] = {'scores': base, 'mine': {op: {'moves': out[op]['moves'], 'improving': out[op]['improving'], 'best': {t: out[op]['best'][t][0] for t in out[op]['best']}} for op in out},
                 'project_census': {op: v['catalogue'][op] for op in ('apex', 'pivot')}, 'agree_apex_pivot': agree, 'cpu_s': time.process_time() - t}
    print(name, base, {op: (out[op]['moves'], out[op]['improving']) for op in out}, agree, round(time.process_time() - t, 1), flush=True)
json.dump(res, open('census_indep_result.json', 'w'), indent=1)
