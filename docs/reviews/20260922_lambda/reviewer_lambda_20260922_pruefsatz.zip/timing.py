"""Zeitkonsistenz: untere Schranke der Makespan aus wait4-CPU (Receipts) bei <=18 gleichzeitigen,
einthreadigen Workern, verglichen mit UTC- und monotoner Dauer aus SUMMARY.json."""
import json, sys, math
D = sys.argv[1]
R = json.load(open(f'{D}/RECEIPTS.json')); S = json.load(open(f'{D}/SUMMARY.json'))
cpu = sorted(v['cpu_seconds'] for k, v in R.items() if k != 'controls')
n, slots = len(cpu), 18
L = min(cpu)
# Lemma: bei <=s gleichzeitigen Jobs der Dauer >=L gilt S(t)<=s*(floor(t/L)+1) gestartete Jobs;
# alle n beendet => letzter Start >= (ceil(n/s)-1)*L => Makespan >= ceil(n/s)*L.
lb_wave = math.ceil(n / slots) * L
lb_area = sum(cpu) / slots
mono, utc = S['comparison_monotonic_seconds'], S['comparison_utc_elapsed_seconds']
out = {'jobs': n, 'min_job_cpu': L, 'sum_cpu_h': sum(cpu) / 3600,
       'lower_bound_waves_s': lb_wave, 'lower_bound_area_s': lb_area,
       'utc_s': utc, 'monotonic_s': mono,
       'utc_minus_lb': utc - lb_wave, 'monotonic_minus_lb': mono - lb_wave,
       'ratio_utc_over_monotonic': utc / mono,
       'implied_cpu_clock_factor_if_monotonic_true': lb_wave / mono,
       'interpretation': ('Monotone Dauer liegt UNTER der aus wait4-CPU zwingenden Makespan-Schranke; '
                          'wait4-CPU und UTC sind miteinander vertraeglich (Rest = Overhead). '
                          'Genau eine der Zeitbasen (CLOCK_MONOTONIC oder rusage/UTC) weicht ab; '
                          'Entscheidung nur mit unabhaengiger Hostzeit.')}
print(json.dumps(out, indent=1)); json.dump(out, open('timing_result.json', 'w'), indent=1)
