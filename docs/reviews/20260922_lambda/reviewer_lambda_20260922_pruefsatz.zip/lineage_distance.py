"""Beschriftete Kantenabstaende (|E1 Δ E2|/2 = Anzahl ausgetauschter Kanten) zwischen Gruendern und Rekorden.
Suchzuege behalten die Knotenbeschriftung; kleiner Abstand = gleiche Nachbarschaftsregion (obere Schranke fuer
Isomorphieabstand ist nicht behauptet; nur beschrifteter Abstand)."""
import json, sys
from indep import decode_g6
D, FR = sys.argv[1], sys.argv[2]
F = json.load(open(FR)); C = json.load(open(f'{D}/RECORD_CENSUS.json')); P = json.load(open('record_pool_preliminary.json'))
def edges(g6):
    adj = decode_g6(g6); return {(u, v) for u in range(99) for v in adj[u] if u < v}
pts = {f['line']: edges(f['graph6']) for f in F if f['family'] == 'HoG' or f['line'].startswith('endpoint')}
pts.update({'Z33:gen-lambda-13': edges(next(f for f in F if f['line'] == 'gen-lambda-13')['graph6'])})
for name in ('observed_W', 'active_W', 'TC_W', 'observed_L1', 'observed_Linf'):
    pts[f"{name}({C[name]['scores']['W']})"] = edges(C[name]['graph6'])
pts['witness2121'] = edges(C['observed_W']['improving_witnesses']['W']['graph6'])
names = list(pts); out = {}
print(' ' * 22 + ' '.join(f'{n[:9]:>9}' for n in names))
for a in names:
    row = [len(pts[a] ^ pts[b]) // 2 for b in names]; out[a] = dict(zip(names, row))
    print(f'{a[:22]:22}' + ' '.join(f'{x:9d}' for x in row))
json.dump(out, open('lineage_distance_result.json', 'w'), indent=1)
