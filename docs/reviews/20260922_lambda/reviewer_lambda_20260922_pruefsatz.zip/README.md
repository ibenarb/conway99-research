# Reviewer-Prüfsatz λ, 22.09.2026 (flaches ZIP)

Zum Dokument `REVIEWER_VORSCHLAG_lambda_20260922.md`. Alle Programme wurden in meiner
eigenen Umgebung ausgeführt (Python 3.12, pynauty 2.8.8.1), nicht auf Ryzen.
Gesamtaufwand ca. 1 CPU-Stunde. Kein Suchlauf, keine Änderung am Laufbundle.

## Unabhängiger Kern (kein Projektcode)

- `indep.py`      graph6-Decoder, Residuen, Scores, λ-Gültigkeit (n=99, Grad 14, CN=1 je Kante,
                  231 Dreiecke, 7 je Knoten), Zielschlüssel.
- `neigh.py`      Brute-Force Apex/Pivot nach Definition mit vollständiger lokaler λ-Prüfung.
- `check_all.py`  prüft alle veröffentlichten graph6 und alle Zensus-Zeugen  -> check_all_result.json,
                  witness_result.json
- `run_census.py` unabhängiger Nachbarschaftszensus gegen RECORD_CENSUS.json -> census_indep_result.json
- `descend.py`    strikter (W,L1)-Abstieg im unabhängigen Apex∪Pivot ab W=2121 -> descent_2121_result.json
- `paired.py`     Paarbilanzen/Messpunkte/Laufkennzahlen aus ENDPOINTS.json    -> paired_result.json
- `timing.py`     Makespan-Schranke vs. UTC und monotone Dauer                 -> timing_result.json
- `lineage_distance.py` beschriftete Kantenabstände                            -> lineage_distance_result.json
- `record_pool.py`      vorläufiger R-Gründerpool (pynauty-Zertifikate)        -> record_pool_preliminary.json
- `schedule.py`         Listen-Scheduling-Simulation                           -> schedule_result.json

## Sonden mit eingefrorenem Projektcode (b659cb8), Ergebnisse unabhängig nachgeprüft

- `probe_descent.py`  Bestabstieg im T-/TC-Katalog ab Startgründer     -> probe_descent_result.json
- `probe_tabu.py`     getreue Nachbildung von Engine.step_tabu         -> probe_tabu_*.json
                      (TC/W 12 Seeds × 40 It., T/W 12 Seeds × 60 It., Seed 0 je 250 It.)
- `probe_founders.py` Bestabstieg ab allen 16 Gründern                 -> probe_founders_result.json
- `depth2.py`         Tiefe-2-Zensus (F=2836, W=2121/2130/2141)        -> depth2_result.json
- `witness_2116.py`   Zwei-Schritt-Zeuge W=2116 mit expliziten Zügen   -> witness_2116_result.json

## Aufruf

    DATA=<Verzeichnis mit ENDPOINTS.json, SUMMARY.json, AUDIT.json, RECEIPTS.json, RECORD_CENSUS.json>
    FROZEN=<Pfad zu experiments/memetik/lambda_compare_0_2_0 aus b659cb8>

    python3 check_all.py $DATA
    python3 run_census.py $DATA/RECORD_CENSUS.json
    python3 paired.py $DATA
    python3 timing.py $DATA
    python3 lineage_distance.py $DATA $FROZEN/founders.json
    python3 record_pool.py $DATA
    python3 descend.py $DATA/RECORD_CENSUS.json
    python3 schedule.py
    python3 probe_descent.py  $FROZEN $DATA
    REPS=0,1,2 python3 probe_tabu.py $FROZEN $DATA TC W 40
    python3 probe_founders.py $FROZEN 80
    python3 depth2.py        $FROZEN $DATA
    python3 witness_2116.py  $FROZEN $DATA

`AUDIT.json` und `ENDPOINTS.json` sind die entpackten `.gz`-Dateien aus `84c46aa`.

## Grenzen

Das 287-MiB-Originalarchiv lag nicht vor. Keine Prüfung der 1.490.795 Archivzeilen,
keine Neuberechnung der Kanonisierungszertifikate des Laufs, keine Pfadreproduktion im
Worker. `probe_tabu.py` bildet nur die Entscheidungsregel nach (Katalog, Zulässigkeit,
Gleichstandswahl, Tenure) und trifft damit Bestwert und Iteration aller 12 TC-Seeds;
das ist keine Behauptung identischer echter Trajektorien.
