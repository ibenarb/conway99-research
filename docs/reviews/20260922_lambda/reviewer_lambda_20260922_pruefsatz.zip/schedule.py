"""Listen-Scheduling-Simulation fuer Stufe 1 (18 Slots, Jobs in Manifestreihenfolge), CPU-Dauern ohne Overhead.
Gibt Makespan, Slot-Auslastung und mittlere Gleichzeitigkeit je Arm aus (SMT-Lastvergleich)."""
import heapq, json, sys
def simulate(jobs, slots=18):
    t = 0.0; running = []; pending = list(jobs); log = []
    events = []
    while pending or running:
        while pending and len(running) < slots:
            name, arm, dur = pending.pop(0); heapq.heappush(running, (t + dur, name, arm, t))
        end, name, arm, start = heapq.heappop(running); log.append((name, arm, start, end)); t = end
    ms = max(e for *_, e in log)
    # mittlere Gleichzeitigkeit, die ein Arm waehrend seiner Laufzeit erlebt
    pts = sorted({s for *_, s, _ in log} | {e for *_, e in log})
    conc = {}
    for name, arm, s, e in log:
        acc = 0.0
        for a, b in zip(pts, pts[1:]):
            if a >= s and b <= e:
                acc += (b - a) * sum(1 for *_, s2, e2 in log if s2 <= a and e2 >= b)
        conc.setdefault(arm, []).append(acc / (e - s))
    return ms, sum(e - s for *_, s, e in log) / (slots * ms), {a: round(sum(v) / len(v), 2) for a, v in conc.items()}, log
H = 3600
base = []
for i in range(12):
    base += [(f'PC-{i:02d}', 'PC', 4 * H), (f'TE-{i:02d}', 'TE', 4 * H), (f'Pext-{i:02d}', 'Pext', 3 * H)]
variants = {
  'S1: nur Vergleich (Pext+PC+TE), verschraenkt': base,
  'S1 + R 6x4h am Ende': base + [(f'R-{i}', 'R', 4 * H) for i in range(6)],
  'S1 + R 6x4h vorne': [(f'R-{i}', 'R', 4 * H) for i in range(6)] + base,
  'Alternative A (Codex-Option): P+TC je 12x3h Fortsetzung': [x for i in range(12) for x in ((f'Pext-{i}', 'Pext', 3 * H), (f'TCext-{i}', 'TCext', 3 * H))],
}
out = {}
for k, jobs in variants.items():
    ms, util, conc, _ = simulate(jobs)
    cpu = sum(d for *_, d in jobs) / H
    out[k] = {'cpu_h': cpu, 'makespan_h': round(ms / H, 2), 'utilisation': round(util, 3), 'mean_concurrency_seen_by_arm': conc}
    print(k, out[k])
json.dump(out, open('schedule_result.json', 'w'), indent=1)
