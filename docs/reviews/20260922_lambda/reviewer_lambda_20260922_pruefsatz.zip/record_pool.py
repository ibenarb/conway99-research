"""Vorlaeufiger Gruenderpool fuer die Rekordfortsetzung R aus den in Git verfuegbaren Graphen:
192 aktive Endpunkte, 4 beobachtete Zielrekorde, 19 Nachdiagnose-Zeugen.
Unabhaengige Pruefung (indep.py) + kanonische Klasse (pynauty, gleiche Zertifikatsmethode wie core.canonical).
Auswahl: 16 kanonisch verschiedene Klassen, lexikographisch kleinste (W,L1), Gleichstand: graph6-SHA256.
Endgueltige Liste erst nach Ernte (D5) aus allen OBSERVED-Zeilen des Originalarchivs."""
import json, sys, hashlib, pynauty
from indep import decode_g6, scores, lambda_valid
D = sys.argv[1]
E = json.load(open(f'{D}/ENDPOINTS.json')); A = json.load(open(f'{D}/AUDIT.json')); C = json.load(open(f'{D}/RECORD_CENSUS.json'))
cands = []
for jid, v in E.items(): cands.append((v['best']['graph6'], 'active:' + jid, v['best'].get('family'), v['best'].get('line')))
for t, v in A['observed_records_all_targets'].items(): cands.append((v['candidate']['graph6'], f"observed:{v['variant']}/{v['active_target']}/{v['replicate']}:{t}", v['candidate'].get('family'), v['candidate'].get('line')))
base_origin = {'observed_W': ('HoG', 'hog57338'), 'active_W': ('HoG', 'endpoint_W2180'), 'TC_W': ('HoG', 'endpoint_W2180')}
for jid, v in E.items(): pass
for name, v in C.items():
    fam, line = base_origin.get(name, (None, None))
    for t, w in v['improving_witnesses'].items(): cands.append((w['graph6'], f'witness:{name}->{t}', fam, line))
def canon(adj):
    g = pynauty.Graph(99, adjacency_dict={i: sorted(adj[i]) for i in range(99)})
    return hashlib.sha256(pynauty.certificate(g)).hexdigest()
classes = {}
for g6, src, fam, line in cands:
    adj = decode_g6(g6); ok, why = lambda_valid(adj); assert ok, (src, why)
    c = canon(adj); s = scores(adj)
    e = classes.setdefault(c, {'class': c, 'graph6': g6, 'scores': s, 'sources': [], 'family': fam, 'line': line})
    e['sources'].append(src)
    if e['family'] is None and fam: e['family'], e['line'] = fam, line
pool = sorted(classes.values(), key=lambda e: (e['scores']['W'], e['scores']['L1'], hashlib.sha256(e['graph6'].encode()).hexdigest()))
top = pool[:16]
json.dump({'scope': 'preliminary; Git-available graphs only; final list after harvest D5',
           'distinct_classes_available': len(pool), 'top16': top}, open('record_pool_preliminary.json', 'w'), indent=1)
print('distinct classes', len(pool))
for e in top: print(e['scores']['W'], e['scores']['L1'], e['scores']['F'], e['family'], e['line'], e['sources'][:3], len(e['sources']))
