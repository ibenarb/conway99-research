"""Strikter (W,L1)-Bestabstieg mit unabhaengigem Apex∪Pivot (neigh.py) ab einem Zeugen.
Zeichnet in jedem Schritt die Groesse der Gleichstandsmenge beim besten Schluessel auf.
Nur Diagnose; kein Kampagnenendpunkt."""
import json, sys, time
from indep import decode_g6, scores, key, lambda_valid
from neigh import apexes, pivots, apply
def encode_g6(adj):
    n = len(adj); bits = []
    for j in range(1, n):
        for i in range(j): bits.append(1 if j in adj[i] else 0)
    bits += [0] * (-len(bits) % 6)
    out = chr(126) + ''.join(chr(63 + x) for x in ((n >> 12) & 63, (n >> 6) & 63, n & 63))
    return out + ''.join(chr(63 + int(''.join(map(str, bits[i:i+6])), 2)) for i in range(0, len(bits), 6))
def descend(adj, target='W', max_steps=200):
    path = []; cur = adj; s = scores(cur)
    for step in range(max_steps):
        cands = []
        for op, ms in (('apex', apexes(cur)), ('pivot', pivots(cur))):
            for d, a in ms:
                new = apply(cur, d, a); cands.append((key(scores(new), target), op, new))
        better = [c for c in cands if c[0] < key(s, target)]
        if not better:
            return cur, s, path, len(cands)
        b = min(c[0] for c in better); ties = [c for c in better if c[0] == b]
        _, op, cur = ties[0]; s = scores(cur)
        ok, _ = lambda_valid(cur); assert ok
        path.append({'step': step + 1, 'operator': op, 'scores': s, 'tie_set_size': len(ties), 'improving_moves': len(better), 'catalogue': len(cands)})
        print(path[-1], flush=True)
    return cur, s, path, None
if __name__ == '__main__':
    C = json.load(open(sys.argv[1]))
    start = decode_g6(C['observed_W']['improving_witnesses']['W']['graph6'])
    t = time.process_time()
    end, s, path, cat = descend(start)
    json.dump({'start_scores': scores(start), 'end_scores': s, 'end_graph6': encode_g6(end), 'end_valid': lambda_valid(end)[0],
               'path': path, 'final_catalogue_apex_pivot': cat, 'cpu_s': time.process_time() - t,
               'scope': 'post-run strict (W,L1) descent in apex∪pivot only; cycle3 not included; not a campaign endpoint'},
              open('descent_2121_result.json', 'w'), indent=1)
    print('END', s, 'steps', len(path), 'cpu', round(time.process_time() - t, 1))
