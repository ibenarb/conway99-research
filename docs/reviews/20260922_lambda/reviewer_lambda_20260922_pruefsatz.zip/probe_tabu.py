"""Sonde: getreue Nachbildung von Engine.step_tabu (b659cb8) fuer die ersten N Iterationen,
fuer die 12 echten Kampagnenseeds. Nutzt Projekt-kernel.catalogue/Scorer (Scores) und
dieselbe RNG-Verbrauchsreihenfolge (rng.choice unter Gleichstand, dann randint Tenure).
Ziel: pruefen, ob TC/W in allen Seeds denselben Pfad nimmt (Erklaerung fuer identischen Bestgraph)."""
import sys, json, time, random, hashlib
FROZEN, DATA, VARIANT, TARGET, N = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5])
sys.path.insert(0, FROZEN)
import bootstrap  # noqa
from kernel import catalogue, Scorer
from common import core
from search import key
class G:
    def check(self): pass
founders = json.load(open(f'{FROZEN}/founders.json')); cfg = json.load(open(f'{FROZEN}/config.json'))
E = json.load(open(f'{DATA}/ENDPOINTS.json'))
start = min(founders, key=lambda p: key(p['scores'], TARGET))
res = {}
cache = {}
def neighbours(rows):
    h = hashlib.sha256(repr(rows).encode()).hexdigest()
    if h not in cache:
        sc = Scorer(rows); cache[h] = [(n, m, *sc.evaluate(m)) for n, m in catalogue(rows, VARIANT == 'TC', G())]
    return cache[h]
import os
REPS = [int(x) for x in os.environ.get("REPS", ",".join(map(str, range(12)))).split(",")]
for rep in REPS:
    seed = core.derive_seed(cfg['seed_master'], ['lambda-compare', rep])
    jid = f'{VARIANT}--lambda-{TARGET}-{rep:02d}'
    assert E[jid]['seed'] == seed, 'seed mismatch'
    rng = random.Random(seed); rows = core.decode_g6(start['graph6']); cur = Scorer(rows).scores
    best = dict(cur); tabu = {}; it = 0; trace = []; first_best_it = None; ties_gt1 = 0
    while len(trace) < N:
        items = neighbours(rows)
        tabu = {e: x for e, x in tabu.items() if x > it}
        elig = [c for c in items if key(c[3], TARGET) < key(best, TARGET) or not any(tabu.get(f'{a},{b}', 0) > it for a, b in c[1][1])]
        if not elig:
            it = min(tabu.values()); trace.append('ADVANCE'); continue
        bk = min(key(c[3], TARGET) for c in elig); ties = [c for c in elig if key(c[3], TARGET) == bk]
        ties_gt1 += len(ties) > 1
        ch = rng.choice(ties)
        rows = ch[2]; cur = ch[3]
        tenure = rng.randint(*cfg['tabu_deleted_edge_tenure'])
        for a, b in ch[1][0]: tabu[f'{a},{b}'] = it + tenure + 1
        if key(cur, TARGET) < key(best, TARGET):
            best = dict(cur); first_best_it = len(trace) + 1
        trace.append(hashlib.sha256(core.encode_g6(rows).encode()).hexdigest()[:12] + f":{cur['W']},{cur['L1']}:{ch[0]}:t{len(ties)}")
        it += 1
    res[rep] = {'best': best, 'best_at_iteration': first_best_it, 'iterations_with_ties': ties_gt1,
                'reported_best': E[jid]['best']['scores'], 'reported_last_improvement_cpu': E[jid]['last_improvement_cpu'], 'trace': trace}
    print(rep, 'best', (best['W'], best['L1']), 'at it', first_best_it, 'tie-iterations', ties_gt1,
          '| reported', (E[jid]['best']['scores']['W'], E[jid]['best']['scores']['L1']), 'lastimp_cpu', round(E[jid]['last_improvement_cpu'], 1), flush=True)
traces = [tuple(v['trace']) for v in res.values()]
if len(traces) < 2: traces = traces*2
common = 0
while all(len(t) > common for t in traces) and len({t[common] for t in traces}) == 1: common += 1
res['summary'] = {'variant': VARIANT, 'target': TARGET, 'iterations': N, 'identical_prefix_length_all_12': common,
                  'distinct_full_traces': len(set(traces))}
print(res['summary'])
json.dump(res, open(f'probe_tabu_{VARIANT}_{TARGET}_{N}' + ('' if len(REPS)==12 else '_r'+'-'.join(map(str,REPS))) + '.json', 'w'), indent=1)
