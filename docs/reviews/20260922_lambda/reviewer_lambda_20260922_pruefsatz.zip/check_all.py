"""Prueft alle in ENDPOINTS.json und RECORD_CENSUS.json/AUDIT.json veroeffentlichten graph6
mit indep.py und vergleicht die gemeldeten Scores."""
import json, sys, hashlib
from indep import decode_g6, scores, lambda_valid
D = sys.argv[1]
E = json.load(open(f'{D}/ENDPOINTS.json'))
C = json.load(open(f'{D}/RECORD_CENSUS.json'))
A = json.load(open(f'{D}/AUDIT.json'))
graphs = {}
def add(tag, g6, sc):
    graphs.setdefault(g6, []).append((tag, sc))
for jid, v in E.items():
    add(jid + ':best', v['best']['graph6'], v['best']['scores'])
for t, v in A['observed_records_all_targets'].items():
    add('observed:' + t, v['candidate']['graph6'], v['candidate']['scores'])
for t, v in C.items():
    add('census:' + t, v['graph6'], v['scores'])
    for i, w in enumerate(v.get('witnesses', v.get('improvements', [])) or []):
        if isinstance(w, dict) and 'graph6' in w:
            add(f'census:{t}:witness{i}', w['graph6'], w.get('scores'))
bad = 0; out = {}
for g6, tags in graphs.items():
    adj = decode_g6(g6); ok, why = lambda_valid(adj); s = scores(adj)
    mism = [t for t, sc in tags if sc is not None and {k: sc[k] for k in s} != s]
    out[hashlib.sha256(g6.encode()).hexdigest()] = {'tags': [t for t, _ in tags], 'valid': ok, 'why': why, 'scores': s, 'mismatch': mism}
    bad += (not ok) + bool(mism)
# milestone sha check: every milestone sha must match either the best graph or be listed
print(json.dumps({'distinct_graph6': len(graphs), 'failures': bad}, indent=1))
json.dump(out, open('check_all_result.json', 'w'), indent=1)
# Zeugen aus RECORD_CENSUS (improving_witnesses): Gueltigkeit, Scores und Zug-Reproduktion
from neigh import apply
wit = {}
for name, v in C.items():
    base = decode_g6(v['graph6'])
    for t, w in v['improving_witnesses'].items():
        adj = decode_g6(w['graph6']); ok, why = lambda_valid(adj); s = scores(adj)
        dele = [tuple(e) for e in w['move'][0]]; add = [tuple(e) for e in w['move'][1]]
        rep = apply(base, dele, add)
        same = rep is not None and all(rep[i] == adj[i] for i in range(99))
        wit[f'{name}->{t}'] = {'operator': w['operator'], 'valid': ok, 'scores_match': s == {k: w['scores'][k] for k in s}, 'move_reproduces_graph6': same, 'scores': s}
        bad += (not ok) + (s != {k: w['scores'][k] for k in s}) + (not same)
json.dump(wit, open('witness_result.json', 'w'), indent=1)
print(json.dumps({'witnesses': len(wit), 'failures_total': bad}, indent=1))
