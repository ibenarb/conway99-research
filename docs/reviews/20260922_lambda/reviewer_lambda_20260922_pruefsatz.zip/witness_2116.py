"""Erzeugt und prueft den Zwei-Schritt-Zeugen W=2116 ab dem Ein-Schritt-Zeugen W=2121.
Schritt 1/2 werden mit dem eingefrorenen Projektkatalog (b659cb8) gesucht, das Ergebnis
mit indep.py unabhaengig geprueft. Kategorie 3 (Nachdiagnose), kein Kampagnenendpunkt."""
import sys, json, time
FROZEN, DATA = sys.argv[1], sys.argv[2]
sys.path.insert(0, FROZEN)
import bootstrap  # noqa
from kernel import catalogue, Scorer
from common import core
from search import key
from indep import decode_g6, scores as iscores, lambda_valid
class G:
    def check(self): pass
C = json.load(open(f'{DATA}/RECORD_CENSUS.json'))
g6 = C['observed_W']['improving_witnesses']['W']['graph6']
rows = tuple(core.decode_g6(g6)); base = Scorer(rows).scores
t = time.process_time(); best = None
sc = Scorer(rows)
for n1, m1 in catalogue(rows, True, G()):
    ch1, s1 = sc.evaluate(m1); sc2 = Scorer(ch1)
    for n2, m2 in catalogue(ch1, True, G()):
        ch2, s2 = sc2.evaluate(m2)
        if ch2 == rows: continue
        if key(s2, 'W') < key(base, 'W') and (best is None or key(s2, 'W') < key(best['scores'], 'W')):
            best = {'scores': s2, 'graph6': core.encode_g6(ch2),
                    'step1': {'operator': n1, 'move': m1, 'scores': s1},
                    'step2': {'operator': n2, 'move': m2}}
adj = decode_g6(best['graph6']); ok, why = lambda_valid(adj)
best.update(independent_valid=ok, independent_scores=iscores(adj),
            independent_scores_match=iscores(adj) == {k: best['scores'][k] for k in iscores(adj)},
            start_graph6=g6, start_scores=base, cpu_s=round(time.process_time() - t, 1),
            scope='post-run two-step diagnostic witness; not a campaign endpoint; not further descended')
json.dump(best, open('witness_2116_result.json', 'w'), indent=1)
print(best['scores'], best['step1']['operator'], best['step1']['scores'], '->', best['step2']['operator'], ok, best['independent_scores_match'])
