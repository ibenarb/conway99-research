"""Eigene Neuberechnung der Paarvergleiche, Messpunkte und Laufkennzahlen aus ENDPOINTS.json."""
import json, sys, statistics as st
from indep import key
E = json.load(open(f'{sys.argv[1]}/ENDPOINTS.json'))
V = ('B0', 'P', 'T', 'TC'); T = ('W', 'L1', 'F', 'Linf'); M = ('600', '1800', '3600')
def ms(v, t, i, m): return E[f'{v}--lambda-{t}-{i:02d}']['milestones'][m]['scores']
out = {'pairs': {}, 'per_seed': {}, 'runstats': {}}
for t in T:
    for a, b in (('P','B0'),('T','B0'),('TC','B0'),('P','T'),('TC','T'),('TC','P')):
        for m in M:
            w = l = 0
            for i in range(12):
                ka, kb = key(ms(a,t,i,m), t), key(ms(b,t,i,m), t)
                w += ka < kb; l += ka > kb
            out['pairs'][f'{t}:{a}vs{b}@{m}'] = (w, 12-w-l, l)
    for v in V:
        out['per_seed'][f'{v}/{t}'] = {m: [key(ms(v,t,i,m), t) for i in range(12)] for m in M}
        jobs = [E[f'{v}--lambda-{t}-{i:02d}'] for i in range(12)]
        out['runstats'][f'{v}/{t}'] = {
            'median_iterations': st.median(j['iterations'] for j in jobs), 'median_episodes': st.median(j['episodes'] for j in jobs),
            'restarts': [j['restarts'] for j in jobs], 'archive_classes_median': st.median(j['archive_classes'] for j in jobs),
            'classes_per_iteration_median': st.median(j['archive_classes'] / max(1, j['iterations']) for j in jobs) if v in ('T','TC') else None,
            'last_improvement_cpu': sorted(round(j['last_improvement_cpu'], 1) for j in jobs),
            'adopted_moves_total': {op: sum(j['adopted_moves'].get(op, 0) for j in jobs) for op in ('apex','pivot','cycle3','rotation','old')},
            'distinct_best_graph6': len({j['best']['graph6'] for j in jobs})}
json.dump(out, open('paired_result.json', 'w'), indent=1)
for k in ('W:P' ,'W:T','W:TC'):
    pass
for k, v in out['pairs'].items():
    if k.startswith('W:') or k.endswith('@3600'): print(k, v)
for k, v in out['runstats'].items(): print(k, v)
print('W per seed @3600:')
for v in V: print(v, [x[0] for x in out['per_seed'][f'{v}/W']['3600']])
print('W per seed @1800:')
for v in V: print(v, [x[0] for x in out['per_seed'][f'{v}/W']['1800']])
print('Linf per seed @3600:')
for v in V: print(v, [x[1] for x in out['per_seed'][f'{v}/Linf']['3600']])
