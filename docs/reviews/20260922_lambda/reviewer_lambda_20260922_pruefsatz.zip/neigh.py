"""Unabhaengige Brute-Force-Nachbarschaft (Apex, Pivot) nach Definition,
mit vollstaendiger lokaler lambda-Pruefung jedes Kandidaten. Kein Projektcode.
Dreierzyklus wird NICHT unabhaengig nachgebaut (nur in probe_descent.py via Projektcode)."""
from itertools import combinations
from indep import triangles, scores, residuals, key

def apply(adj, deleted, added):
    new = [set(s) for s in adj]
    for a, b in deleted:
        if b not in new[a]: return None
        new[a].discard(b); new[b].discard(a)
    for a, b in added:
        if b in new[a] or a == b: return None
        new[a].add(b); new[b].add(a)
    return new

def locally_valid(new, touched, k=14):
    for i in touched:
        if len(new[i]) != k: return False
        for j in new[i]:
            if len(new[i] & new[j]) != 1: return False
    return True

def E(a, b): return (a, b) if a < b else (b, a)

def pivots(adj):
    tri = list(triangles(adj)); by = {}
    for t in tri:
        for p in t: by.setdefault(p, []).append(tuple(v for v in t if v != p))
    moves = set()
    for p, pairs in by.items():
        for (x, y), (u, v) in combinations(pairs, 2):
            for a, b in ((x, y), (y, x)):
                dele = frozenset({E(a, b), E(u, v)}); add = frozenset({E(a, u), E(b, v)})
                new = apply(adj, dele, add)
                if new is not None and locally_valid(new, {a, b, u, v}):
                    moves.add((dele, add))
    return moves

def apexes(adj):
    tri = list(triangles(adj)); moves = set()
    for T1, T2 in combinations(tri, 2):
        if set(T1) & set(T2): continue
        for c in T1:
            a, b = [v for v in T1 if v != c]
            for d in T2:
                e, f = [v for v in T2 if v != d]
                dele = frozenset({E(a, c), E(b, c), E(d, e), E(d, f)})
                add = frozenset({E(a, d), E(b, d), E(c, e), E(c, f)})
                new = apply(adj, dele, add)
                if new is not None and locally_valid(new, {a, b, c, d, e, f}):
                    moves.add((dele, add))
    return moves

def census(adj, targets=('W', 'L1', 'F', 'Linf')):
    base = scores(adj); out = {}
    for name, ms in (('apex', apexes(adj)), ('pivot', pivots(adj))):
        imp = {t: 0 for t in targets}; best = {}
        for dele, add in ms:
            s = scores(apply(adj, dele, add))
            for t in targets:
                if key(s, t) < key(base, t):
                    imp[t] += 1
                    if t not in best or key(s, t) < key(best[t][0], t):
                        best[t] = (s, sorted(dele), sorted(add))
        out[name] = {'moves': len(ms), 'improving': imp, 'best': best}
    return base, out
