"""Unabhaengiger Pruefkern (Reviewer, 22.09.2026): eigener graph6-Decoder,
eigene Residuen/Scores, eigene lambda-Gueltigkeit. Importiert keinen Projektcode."""
from collections import Counter

def decode_g6(text):
    s = text.strip()
    if s.startswith('>>graph6<<'):
        s = s[10:]
    data = [ord(c) - 63 for c in s]
    if data[0] == 63:  # n >= 63
        if data[1] == 63:
            raise ValueError('n too large')
        n = (data[1] << 12) | (data[2] << 6) | data[3]; body = data[4:]
    else:
        n = data[0]; body = data[1:]
    bits = []
    for x in body:
        if not 0 <= x < 64: raise ValueError('bad char')
        bits.extend((x >> (5 - k)) & 1 for k in range(6))
    need = n * (n - 1) // 2
    if len(bits) < need or any(bits[need:]) and len(bits) - need >= 6:
        raise ValueError('bad length')
    adj = [set() for _ in range(n)]
    idx = 0
    for j in range(1, n):          # graph6: column-major upper triangle
        for i in range(j):
            if bits[idx]:
                adj[i].add(j); adj[j].add(i)
            idx += 1
    return adj

def residuals(adj):
    n = len(adj)
    r = {}
    for u in range(n):
        for v in range(u + 1, n):
            r[(u, v)] = len(adj[u] & adj[v]) + (1 if v in adj[u] else 0) - 2
    return r

def scores(adj):
    h = Counter(residuals(adj).values())
    m = max((abs(k) for k, c in h.items() if c), default=0)
    return {'W': sum(c for k, c in h.items() if k),
            'L1': sum(abs(k) * c for k, c in h.items()),
            'F': sum(k * k * c for k, c in h.items()),
            'Linf': m, 'Nmax': sum(c for k, c in h.items() if abs(k) == m)}

def lambda_valid(adj, n=99, k=14):
    """n Knoten, k-regulaer, einfach, jede Kante genau ein gemeinsamer Nachbar
    (=> jede Kante in genau einem Dreieck; 2-Sektion ohne Zusatzdreiecke)."""
    if len(adj) != n: return False, 'n'
    for u in range(n):
        if u in adj[u]: return False, 'loop'
        if len(adj[u]) != k: return False, 'degree'
        for v in adj[u]:
            if u not in adj[v]: return False, 'asym'
            if v > u and len(adj[u] & adj[v]) != 1: return False, 'CN'
    # Dreiecke explizit zaehlen: genau n*k/6 = 231, jeder Knoten in k/2 = 7
    tri = [t for t in triangles(adj)]
    if len(tri) != n * k // 6: return False, 'triangles'
    per = Counter(v for t in tri for v in t)
    if any(per[v] != k // 2 for v in range(n)): return False, 'tri/vertex'
    return True, 'ok'

def triangles(adj):
    n = len(adj)
    for u in range(n):
        for v in adj[u]:
            if v > u:
                for w in adj[u] & adj[v]:
                    if w > v:
                        yield (u, v, w)

def key(s, target):
    return {'W': (s['W'], s['L1']), 'L1': (s['L1'],), 'F': (s['F'],),
            'Linf': (s['Linf'], s['Nmax'], s['L1'])}[target]
