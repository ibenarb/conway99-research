# ROOT8105 Census 1.0.0: unabhängiger Crosscheck und Korrekturkandidat 1.0.1-rc1

Datum: 04.10.2026. Geprüft: `experiments/memetik/root8105_census_1_0_0` und
`docs/augmentation/root8105_census_20261004` am Commit
`948f252f798d8dc2cbf0044faa8d1e985c83fc04` (Prüfsummen gegen `SHA256.json`
bestätigt). Korrekturkandidat als neues Verzeichnis
`experiments/memetik/root8105_census_1_0_1rc1`; 1.0.0 bleibt unverändert. Umgebung: Linux-Sandbox, 1 CPU, kein WSL/Windows. Keine
Produktionskampagne gestartet. Die 1.0.0-Belege und das 1.0.0-Paket bleiben unverändert.

## Urteil

1.0.0: **nach Korrekturen freigeben.** Gegen die Counts selbst liegt kein Befund
vor. Die Schwächen betreffen den Betrieb unter Fehlern: Der Windows-Zeitmesser
kann den Lauf abbrechen oder dauerhaft sperren, nach hartem Absturz fehlt ein
Wiederanlaufweg, und die Startprüfung erkennt nicht alle inkonsistenten Zustände.

1.0.1-rc1 (dieser Patch): Ryzen-Vorabkontrolle empfohlen. Breitenzensus nach
bestandenen Zielhardwaretests T1, T4, T5 und T8 (unten). Status bewusst
`NOT_RELEASED`.

## Befunde an 1.0.0

| ID | Ort | Schwere | Gegenbeispiel (reproduziert, siehe evidence) | Korrektur |
|---|---|---|---|---|
| H1 | `census.py` `run_campaign` Z.177–183 | hoch | Ohne `powershell.exe` bleibt die Sitzung offen; jedes weitere `run` wird mit `UNCLOSED_SESSION` verweigert | K1 |
| H2 | `census.py` Z.283–290 | hoch | Eine einzige ungültige Zeitmesserdatei führt zu `CONTROLLER_ERROR`, alle Worker stoppen | K2 |
| H3 | `census.py` Z.334 `host.wait()` | mittel/hoch | Hängt der Helfer, wartet der Controller nach getaner Arbeit unbegrenzt; SIGTERM wirkungslos; nach kill offene Sitzung | K3 |
| H4 | kein Recovery-Befehl | hoch (Betrieb) | Nach SIGKILL ist der Lauf dauerhaft gesperrt; DB-CPU 0.0 statt 0.37 s bzw. 2.58 s | K4 |
| M1 | `worker.py` Z.24–27 | mittel | Controllertod während des Worker-Starts: Worker rechnet unbeaufsichtigt bis COMPLETE, CPU ungebucht | K6 |
| M2 | `census.py` `audit_start`, Endstatus | mittel | RUNNING-Root ohne Versuch besteht das Audit, wird nie neu geplant, Zensus endet als `CALIBRATION_COMPLETE` mit Exit 0 | K5 |
| M3 | Speicherort, Live-Lesen | mittel | Fremde Schreibsperre >30 s bricht den Controller ab; kein Dateisystemcheck; Live-Lesefehler global fatal | K2/K7 |
| N | diverse | niedrig | Prompt nach Neustart nicht wiederholt; ETA ohne Live-Fortschritt und längsten Rest-Root (GC-11); eine Filterkennung für alle Varianten; Worker-Waise zwischen `Popen` und INSERT; Fatalpfad ohne Teilzählungen | K8 u.a. |

Ohne Befund geprüft: Die GC-19-Antwortlogik (acht gleichzeitige Antworten
ergeben genau ein EXTENDED; ungültige Eingaben laufen weiter). Die
CPU-Abrechnung zeigt keine Doppelzählung. Die Ergebnisübernahme ist atomar.

## Befund 66 → 64 (erster Cloud-Persistenzlauf)

`evidence/forensics_66_64.py` wertet `development_evidence.tar.gz` reproduzierbar aus.

Die gespeicherte `run.sqlite` enthält `latest_state=CALIBRATION_COMPLETE` und
`helper_cpu_<session>`. Beide werden in derselben Transaktion geschrieben wie das
Sitzungsende. Sie enthält außerdem den `auxiliary_cpu_s`-Wert nach dem späteren
Export. Trotzdem steht die Sitzung noch auf RUNNING, zwei Versuche sind offen,
und es fehlen zwei Ergebnisse. `integrity_check` meldet `ok`.

Die Datei mischt also Seiten verschiedener Commit-Zeitpunkte. Weder SQLite mit
kohärentem WAL noch der Controllercode können diesen Zustand erzeugen. Zusätzlich
liegt `output.json` von Root 36 als veralteter Zwischenstand vor, obwohl Root 36
im exportierten `census.jsonl` vollständig steht.

Folgerung: Ursache ist sehr wahrscheinlich die Synchronisations- bzw.
Kopierschicht, nicht der Controller.

Der Wiederholungslauf sichert ab: 66 Ergebnisse auf lokalem Dateisystem
persistiert und beim Wiederöffnen ohne Neuberechnung bestätigt. Nicht abgesichert
sind dadurch Fortsetzung mitten im Root, Absturz und WSL. Diese Lücken schließen
die rc1-Tests (unten), außer WSL.

## Mathematik

Die Tiefe-1-Reduktion auf historisches F, der Overflowbeweis
(B7 = 134 744 793 483 572 < 2^63−1), die Sampler-Bijektion und die Notwendigkeit
von LD und CAP sind korrekt begründet.

Provenienz: Die Reviewerwerte stammen aus `width_dp.py`, dem Vorfahren von
`kernel.py`. Daher zusätzlich eine unabhängige Kontrolle mit dem
Python-Vertexzähler: 498 Counts Kern gegen Vertexzähler und 1.992 Counts
Vertexzähler gegen Fixture, alle drei Roottypen, **keine Abweichung**. `validate.py`
bestand vollständig auf 1.0.0 und auf rc1.

## Korrekturen in 1.0.1-rc1

Kern, Modell, Rootliste und Fixtures sind unverändert. Der Fingerprint ist neu,
daher sind 1.0.0-Laufverzeichnisse absichtlich nicht fortsetzbar.

- **K1:** Zeitmesserstart im `try`. Fehler ergeben `HOST_CLOCK_UNAVAILABLE`, die ETA bleibt `unknown`, die Zählung läuft weiter.
- **K2:** `read_host_clock` wirft nie eine Ausnahme. Der letzte gültige Wert bleibt erhalten, Fehler werden unter `warnings_<session>` gezählt. Live-CPU-Lesefehler sind nicht mehr fatal.
- **K3:** Helfer-Stopp mit Timeout (60 s), danach terminate/kill. Die Windows-CPU gilt dann als Untergrenze.
- **K4:** `census.py reconcile-crash RUN_DIR [--apply]`, Trockenlauf als Standard.
  - Verweigert, solange ein Lock gehalten wird oder ein Worker derselben Boot-ID lebt.
  - Schließt Versuche als `CRASH_LOWER_BOUND` (cpu_exact=0, max(Livewert, Worker-Selbstmeldung)).
  - Schließt die Sitzung als `CRASHED_RECONCILED`.
  - Gerettete Ausgaben werden getrennt als `salvage_*` gespeichert und nicht übernommen.
  - Der Lauf trägt danach `cpu_is_lower_bound=true`.
- **K5:** Audit-Invarianten, nämlich RUNNING nur mit offenem Versuch, ERROR mit ERROR-Versuch, Ergebnisversuch zum selben Root, `latest_state` gleich letzter Sitzung und wohlgeformte Teilzählungen. Dazu Endstatus `PHASE_INCOMPLETE` mit Exitcode 3 und `CALIBRATION_COMPLETE_WITH_ERRORS`.
- **K6:** Der Worker vergleicht nach `prctl` mit der Controller-PID aus der spec und prüft STOP vor jedem Ziel.
- **K7:** Dateisystemprüfung für RUN_DIR in `run` und Preflight. Die Preflight-Probe startet den echten Windows-Zeitmesser 12 s lang und warnt nur. Die Preflight-CPU wird vollständig über `RUSAGE_CHILDREN` erfasst.
- **K8:** Offene Anfrage wird bei jedem Controllerstart erneut angezeigt. ETA zieht Live-Fortschritt ab und berücksichtigt den längsten Rest-Root. Jede Filterkombination hat eine eigene Kennung.
- **Fatalpfad:** Alle Worker werden geerntet. Nicht verbuchte Abschlüsse werden erneut versucht, Teilzählungen bleiben erhalten. Ein zwischen `Popen` und INSERT verwaister Worker wird sofort beendet.

## Prüfungen von rc1

| Prüfung | Ergebnis |
|---|---|
| `validate.py` vollständig | PASS, zusätzlich vier getrennte Filterkennungen |
| `operations_test.py` | 20/20 PASS, davon 9 neu |
| Gegenprobe PDEATHSIG-Test mit `worker.py` 1.0.0 | 3/3 COMPLETE, der Test schlägt also fehl wie beabsichtigt |
| Echter Kern, 1 Worker: Pause → Fortsetzung → SIGKILL → `reconcile-crash` → Fortsetzung | Audit PASS; alle Ergebnisse gleich Vertexzähler; 54 gerettete Zählungen identisch |
| Echter Kern, endgültiger Code | Kurzlauf mit SIGTERM-Kontrollpunkt, PASS |
| Zeitmesser-Probe (Attrappen: gut, fehlt, korrupt, hängt) | PASS, UNAVAILABLE, DEGRADED, DEGRADED |
| Preflight vollständig | PASS (ext4, NOT_WSL) |

Die neuen Prozesstests decken ab:
- erneute Anzeige offener Anfragen
- verwaister RUNNING-Root
- Worker-Waise beim Start
- Absturz mit Abgleich und Fortsetzung
- extern gestoppter Worker
- vier Zeitmesserfälle mit selbst erzeugten `wslpath`/`powershell.exe`-Attrappen

Einschränkungen dieser Prüfungen:
- Die Echtkern-Läufe und der Preflight nutzten in dieser 4-GiB-Sandbox einen markierten Platzhalter bzw. eine gesenkte RAM-Schwelle in einer Kopie.
- Kein 11-Worker-66-Root-Lauf mit rc1.
- Kein WSL.
- Terminate beendet unter WSL nur den Interop-Prozess. Eine wirklich hängende Windows-PowerShell kann weiterlaufen und wird protokolliert.

## Zielhardwaretests vor dem Zensus

- **T1:** `host_clock.ps1` unter de-DE etwa 3 min laufen lassen. Prüfen: JSON jede Sekunde gültig, ob `Move-Item -Force` die Zieldatei kurz entfernt, Drift gegenüber der WSL-Uhr, Stopp-Reaktion.
- **T2:** Preflight-Probe auswerten (`host_clock_probe` in `preflight.json`).
- **T3:** Wegwerf-Kalibrierung mit 11 Workern. SIGTERM nach etwa 30 s, Fortsetzung, Digest-Vergleich mit einem Referenzlauf.
- **T4:** `wsl --shutdown` während eines Wegwerf-Laufs, danach `reconcile-crash`, `--apply` und Fortsetzung.
- **T5:** Prüfen, ob der nohup-Controller das Schließen des Terminals bzw. das WSL-Leerlaufende überlebt. Schlafmodus und Update-Neustarts für die Laufdauer sperren.
- **T6:** `validate.py` ohne `--quick`.
- **T7:** 11 Worker parallel zu C2. `MemAvailable` muss über 2 GiB bleiben.
- **T8:** `stat -f -c %T RUN_DIR` muss ext2/ext3 ergeben.
- **T9:** Wegwerf-Lauf mit etwa 300 s Budget. Prompt, Antwort im zweiten Terminal und `0` prüfen.

Erwarteter Umfang nach Cloud-Kalibrierung: etwa 23 CPU-h für 8105 Roots. Die
Meldeschwelle von 48 h wird voraussichtlich nicht erreicht, GC-19 also nur über
T9 praktisch geprüft.

## Inhalt von `evidence.tar.gz`

- `forensics_66_64.py`: Auswertung des fehlgeschlagenen Cloud-Laufs.
- `experiments_1_0_0/`: Skripte gegen unverändertes 1.0.0 sowie `OBSERVED_OUTPUTS.json` (transkribierte Konsolenausgaben) und `xcheck.jsonl` (unabhängige Zählerkontrolle).
- `wsl_simulation/`: Attrappen und Diff der Simulationskopie (nur WSL-Erkennung erzwungen).
- `rc1_runs/`: Datenbanken, Logs und Berichte der rc1-Läufe (Echtkern, Preflight, Tests).
