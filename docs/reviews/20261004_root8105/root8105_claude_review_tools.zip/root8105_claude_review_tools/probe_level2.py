"""Knuth-type level-2 probe for one root (proposed phase P2, prototype).

Branching rule R1 (fixed before measurement):
  level 1: target t1 = argmin of the exact level-1 widths (edge DP, all 83 targets);
  level 2: target = argmin of width_exact over all open targets adjacent to u or t1
           (all candidates are measured exactly; their cost is part of the probe cost).
Children at level 1 are drawn uniformly from the complete enumeration of t1's
projection (pilot encoder + Glucose, exhaustive, completeness = final UNSAT).
Unbiased estimate of the level-3 node count of rule R1:  N3_hat = w1 * mean(w2_min).

Usage: python3 probe_level2.py PILOT_DIR ROOTS.tsv ROOT_ID SAMPLES SEED OUT.jsonl
"""
import json
import random
import sys
import time

from crosscheck_sat import import_pilot, sat_rows
from width_dp import Geo, load_roots, width_exact, width_fast


def main(pilot_dir, roots_path, root_id, samples, seed, out_path):
    pc = import_pilot(pilot_dir)
    G, g = pc.Geometry(7), Geo(7)
    root = next(r for r in load_roots(roots_path, g) if r['id'] == root_id)
    r = root['row']
    w1 = {t: width_fast(g, r, t) for t in range(1, g.n)}
    t1 = min(w1, key=w1.get)
    kids, complete = sat_rows(pc, G, {0: r}, t1)
    assert complete and len(kids) == w1[t1], 'level-1 enumeration disagrees with DP'
    rng = random.Random(seed)
    with open(out_path, 'a') as out:
        for k in range(samples):
            row = rng.choice(kids)
            S = {0: r, t1: row}
            G.verify(S)
            cand = [t for t in range(g.n) if t not in S and ((r >> t) & 1 or (row >> t) & 1)]
            t0 = time.process_time()
            W = {t: width_exact(g, S, t) for t in cand}
            tm = min(W, key=W.get)
            out.write(json.dumps({'root': root_id, 'stab': root['stab'], 't1': list(g.labels[t1]), 'w1': w1[t1],
                                  'sample': k, 'row': hex(row), 'candidates': len(cand),
                                  'w2_min': W[tm], 'argmin': list(g.labels[tm]),
                                  'widths': {str(t): v for t, v in W.items()},
                                  'cpu_s': round(time.process_time() - t0, 1)}) + '\n')
            out.flush()


if __name__ == '__main__':
    a = sys.argv
    main(a[1], a[2], int(a[3]), int(a[4]), int(a[5]), a[6])
