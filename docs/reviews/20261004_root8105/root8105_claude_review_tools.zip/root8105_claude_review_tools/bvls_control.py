"""Full-model positive control for the ROOT8105 code path at m=11.

SRG(243,22,1,2) (Berlekamp-van Lint-Seidel) = coset graph of the ternary Golay code
[11,6,5]. Any vertex x gives N(x) = 11K2 and every non-neighbour meets exactly two
non-matched border vertices, i.e. the identical row model with m=11 (220 H-rows,
H-degree 20). Steps:
  1. build the code (729 words, d=5) and the graph; check A^2 = 22I + A + 2(J-I-A);
  2. map into pilot Geometry(11); pilot Geometry.verify (all 220 rows) and
     completion.verify_complete must pass;
  3. positive: for random prefixes (depth 1..219) and random targets, core.encode(prefix, t)
     with ALL edge variables fixed to the witness must be SAT;
  4. negative: a target row with correct degree, margins and symmetry but wrong
     codegree with u must be rejected by Geometry.verify ('common neighbors') and
     must make core.encode UNSAT under the row assumptions.
Usage: python3 bvls_control.py PILOT_DIR [out.json]
GC-20: this is a positive control for m=11 only; no runtime claim for m=7.
"""
import itertools
import json
import random
import sys

import numpy as np

from crosscheck_sat import import_pilot


def golay_coset_graph():
    p = 3
    g = [2, 0, 1, 2, 1, 1]                      # x^5+x^4-x^3+x^2-1, low -> high
    Gm = np.array([[0] * i + g + [0] * (11 - 6 - i) for i in range(6)]) % p
    code = {tuple(int(x) for x in np.dot(c, Gm) % p) for c in itertools.product(range(p), repeat=6)}
    dmin = min(sum(1 for x in w if x) for w in code if any(w))
    H = []                                       # parity-check rows: dual code basis
    def rank(M):
        M = [list(r) for r in M]; r = 0
        for c in range(11):
            piv = next((i for i in range(r, len(M)) if M[i][c] % p), None)
            if piv is None:
                continue
            M[r], M[piv] = M[piv], M[r]; inv = pow(M[r][c], -1, p)
            M[r] = [x * inv % p for x in M[r]]
            for i in range(len(M)):
                if i != r and M[i][c] % p:
                    f = M[i][c]; M[i] = [(a - f * b) % p for a, b in zip(M[i], M[r])]
            r += 1
        return r
    for v in itertools.product(range(p), repeat=11):
        if any(v) and not (np.dot(Gm, v) % p).any() and rank(H + [list(v)]) > len(H):
            H.append(list(v))
            if len(H) == 5:
                break
    H = np.array(H)
    cols = [tuple(int(x) for x in H[:, i]) for i in range(11)]
    neg = [tuple(int(x) for x in (-np.array(c)) % p) for c in cols]
    S = set(cols) | set(neg)
    V = list(itertools.product(range(p), repeat=5)); idx = {v: i for i, v in enumerate(V)}
    A = np.zeros((243, 243), dtype=int)
    for v in V:
        for s in S:
            A[idx[v], idx[tuple((np.array(v) + s) % p)]] = 1
    I, J = np.eye(243, dtype=int), np.ones((243, 243), dtype=int)
    ok = bool((A == A.T).all() and (A.sum(1) == 22).all() and (A @ A == 22 * I + A + 2 * (J - I - A)).all())
    return A, idx, cols, neg, len(code), dmin, ok


def main(pilot_dir, out_path=None):
    pc = import_pilot(pilot_dir)
    completion = __import__('completion')
    A, idx, cols, neg, ncode, dmin, srg_ok = golay_coset_graph()
    G = pc.Geometry(11)
    x = idx[(0,) * 5]
    Nx = [idx[c] for c in cols] + [idx[c] for c in neg]     # border a <-> a+11 matched (+h, -h)
    pos = {v: a for a, v in enumerate(Nx)}
    assert all(A[Nx[a], Nx[a + 11]] for a in range(11))
    lab = {}
    for v in range(243):
        if v != x and not A[x, v]:
            nb = sorted(pos[w] for w in Nx if A[v, w])
            lab[v] = G.index[tuple(nb)]
    inv = {l: v for v, l in lab.items()}
    W = {l: sum(1 << l2 for l2 in range(G.n) if A[inv[l], inv[l2]]) for l in range(G.n)}
    G.verify(W)
    full = completion.verify_complete(G, W)['status']
    from pysat.solvers import Glucose4
    rng = random.Random(20261004)
    positives = []
    for d in (1, 2, 5, 10, 20, 40, 80, 120, 150, 200, 219):
        for _ in range(3):
            built = rng.sample(range(1, G.n), d - 1) + [0]
            rows = {u: W[u] for u in built}
            G.verify(rows)
            t = rng.choice([v for v in range(G.n) if v not in rows])
            cnf, var = pc.encode(G, rows, t)
            assum = [(l if (W[a] >> b) & 1 else -l) for (a, b), l in var.items()]
            with Glucose4(bootstrap_with=cnf.clauses) as s:
                positives.append({'depth': d, 'target': t, 'edge_vars': len(var), 'sat': s.solve(assumptions=assum)})
    # negative control: right degree/margins/symmetry, wrong codegree with u
    u = 0; Nu = {v for v in range(G.n) if (W[u] >> v) & 1}
    t = next(v for v in range(1, G.n) if not (W[u] >> v) & 1)
    need = 2 - len(G.sets[t] & G.sets[u]); marg = G.margins(t); neg_result = None
    for _ in range(200000):
        labs = [i for i in range(G.n) if i not in (t, u)]; rng.shuffle(labs)
        deg, R = [0] * G.b, []
        for i in labs:
            a, b = G.labels[i]
            if deg[a] < marg[a] and deg[b] < marg[b]:
                R.append(i); deg[a] += 1; deg[b] += 1
        if deg == marg and len(set(R) & Nu) != need:
            row = sum(1 << i for i in R)
            try:
                G.verify({u: W[u], t: row}); verdict = 'NOT_REJECTED'
            except ValueError as e:
                verdict = str(e)
            cnf, var = pc.encode(G, {u: W[u]}, t)
            fixed, free = pc.projection(G, {u: W[u]}, t, var)
            with Glucose4(bootstrap_with=cnf.clauses) as s:
                enc = s.solve(assumptions=[(l if (row >> v) & 1 else -l) for v, l in free])
            neg_result = {'codegree_wrong': len(set(R) & Nu), 'codegree_required': need,
                          'verify': verdict, 'encode_sat': enc}
            break
    out = {'golay_code_words': ncode, 'min_distance': dmin, 'srg_243_22_1_2': srg_ok,
           'pilot_verify_all_220_rows': 'PASS', 'pilot_verify_complete': full,
           'positive_prefix_tests': len(positives), 'positive_all_sat': all(p['sat'] for p in positives),
           'negative_control': neg_result,
           'status': 'PASS' if srg_ok and full == 'SRG_FOUND_VERIFIED' and all(p['sat'] for p in positives)
                     and neg_result and neg_result['verify'] == 'common neighbors' and not neg_result['encode_sat'] else 'FAIL'}
    print(json.dumps(out, indent=2))
    if out_path:
        json.dump({'summary': out, 'positives': positives, 'rows_m11': {str(k): hex(v) for k, v in W.items()}},
                  open(out_path, 'w'), indent=1)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
