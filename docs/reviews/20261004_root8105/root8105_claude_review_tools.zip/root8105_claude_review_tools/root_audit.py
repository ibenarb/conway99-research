"""Independent audit of the 8105 ROOT8105 root classes (no nauty, no vertex DP).

Builds G_u = stabiliser of label {0,1} in the hyperoctahedral group C2 wr S7
(order 7680) explicitly, checks for every representative its stabiliser order,
pairwise inequivalence via canonical minimum images, the orbit sum, and compares
with an independent edge-DP count of all margin-valid u-rows.

Usage: python3 root_audit.py PATH/TO/roots.tsv
Runtime: ~40 s on one core. Read-only.
"""
import itertools
import json
import sys
import time

import numpy as np

from width_dp import Geo, count_rows_fast, load_roots


def group_u(g):
    idx = {p: i for i, p in enumerate(g.labels)}
    elems = []
    for pi in itertools.permutations(range(g.m)):
        for fl in range(1 << g.m):
            s = [pi[i % g.m] + g.m * (((i // g.m) ^ (fl >> (i % g.m))) & 1) for i in range(g.b)]
            if {s[0], s[1]} == {0, 1}:
                elems.append([idx[tuple(sorted((s[a], s[b])))] for a, b in g.labels])
    return np.array(elems)


def main(path):
    t0 = time.time()
    g = Geo(7)
    G = group_u(g)
    inv = np.argsort(G, axis=1)
    roots = load_roots(path, g)
    rows = np.array([[(r['row'] >> v) & 1 for v in range(g.n)] for r in roots], dtype=np.uint8)
    canon, bad, orbit_sum = set(), [], 0
    for i, r in enumerate(roots):
        keys = [bytes(x) for x in np.packbits(rows[i][inv], axis=1)]
        own = bytes(np.packbits(rows[i]))
        stab = sum(1 for k in keys if k == own)
        mn = min(keys)
        if stab != r['stab'] or r['orbit'] * stab != len(G) or mn in canon:
            bad.append(r['id'])
        canon.add(mn)
        orbit_sum += len(set(keys))
    dp_total = count_rows_fast(g, 0)
    out = {'status': 'PASS' if not bad and orbit_sum == dp_total and len(canon) == len(roots) else 'FAIL',
           'group_order': int(len(G)), 'roots': len(roots), 'distinct_classes': len(canon),
           'stabiliser_or_duplicate_failures': bad, 'orbit_sum': orbit_sum,
           'independent_edge_dp_row_count': dp_total, 'seconds': round(time.time() - t0, 1)}
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
