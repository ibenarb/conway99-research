"""Exact first-extension widths for ROOT8105 roots (proposed phase P1).

For every root class and every target label t != u the exact projected width of
core.encode({0: root}, t) is computed by the edge DP (no SAT, no enumeration,
no row storage). Output: one JSON line per root, resumable (finished ids are skipped).

Usage: python3 census_level1.py ROOTS.tsv OUT.jsonl [--workers 11] [--ids 1,9,20]
Sandbox speed: ~0.12 s per (root, target) on one core, i.e. ~10 s per root;
8105 roots ~ 22 CPU-h (budget projection only, measure on the Ryzen first).

This is a review tool, not a GC-19 production controller: it has no time budget
and never stops on time. For a production run wrap it in the project controller
(time-budget dialog, receipts, heartbeat) as required by EXPERIMENT_RULES v1.1.
"""
import argparse
import json
import os
import time
from multiprocessing import Pool

from width_dp import Geo, load_roots, width_fast

G = Geo(7)


def one(root):
    t0 = time.process_time()
    w = [width_fast(G, root['row'], t) for t in range(1, G.n)]
    m = min(w)
    return {'id': root['id'], 'stab': root['stab'], 'orbit': root['orbit'], 'row': hex(root['row']),
            'widths_t1_to_t83': w, 'min': m, 'argmin': [t for t in range(1, G.n) if w[t - 1] == m],
            'cpu_s': round(time.process_time() - t0, 3)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('roots'); ap.add_argument('out')
    ap.add_argument('--workers', type=int, default=1)
    ap.add_argument('--ids', default=None)
    a = ap.parse_args()
    roots = load_roots(a.roots, G)
    if a.ids:
        keep = {int(x) for x in a.ids.split(',')}
        roots = [r for r in roots if r['id'] in keep]
    done = set()
    if os.path.exists(a.out):
        with open(a.out) as f:
            for line in f:
                try:
                    done.add(json.loads(line)['id'])
                except ValueError:
                    pass                      # torn last line after a crash: recomputed
    todo = [r for r in roots if r['id'] not in done]
    with open(a.out, 'a') as out, Pool(a.workers) as pool:
        for rec in pool.imap_unordered(one, todo):
            out.write(json.dumps(rec) + '\n'); out.flush()


if __name__ == '__main__':
    main()
