"""Knuth-type level-2 probe for root 1: uniform random children of (root, t1=(0,8)),
exact widths (width_exact) for all targets adjacent to u or t1; rule R1 = min over these."""
import sys, json, random, time
from width_dp import Geo, width_exact, load_roots
g=Geo(7)
C=json.load(open('root1_t1_children.json')); r=load_roots('/home/claude/repo/experiments/memetik/root8105_pilot_1_0_1/roots.tsv',g)[0]['row']
t1=C['t1']; kids=[int(x,16) for x in C['rows']]
rng=random.Random(4711); out=open('probe_d2.jsonl','a')
for k in range(12):
    row=rng.choice(kids); S={0:r,t1:row}
    cand=[t for t in range(g.n) if t not in S and ((r>>t)&1 or (row>>t)&1)]
    t0=time.time(); W={t:width_exact(g,S,t) for t in cand}
    tmin=min(W,key=W.get)
    out.write(json.dumps({'sample':k,'row':hex(row),'n_cand':len(cand),'min':W[tmin],'argmin':g.labels[tmin],
        'argmin_adj_u':(r>>tmin)&1,'widths':{str(t):w for t,w in W.items()},'sec':round(time.time()-t0,1)})+'\n'); out.flush()
