"""Cross-check width_exact against the UNCHANGED pilot encoder core.encode plus
exhaustive Glucose blocking-clause enumeration.

Usage:
  python3 crosscheck_sat.py PILOT_DIR small          # m=4,5 random states, depth 1..4
  python3 crosscheck_sat.py PILOT_DIR m7 ROOTS.tsv   # m=7, root 1, depth 1 and one depth-2 state
PILOT_DIR = experiments/memetik/root8105_pilot_1_0_1 (core.py is imported from there).
pynauty is not needed: a stub is injected if it is missing (encode does not use it).
Every case is EXACT vs EXACT; a per-case CPU cap only marks a case CENSORED,
it is never counted as agreement.
"""
import importlib
import json
import random
import sys
import time
import types

from width_dp import Geo, width_exact, load_roots


def import_pilot(pilot_dir):
    try:
        import pynauty  # noqa: F401
    except ImportError:
        stub = types.ModuleType('pynauty')
        stub.Graph = lambda *a, **k: None
        stub.certificate = stub.autgrp = lambda *a, **k: (_ for _ in ()).throw(RuntimeError('stub'))
        sys.modules['pynauty'] = stub
    sys.path.insert(0, pilot_dir)
    return importlib.import_module('core')


def sat_rows(pc, G, rows, t, cpu_cap=None):
    from pysat.solvers import Glucose4
    cnf, var = pc.encode(G, rows, t)
    fixed, free = pc.projection(G, rows, t, var)
    out, t0 = [], time.process_time()
    with Glucose4(bootstrap_with=cnf.clauses) as s:
        while s.solve():
            pos = {v for v in s.get_model() if v > 0}
            out.append(fixed | sum(1 << v for v, l in free if l in pos))
            s.add_clause([-l if l in pos else l for _, l in free])
            if cpu_cap and time.process_time() - t0 > cpu_cap:
                return out, False
    return out, True


def random_root(g, rng):
    marg, labs = g.margins(0), list(range(1, g.n))
    while True:
        rng.shuffle(labs)
        deg, R = [0] * g.b, []
        for i in labs:
            a, b = g.labels[i]
            if deg[a] < marg[a] and deg[b] < marg[b]:
                R.append(i); deg[a] += 1; deg[b] += 1
        if deg == marg:
            return sum(1 << i for i in R)


def small(pc):
    rng = random.Random(7)
    report = []
    for m, depth, states in ((4, 1, 3), (5, 1, 3), (4, 2, 30), (4, 3, 30), (5, 2, 25), (5, 3, 25), (5, 4, 15)):
        G, g = pc.Geometry(m), Geo(m)
        tested = mism = 0
        for _ in range(states):
            rows = {0: random_root(g, rng)}
            while len(rows) < depth:
                t = rng.choice([v for v in range(g.n) if v not in rows])
                kids, _ = sat_rows(pc, G, rows, t)
                if not kids:
                    break
                rows[t] = rng.choice(kids)
            if len(rows) < depth:
                continue
            G.verify(rows)
            for t in [v for v in range(g.n) if v not in rows]:
                a, _ = sat_rows(pc, G, rows, t)
                tested += 1
                mism += len(a) != width_exact(g, rows, t)
        report.append({'m': m, 'depth': depth, 'cases': tested, 'mismatches': mism})
        print(json.dumps(report[-1]), flush=True)
    return report


def m7(pc, roots_path):
    G, g = pc.Geometry(7), Geo(7)
    r = load_roots(roots_path, g)[0]['row']
    t1 = G.index[(0, 8)]
    kids, done = sat_rows(pc, G, {0: r}, t1)
    print(json.dumps({'depth': 1, 'target': [0, 8], 'sat': len(kids), 'complete': done,
                      'dp': width_exact(g, {0: r}, t1)}), flush=True)
    rng = random.Random(2026)
    S = {0: r, t1: rng.choice(kids)}
    W = {t: width_exact(g, S, t) for t in range(g.n) if t not in S}
    for t in sorted(W, key=W.get)[:2]:
        rows, done = sat_rows(pc, G, S, t, cpu_cap=600)
        print(json.dumps({'depth': 2, 'target': list(G.labels[t]), 'dp': W[t], 'sat': len(rows),
                          'status': ('MATCH' if len(rows) == W[t] else 'MISMATCH') if done else 'CENSORED'}), flush=True)


if __name__ == '__main__':
    pc = import_pilot(sys.argv[1])
    small(pc) if sys.argv[2] == 'small' else m7(pc, sys.argv[3])
