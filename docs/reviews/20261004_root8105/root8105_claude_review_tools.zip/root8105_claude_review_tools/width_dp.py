"""Exact projected widths for the ROOT8105 row model (review tool, Claude, 04.10.2026).

Model (derived from SRG(v,2m,1,2), checked against core.py of root8105_pilot_1_0_1):
  border vertices 0..2m-1, matching a <-> a+m; labels = 2-subsets {a,b}, b-a != m.
  A row of label t is a label set R (t not in R) whose degree profile on the border
  equals margins(t) (1 on t and its partners, 2 elsewhere).
Depth 1 (only root u = label 0 built): width / width_fast, pure edge DP, exact.
Depth >= 1 general: width_exact = sum over target adjacency patterns into the
  neighbourhoods of built rows adjacent to t of
  [star system of all built rows satisfiable | pattern] * DP count.
  The star systems are COUPLED through labels lying in two neighbourhoods; simpler
  per-star rules overcount (observed 2-9 %).  Validated against core.encode +
  exhaustive Glucose enumeration, see README / crosscheck_sat.py.
No pynauty, no SAT in the counting itself (a tiny pysat call only for star systems).
"""
import itertools

import numpy as np


class Geo:
    def __init__(self, m=7):
        self.m, self.b = m, 2 * m
        self.labels = [(a, b) for a, b in itertools.combinations(range(self.b), 2) if b - a != m]
        self.n = len(self.labels)
        self.sets = [frozenset(p) for p in self.labels]

    def margins(self, t):
        a, b = self.labels[t]
        sp = {a, b, (a + self.m) % self.b, (b + self.m) % self.b}
        return [1 if x in sp else 2 for x in range(self.b)]


def count_rows(g, t, forced=(), forbidden=(), flagged=(), k_target=None):
    """#R subset labels with degree profile margins(t), forced/forbidden labels,
    and |R cap flagged| == k_target (or no constraint if None)."""
    marg = g.margins(t)
    K = (k_target + 1) if k_target is not None else 1
    shape = tuple(d + 1 for d in marg) + (K + 1,)  # last axis: intersection count, K means overflow (dropped)
    A = np.zeros(shape, dtype=np.int64)
    A[(0,) * g.b + (0,)] = 1
    forced, forbidden, flagged = set(forced), set(forbidden), set(flagged)
    for idx, (a, b) in enumerate(g.labels):
        if idx == t or idx in forbidden:
            continue
        f = 1 if (idx in flagged and k_target is not None) else 0
        src = [slice(None)] * (g.b + 1)
        dst = [slice(None)] * (g.b + 1)
        src[a] = slice(0, marg[a]); dst[a] = slice(1, marg[a] + 1)
        src[b] = slice(0, marg[b]); dst[b] = slice(1, marg[b] + 1)
        if f:
            src[-1] = slice(0, K); dst[-1] = slice(1, K + 1)
        shifted = np.zeros_like(A)
        shifted[tuple(dst)] = A[tuple(src)]
        if f:
            shifted[..., K] = 0  # overflow beyond target is dropped
        A = shifted if idx in forced else A + shifted
    full = tuple(marg)
    if k_target is None:
        return int(A[full + (0,)])
    return int(A[full + (k_target,)])


def width(g, root_row, t):
    u = 0
    Nu = [v for v in range(g.n) if (root_row >> v) & 1]
    e = (root_row >> t) & 1
    inter = len(g.sets[t] & g.sets[u])
    k = 2 - e - inter
    if k < 0:
        return 0
    forced = [u] if e else []
    forbidden = [] if e else [u]
    if e:
        forbidden += [v for v in Nu if len(g.sets[v] & g.sets[u]) == 1]
    flagged = [v for v in Nu if v != t]
    return count_rows(g, t, forced, forbidden, flagged, k)


def load_roots(path, g):
    idx = {p: i for i, p in enumerate(g.labels)}
    out = []
    for line in open(path):
        if not line.strip() or line.startswith('#'):
            continue
        f = line.rstrip('\n').split('\t')
        labs = [tuple(map(int, w.split('-'))) for w in f[3:]]
        out.append({'id': int(f[0]), 'stab': int(f[1]), 'orbit': int(f[2]),
                    'row': sum(1 << idx[p] for p in labs)})
    return out


def count_rows_fast(g, t, forced=(), forbidden=(), flagged=(), k_target=None):
    """Same as count_rows, with vertex-axis elimination once a vertex is complete."""
    marg = g.margins(t)
    forced, forbidden, flagged = set(forced), set(forbidden), set(flagged)
    use = [i for i in range(g.n) if i != t and i not in forbidden]
    K = (k_target + 1) if k_target is not None else 1
    last = {}
    for i in use:
        for c in g.labels[i]:
            last[c] = max(last.get(c, -1), i)
    axes = list(range(g.b))  # axis position -> vertex
    A = np.zeros(tuple(d + 1 for d in marg) + (K + 1,), dtype=np.int64)
    A[(0,) * (g.b + 1)] = 1
    for c in range(g.b):  # vertices with no usable label must have margin 0 (never here)
        if c not in last:
            return 0
    for i in use:
        a, b = g.labels[i]
        pa, pb = axes.index(a), axes.index(b)
        f = 1 if (i in flagged and k_target is not None) else 0
        nd = A.ndim
        src = [slice(None)] * nd; dst = [slice(None)] * nd
        src[pa] = slice(0, marg[a]); dst[pa] = slice(1, marg[a] + 1)
        src[pb] = slice(0, marg[b]); dst[pb] = slice(1, marg[b] + 1)
        if f:
            src[-1] = slice(0, K); dst[-1] = slice(1, K + 1)
        sh = np.zeros_like(A)
        sh[tuple(dst)] = A[tuple(src)]
        if f:
            sh[..., K] = 0
        A = sh if i in forced else A + sh
        for c in (a, b):
            if last[c] == i:
                p = axes.index(c)
                A = np.take(A, marg[c], axis=p)
                axes.pop(p)
    assert not axes
    return int(A[k_target if k_target is not None else 0])


def width_fast(g, root_row, t):
    u = 0
    Nu = [v for v in range(g.n) if (root_row >> v) & 1]
    e = (root_row >> t) & 1
    k = 2 - e - len(g.sets[t] & g.sets[u])
    if k < 0:
        return 0
    forced = [u] if e else []
    forbidden = [] if e else [u]
    if e:
        forbidden += [v for v in Nu if len(g.sets[v] & g.sets[u]) == 1]
    flagged = [v for v in Nu if v != t]
    return count_rows_fast(g, t, forced, forbidden, flagged, k)


def count_rows_multi(g, t, forced=(), forbidden=(), flags=()):
    """Edge DP with several intersection constraints flags=[(set_of_labels, k), ...]."""
    marg = g.margins(t)
    forced, forbidden = set(forced), set(forbidden)
    if forced & forbidden:
        return 0
    use = [i for i in range(g.n) if i != t and i not in forbidden]
    if not forced <= set(use):
        return 0
    last = {}
    for i in use:
        for c in g.labels[i]:
            last[c] = max(last.get(c, -1), i)
    if len(last) != g.b:
        return 0
    flags = [(set(s), k) for s, k in flags]
    if any(k < 0 for _, k in flags):
        return 0
    extra = [k + 2 for _, k in flags]          # value k+1 = overflow sink
    A = np.zeros(tuple(d + 1 for d in marg) + tuple(extra), dtype=np.int64)
    A[(0,) * A.ndim] = 1
    axes = list(range(g.b))
    nf = len(flags)
    for i in use:
        a, b = g.labels[i]
        pa, pb = axes.index(a), axes.index(b)
        nd = A.ndim
        src = [slice(None)] * nd; dst = [slice(None)] * nd
        src[pa] = slice(0, marg[a]); dst[pa] = slice(1, marg[a] + 1)
        src[pb] = slice(0, marg[b]); dst[pb] = slice(1, marg[b] + 1)
        sh = np.zeros_like(A)
        sub = A[tuple(src)]
        # shift every flag axis containing label i by +1, folding overflow into sink
        for j, (s, k) in enumerate(flags):
            if i in s:
                ax = nd - nf + j
                moved = np.zeros_like(sub)
                idx_src = [slice(None)] * sub.ndim; idx_dst = [slice(None)] * sub.ndim
                idx_src[ax] = slice(0, k + 1); idx_dst[ax] = slice(1, k + 2)
                moved[tuple(idx_dst)] = sub[tuple(idx_src)]
                ov = [slice(None)] * sub.ndim; ov[ax] = slice(k + 1, k + 2)
                moved[tuple(ov)] += sub[tuple(ov)]
                sub = moved
        sh[tuple(dst)] = sub
        A = sh if i in forced else A + sh
        for c in (a, b):
            if last[c] == i:
                p = axes.index(c)
                A = np.take(A, marg[c], axis=p)
                axes.pop(p)
    return int(A[tuple(k for _, k in flags)])


def _star_system_sat(g, rows, t, t_adj):
    """Is the star system of all built rows satisfiable, given target t's adjacency
    t_adj (dict open label -> 0/1)?  Open-open edges inside each built row's
    neighbourhood are free variables, exactly as in core.encode."""
    from pysat.card import CardEnc, EncType
    from pysat.formula import IDPool
    from pysat.solvers import Minisat22
    pool = IDPool(); clauses = []
    def term(v, w):                      # ('c', 0/1) constant or ('v', id)
        if v in rows:
            return ('c', (rows[v] >> w) & 1)
        if w in rows:
            return ('c', (rows[w] >> v) & 1)
        if v == t:
            return ('c', t_adj.get(w, 0))
        if w == t:
            return ('c', t_adj.get(v, 0))
        return ('v', pool.id(tuple(sorted((v, w)))))
    for s, rs in rows.items():
        Ns = [v for v in range(g.n) if (rs >> v) & 1]
        for v in Ns:
            if v in rows or v == t:
                continue
            need = 1 - len(g.sets[s] & g.sets[v])
            terms = [term(v, w) for w in Ns if w != v]
            r = need - sum(x for k, x in terms if k == 'c')
            vs = [x for k, x in terms if k == 'v']
            if r < 0 or r > len(vs):
                return False
            if not vs:
                continue
            if r == 0:
                clauses += [[-x] for x in vs]
            elif r == len(vs):
                clauses += [[x] for x in vs]
            else:
                clauses += CardEnc.equals(lits=vs, bound=r, vpool=pool, encoding=EncType.seqcounter).clauses
    with Minisat22(bootstrap_with=clauses) as so:
        return so.solve()


def width_exact(g, rows, t):
    """Exact projected width of target t under F(S,t) of core.encode:
    sum over target adjacency patterns sigma into the stars containing t of
    [star system satisfiable | sigma] * DP-count(t rows consistent with sigma)."""
    if t in rows:
        raise ValueError('target built')
    forced, forbidden, flags = [], [], []
    W = set()
    for s, rs in rows.items():
        e = (rs >> t) & 1
        (forced if e else forbidden).append(s)
        Ns = {v for v in range(g.n) if (rs >> v) & 1 and v != t}
        flags.append((Ns, 2 - e - len(g.sets[t] & g.sets[s])))
        if e:
            W |= {v for v in Ns if v not in rows}
    W = sorted(W)
    if not W:
        return count_rows_multi(g, t, forced, forbidden, flags) if _star_system_sat(g, rows, t, {}) else 0
    total = 0
    # enumerate adjacency patterns of t into W respecting per-star counts (open part)
    stars_t = [(s, {v for v in range(g.n) if (rs >> v) & 1}) for s, rs in rows.items() if (rs >> t) & 1]
    def need_open(s, Ns):
        k = 1 - len(g.sets[t] & g.sets[s])           # codegree requirement within N(s)
        k -= sum(1 for b in Ns if b in rows and (rows[b] >> t) & 1)
        return k
    reqs = [(Ns, need_open(s, Ns)) for s, Ns in stars_t]
    if any(k < 0 for _, k in reqs):
        return 0
    for size in range(0, min(len(W), sum(k for _, k in reqs)) + 1):
        for chosen in itertools.combinations(W, size):
            cs = set(chosen)
            if any(len(cs & Ns) != k for Ns, k in reqs):
                continue
            t_adj = {w: int(w in cs) for w in W}
            if not _star_system_sat(g, rows, t, t_adj):
                continue
            total += count_rows_multi(g, t, forced + list(cs), forbidden + [w for w in W if w not in cs], flags)
    return total
