"""Real 66-root calibration: SIGTERM/resume and separate SIGKILL/recovery case."""
import gc
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

package, evidence = map(lambda v: Path(v).resolve(), sys.argv[1:3])
sys.path.insert(0, str(package))
from census import audit_start, initialise, reconcile_crash, report
from runtime import atomic, connect, get, put


def wait_for(predicate, proc=None):
    while True:
        result = predicate()
        if result:
            return result
        if proc is not None and proc.poll() is not None:
            raise AssertionError('controller exited before expected milestone')
        time.sleep(.1)


def launch(run, name):
    log = (evidence / (name + '.log')).open('w')
    proc = subprocess.Popen([sys.executable, str(package / 'census.py'), 'run', str(run),
                             '--phase', 'calibrate'], stdin=subprocess.DEVNULL, stdout=log, stderr=log)
    return proc, log


def finish(proc, log):
    code = proc.wait()
    log.close()
    assert code == 0, (code, log.name)


def partial_output(run):
    for path in (run / 'attempts').glob('*.output.json'):
        data = json.loads(path.read_text())
        if 0 < len(data['counts']) < 83 and data['state'] == 'RUNNING':
            return data


def account_snapshot(run):
    con = connect(run, readonly=True)
    audit_start(con)
    result = report(con)
    result['open_sessions'] = con.execute('SELECT COUNT(*) FROM sessions WHERE ended IS NULL').fetchone()[0]
    result['latest_state'] = get(con, 'latest_state')
    result['attempts'] = con.execute('SELECT COUNT(*) FROM attempts').fetchone()[0]
    con.close()
    return result


run = evidence / 'calibration'
calibration_record = json.loads((evidence / 'calibration_verified.json').read_text())
final = calibration_record['final']
con = connect(run, readonly=True)
audit_start(con)
preflight = get(con, 'preflight')
results = {r['root']: json.loads(r['payload']) for r in con.execute('SELECT root,payload FROM results')}
con.close()
partials = {}
for specpath in (run / 'attempts').glob('*.input.json'):
    spec = json.loads(specpath.read_text())
    if spec['partial']:
        partials[spec['root']['id']] = spec['partial']
assert sum(map(len, partials.values())) == calibration_record['preserved_partial_counts']
# A separate bounded REAL-kernel case. Subset is declared in BOTH manifest and DB before first run.
crash = evidence / 'crash-real-third'
config = initialise(crash, 1, 3600)
con = connect(crash)
with con:
    con.execute('DELETE FROM roots WHERE id!=672')
    for key in ('order', 'calibration'):
        config[key] = [672]
        put(con, key, config[key])
    put(con, 'preflight', preflight | {'scope': 'same frozen package; preflight inherited from calibration test'})
config['integration_scope'] = 'one-root real-kernel crash test, NOT a complete census'
atomic(crash / 'manifest.json', config)
con.close()
proc, log = launch(crash, 'crash-third-before-kill')
def active_kernel_worker():
    from runtime import process_stat
    for path in (crash / 'attempts').glob('*.output.json'):
        data = json.loads(path.read_text())
        stat = process_stat(0, proc_pid=data['process']['proc_pid'], identity=data['process']['identity'])
        if data['state'] == 'RUNNING' and stat and stat['cpu_s'] >= 1.5:
            return data
saved = wait_for(active_kernel_worker, proc)
proc.kill()
proc.wait()
log.close()
output = crash / 'attempts' / (saved['attempt'] + '.output.json')
wait_for(lambda: json.loads(output.read_text())['state'] != 'RUNNING')
crash_partial = json.loads(output.read_text())
assert crash_partial['state'] == 'STOPPED_PARTIAL' and 0 < len(crash_partial['counts']) < 83
plan = wait_for(lambda: (lambda x: None if x['blocked'] else x)(reconcile_crash(crash)))
assert 'applied' not in plan
applied = reconcile_crash(crash, apply=True)
assert applied['applied'] and len(applied['attempts']) == 1
proc, log = launch(crash, 'crash-third-after-reconcile')
finish(proc, log)
crash_final = account_snapshot(crash)
assert crash_final['cpu_is_lower_bound'] and crash_final['roots']['DONE'] == 1
con = connect(crash, readonly=True)
crash_counts = json.loads(con.execute('SELECT payload FROM results').fetchone()[0])['counts']
assert get(con, 'salvage_' + saved['attempt'])
con.close()
atomic(evidence / 'crash_verified.json', {'status': 'PASS', 'reconciliation': applied, 'final': crash_final})
print('CRASH_VERIFIED ' + json.dumps(crash_final), flush=True)

# Independent vertex recursion: three complete calibration roots, one per type, plus crash root.
from kernel import Geo, VertexSampler, load_roots
roots = {r['id']: r for r in load_roots()}
chosen = [next(r for r in sorted(results) if roots[r]['type'] == typ) for typ in (0, 1, 2)]
g = Geo()
comparisons = []
for rid in chosen + [672]:
    counts = crash_counts if rid == 672 else results[rid]['counts']
    for target in range(1, 84):
        sampler = VertexSampler(g, int(roots[rid]['row'], 16), target)
        assert sampler.total == counts[str(target)]['width'], (rid, target)
        sampler.rec.cache_clear()
        del sampler
    gc.collect()
    comparisons.append({'root': rid, 'type': roots[rid]['type'], 'independent_vertex_matches': 83})
    print('VERTEX_VERIFIED ' + str(rid), flush=True)
fixture_matches = 0
for line in (package / 'fixtures/reviewer_widths128.jsonl').read_text().splitlines():
    fixture = json.loads(line)
    if fixture['id'] in results:
        assert fixture['w'] == [results[fixture['id']]['counts'][str(t)]['width'] for t in range(1, 84)]
        fixture_matches += 83
atomic(evidence / 'INTEGRATION.json', {'status': 'PASS', 'calibration': final,
    'exact_counts': 5478, 'preserved_partial_counts': sum(map(len, partials.values())),
    'observed_active_workers': 11, 'crash': crash_final, 'independent_comparisons': comparisons,
    'fixture_regression_matches': fixture_matches, 'scope': 'Linux cloud; real kernel; NOT Windows/WSL or Ryzen',
    'driver_cpu_s': time.process_time(), 'package': str(package)})
print('INTEGRATION_PASS', flush=True)
