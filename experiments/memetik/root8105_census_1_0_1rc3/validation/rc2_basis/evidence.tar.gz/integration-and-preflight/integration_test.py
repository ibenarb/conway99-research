"""Real 66-root calibration: SIGTERM/resume and separate SIGKILL/recovery case."""
import gc
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

package, evidence = map(lambda v: Path(v).resolve(), sys.argv[1:3])
sys.path.insert(0, str(package))
from census import audit_start, initialise, reconcile_crash, report
from runtime import atomic, connect, get, put


def wait_for(predicate, proc=None):
    while True:
        result = predicate()
        if result:
            return result
        if proc is not None and proc.poll() is not None:
            raise AssertionError('controller exited before expected milestone')
        time.sleep(.1)


def launch(run, name):
    log = (evidence / (name + '.log')).open('w')
    proc = subprocess.Popen([sys.executable, str(package / 'census.py'), 'run', str(run),
                             '--phase', 'calibrate'], stdin=subprocess.DEVNULL, stdout=log, stderr=log)
    return proc, log


def finish(proc, log):
    code = proc.wait()
    log.close()
    assert code == 0, (code, log.name)


def partial_output(run):
    for path in (run / 'attempts').glob('*.output.json'):
        data = json.loads(path.read_text())
        if 0 < len(data['counts']) < 83 and data['state'] == 'RUNNING':
            return data


def account_snapshot(run):
    con = connect(run, readonly=True)
    audit_start(con)
    result = report(con)
    result['open_sessions'] = con.execute('SELECT COUNT(*) FROM sessions WHERE ended IS NULL').fetchone()[0]
    result['latest_state'] = get(con, 'latest_state')
    result['attempts'] = con.execute('SELECT COUNT(*) FROM attempts').fetchone()[0]
    con.close()
    return result


run = evidence / 'calibration'
wait_for(lambda: (run / 'preflight.json').exists())
proc, log = launch(run, 'calibration-pause')
seen = wait_for(lambda: partial_output(run), proc)
status = json.loads((run / 'status.json').read_text())
assert status['active_workers'] == 11, status
proc.send_signal(signal.SIGTERM)
finish(proc, log)
con = connect(run, readonly=True)
audit_start(con)
partials = {r['id']: json.loads(r['partial']) for r in con.execute("SELECT id,partial FROM roots WHERE state='PENDING' AND partial!='{}'")}
assert partials and any(0 < len(v) < 83 for v in partials.values())
preflight = get(con, 'preflight')
con.close()
paused = account_snapshot(run)
assert paused['latest_state'] == 'USER_SIGNAL_CHECKPOINT'
atomic(evidence / 'pause_verified.json', {'snapshot': paused, 'partial_roots': {str(k): len(v) for k, v in partials.items()},
                                        'observed_active_workers': status['active_workers']})
proc, log = launch(run, 'calibration-resume')
finish(proc, log)
final = account_snapshot(run)
assert final['roots']['DONE'] == 66 and final['open_attempts'] == final['open_sessions'] == 0
assert final['latest_state'] == 'CALIBRATION_COMPLETE'
assert final['aggregate_cpu_s'] > paused['aggregate_cpu_s'] and not final['cpu_is_lower_bound']
con = connect(run, readonly=True)
results = {r['root']: json.loads(r['payload']) for r in con.execute('SELECT root,payload FROM results')}
for rid, prior in partials.items():
    assert all(results[rid]['counts'][t] == value for t, value in prior.items())
assert sum(len(v['counts']) for v in results.values()) == 5478
assert not con.execute('SELECT COUNT(*) FROM attempts WHERE cpu_exact!=1').fetchone()[0]
con.close()
atomic(evidence / 'calibration_verified.json', {'status': 'PASS', 'final': final, 'exact_counts': 5478,
    'preserved_partial_counts': sum(map(len, partials.values())), 'observed_active_workers': 11})
print('CALIBRATION_VERIFIED ' + json.dumps(final), flush=True)

# A separate bounded REAL-kernel case. Subset is declared in BOTH manifest and DB before first run.
crash = evidence / 'crash-real'
config = initialise(crash, 1, 3600)
con = connect(crash)
with con:
    con.execute('DELETE FROM roots WHERE id!=4696')
    for key in ('order', 'calibration'):
        config[key] = [4696]
        put(con, key, config[key])
    put(con, 'preflight', preflight | {'scope': 'same frozen package; preflight inherited from calibration test'})
config['integration_scope'] = 'one-root real-kernel crash test, NOT a complete census'
atomic(crash / 'manifest.json', config)
con.close()
proc, log = launch(crash, 'crash-before-kill')
saved = wait_for(lambda: partial_output(crash), proc)
proc.kill()
proc.wait()
log.close()
output = crash / 'attempts' / (saved['attempt'] + '.output.json')
wait_for(lambda: json.loads(output.read_text())['state'] != 'RUNNING')
plan = wait_for(lambda: (lambda x: None if x['blocked'] else x)(reconcile_crash(crash)))
assert 'applied' not in plan
applied = reconcile_crash(crash, apply=True)
assert applied['applied'] and len(applied['attempts']) == 1
proc, log = launch(crash, 'crash-after-reconcile')
finish(proc, log)
crash_final = account_snapshot(crash)
assert crash_final['cpu_is_lower_bound'] and crash_final['roots']['DONE'] == 1
con = connect(crash, readonly=True)
crash_counts = json.loads(con.execute('SELECT payload FROM results').fetchone()[0])['counts']
assert get(con, 'salvage_' + saved['attempt'])
con.close()
atomic(evidence / 'crash_verified.json', {'status': 'PASS', 'reconciliation': applied, 'final': crash_final})
print('CRASH_VERIFIED ' + json.dumps(crash_final), flush=True)

# Independent vertex recursion: three complete calibration roots, one per type, plus crash root.
from kernel import Geo, VertexSampler, load_roots
roots = {r['id']: r for r in load_roots()}
chosen = [next(r for r in sorted(results) if roots[r]['type'] == typ) for typ in (0, 1, 2)]
g = Geo()
comparisons = []
for rid in chosen + [4696]:
    counts = crash_counts if rid == 4696 else results[rid]['counts']
    for target in range(1, 84):
        sampler = VertexSampler(g, int(roots[rid]['row'], 16), target)
        assert sampler.total == counts[str(target)]['width'], (rid, target)
        sampler.rec.cache_clear()
        del sampler
    gc.collect()
    comparisons.append({'root': rid, 'type': roots[rid]['type'], 'independent_vertex_matches': 83})
    print('VERTEX_VERIFIED ' + str(rid), flush=True)
fixture_matches = 0
for line in (package / 'fixtures/reviewer_widths128.jsonl').read_text().splitlines():
    fixture = json.loads(line)
    if fixture['id'] in results:
        assert fixture['w'] == [results[fixture['id']]['counts'][str(t)]['width'] for t in range(1, 84)]
        fixture_matches += 83
atomic(evidence / 'INTEGRATION.json', {'status': 'PASS', 'calibration': final,
    'exact_counts': 5478, 'preserved_partial_counts': sum(map(len, partials.values())),
    'observed_active_workers': 11, 'crash': crash_final, 'independent_comparisons': comparisons,
    'fixture_regression_matches': fixture_matches, 'scope': 'Linux cloud; real kernel; NOT Windows/WSL or Ryzen',
    'driver_cpu_s': time.process_time(), 'package': str(package)})
print('INTEGRATION_PASS', flush=True)
