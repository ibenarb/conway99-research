from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
cli = root / "experiments/memetik/lambda_decision_1_0_0/run.py"
run = Path.home() / "conway99_workspace/ryzen_lambda_decision_100_20260924"
if run.exists():
    raise SystemExit("Run already exists: use status/check/launch, do not overwrite")
for action in ("prepare", "check", "launch"):
    subprocess.run([sys.executable, str(cli), action, str(run)], check=True)
print("Background run launched. Log:", run / "controller.log")
