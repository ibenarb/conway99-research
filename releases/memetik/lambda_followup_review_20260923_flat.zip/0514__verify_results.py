"""Audit exported run using the independent set-based graph verifier."""
import hashlib
import importlib.util
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[3]
run = pathlib.Path(sys.argv[1])
spec = importlib.util.spec_from_file_location("independent", ROOT / "src/memetic_v2/verify.py")
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = read(run / "plan.json")
fingerprint = read(run / "FINGERPRINT.json")
for name, expected in fingerprint["files"].items():
    assert sha(run / name) == expected, name
seen = {}
claims = 0

def walk(value):
    global claims
    if isinstance(value, dict):
        if "graph6" in value and "scores" in value:
            graph = value["graph6"]
            if graph not in seen:
                result = verifier.check_graph(graph, "lambda")
                assert result["hard_valid"], result["errors"]
                histogram = {int(k): v for k, v in result["residual_histogram"].items()}
                maximum = max(map(abs, histogram))
                seen[graph] = {"W": result["W"], "F": result["F"],
                    "L1": sum(abs(k) * v for k, v in histogram.items()),
                    "Linf": maximum, "Nmax": sum(v for k, v in histogram.items() if abs(k) == maximum)}
            assert value["scores"] == seen[graph], "Score mismatch"
            claims += 1
        for item in value.values():
            walk(item)
    elif isinstance(value, list):
        for item in value:
            walk(item)

cpu = 0
for job in plan["jobs"]:
    directory = run / job["directory"]
    receipt = read(directory / "receipt.json")
    assert receipt["status"] == "COMPLETE" and receipt["exit_code"] == 0
    for filename in ("task", "result", "checkpoint", "archive"):
        suffix = ".sqlite" if filename == "archive" else ".json"
        assert sha(directory / (filename + suffix)) == receipt[filename + "_sha256"]
    assert abs(sum(s["cpu_seconds"] for s in receipt["sessions"]) - receipt["cpu_seconds"]) < 1e-6
    cpu += receipt["cpu_seconds"] - job["initial_actual_cpu"]
    result = read(directory / "result.json")
    walk(result)
    assert result["endpoint_cpu_seconds"] == job["cumulative_budget_seconds"]
    initial = run / "initial" / job["id"] / "result.json"
    if initial.exists():
        old = read(initial)
        assert result["curves"][:len(old["curves"])] == old["curves"]
walk(read(run / "HARVEST.json"))
evaluation = read(run / "EVALUATION.json")
assert abs(cpu / 3600 - evaluation["new_search_cpu_hours"]) < 1e-9
print(json.dumps({"status": "PASS", "jobs": len(plan["jobs"]),
    "fingerprint_files": len(fingerprint["files"]), "distinct_labelled_graphs": len(seen),
    "graph_score_claims": claims, "new_search_cpu_hours": cpu / 3600,
    "scope": "Receipt bytes, fingerprint, CPU sums, preserved curve prefixes; independent lambda and five-score validation of result and harvest graph records. Not a replay of search or depth-two census."}, indent=2))
