from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
cli = root / "experiments/memetik/lambda_radius_1_0_0/run.py"
run = Path.home() / "conway99_workspace/ryzen_lambda_radius_100_20260926"
if run.exists():
    raise SystemExit("Run exists; use its frozen run.py launch/status. No overwrite performed.")
for action in ("prepare", "launch"):
    subprocess.run([sys.executable, str(cli), action, str(run)], check=True)
print("Autonomous controls, depth3, depth4 launched. Log:", run / "controller.log")
