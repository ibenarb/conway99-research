"""Run beside the extracted flat ZIP files. Standard Python only."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name


def score(g6):
    values = [ord(c) - 63 for c in g6]
    assert all(0 <= x <= 63 for x in values)
    assert values[0] == 63 and values[1] != 63
    n = (values[1] << 12) + (values[2] << 6) + values[3]
    assert n == 99
    bits = [(x >> k) & 1 for x in values[4:] for k in range(5, -1, -1)]
    neighbors = [set() for _ in range(n)]
    index = 0
    for v in range(n):
        for u in range(v):
            if bits[index]:
                neighbors[u].add(v)
                neighbors[v].add(u)
            index += 1
    assert all(len(x) == 14 for x in neighbors)
    residuals = []
    for v in range(n):
        for u in range(v):
            common = len(neighbors[u] & neighbors[v])
            edge = u in neighbors[v]
            assert not edge or common == 1
            residuals.append(common + int(edge) - 2)
    maximum = max(map(abs, residuals))
    return dict(W=sum(x != 0 for x in residuals), L1=sum(map(abs, residuals)),
                F=sum(x*x for x in residuals), Linf=maximum,
                Nmax=sum(abs(x) == maximum for x in residuals))


cache = {}
occurrences = 0


def visit(value):
    global occurrences
    if isinstance(value, dict):
        if 'graph6' in value and 'scores' in value:
            g6 = value['graph6']
            if g6 not in cache:
                cache[g6] = score(g6)
            assert cache[g6] == value['scores']
            if 'state' in value:
                assert hashlib.sha256(g6.encode()).hexdigest() == value['state']
            occurrences += 1
        for child in value.values():
            visit(child)
    elif isinstance(value, list):
        for child in value:
            visit(child)


for path in sorted(root.glob('*__result.json')):
    visit(json.loads(path.read_text()))
for path in sorted(root.glob('*__task.json')):
    visit(json.loads(path.read_text()))
print(json.dumps({'status': 'PASS', 'unique_graphs': len(cache),
                  'candidate_occurrences': occurrences,
                  'hashes_checked': len(manifest),
                  'isomorphism_and_sqlite_audit': False}))
