#!/usr/bin/env python3
import argparse, html, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from pilot import H0, N, decode_g6, healthy

COLORS = {
    'healthy': '#b7e4c7',
    'unhealthy': '#f4a6a6',
    'protected': '#2d6a4f',
    'frozen': '#577590',
    'target': '#ffd166',
    'border': '#dddddd',
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('checkpoint')
    ap.add_argument('svg')
    a = ap.parse_args()
    cp = json.loads(Path(a.checkpoint).read_text())
    rows = decode_g6(cp['g6'])
    completed = set(cp.get('completed', []))
    order = cp.get('order', [])
    target = order[len(completed)] if len(completed) < len(order) else None
    mode = cp.get('task', {}).get('mode', '')
    protected = set()
    for v in completed:
        protected.update((min(v, j), max(v, j)) for j in range(N) if j != v)
    frozen = set()
    if mode == 'frozen_rows':
        for v in completed:
            frozen.update((min(v, j), max(v, j)) for j in range(H0, N) if j != v)
    cell = 5
    margin = 130
    size = margin + N * cell + 20
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}">',
             '<rect width="100%" height="100%" fill="white"/>',
             '<style>text{font-family:monospace;font-size:12px}</style>']
    for i in range(N):
        for j in range(N):
            if i == j:
                color = '#222222'
            else:
                pair = (min(i, j), max(i, j))
                color = COLORS['healthy'] if healthy(rows, i, j) else COLORS['unhealthy']
                if pair in protected:
                    color = COLORS['protected']
                if pair in frozen:
                    color = COLORS['frozen']
                if i == target or j == target:
                    color = COLORS['target']
                if i < H0 or j < H0:
                    color = COLORS['border'] if pair not in protected and i != target and j != target else color
            x = margin + j * cell
            y = margin + i * cell
            parts.append(f'<rect x="{x}" y="{y}" width="{cell}" height="{cell}" fill="{color}"/>')
    legend = [
        ('gesund', COLORS['healthy']), ('ungesund', COLORS['unhealthy']),
        ('geschützt', COLORS['protected']), ('eingefroren', COLORS['frozen']),
        ('Zielzeile', COLORS['target']), ('fester Rand', COLORS['border'])]
    parts.append(f'<text x="10" y="20">depth={len(completed)} W={cp.get("W","?")} mode={html.escape(mode)}</text>')
    y = 42
    for label, color in legend:
        parts.append(f'<rect x="10" y="{y-10}" width="12" height="12" fill="{color}"/>')
        parts.append(f'<text x="28" y="{y}">{html.escape(label)}</text>')
        y += 20
    parts.append('</svg>')
    Path(a.svg).write_text('\n'.join(parts))
    print(a.svg)

if __name__ == '__main__':
    main()
