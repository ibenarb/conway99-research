#!/usr/bin/env python3
import random, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from pilot import *

def cycle(n):
    rows=[0]*n
    for i in range(n):
        for j in ((i-1)%n,(i+1)%n): rows[i]|=1<<j
    return tuple(rows)

def test_health_formula_small():
    r=cycle(5)
    assert common(r,0,1)==0

def test_protection_detects_remote_damage():
    # K3 + isolated pair: pair (0,1) is healthy for lambda=1-like local relation;
    # removing edge 1-2 damages (0,1) although 0-1 itself is untouched.
    rows=[0]*4
    for a,b in [(0,1),(0,2),(1,2)]: rows[a]|=1<<b; rows[b]|=1<<a
    rows=tuple(rows); assert healthy(rows,0,1)
    bad=apply_toggle(rows,((1,2),),())
    assert not protection_ok(bad,frozenset({(0,1)}))

def test_backtrack_state_copy():
    s=State((1,2),frozenset({(0,1)}),frozenset(),(15,),(15,16),2,3)
    t=State(s.rows,s.protected,s.frozen,s.completed,s.order,s.backtracks,s.attempts)
    assert asdict(s)==asdict(t)

def synthetic_frame():
    rows=[0]*N
    def add(a,b): rows[a]|=1<<b; rows[b]|=1<<a
    for a in range(1,15): add(0,a); add(a,1+((a-1+7)%14))
    for u,(a,b) in enumerate(OUTER): add(H0+u,1+a); add(H0+u,1+b)
    for u in range(84):
        for d in range(1,7):
            v=(u+d)%84
            if u<v or (u+d)>=84: add(H0+u,H0+v)
    return tuple(rows)

def test_full_frame_and_switch():
    r=synthetic_frame(); validate(r); assert frame_ok(r)
    rng=random.Random(7)
    sw=random_switch(r,rng,H0); assert sw
    q=apply_toggle(r,*sw); validate(q); assert frame_ok(q)
    assert all(x.bit_count()==14 for x in q)

if __name__=='__main__':
    for f in [test_health_formula_small,test_protection_detects_remote_damage,test_backtrack_state_copy,test_full_frame_and_switch]:
        f(); print('PASS',f.__name__)
